<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Level extends Model
{
    use HasFactory;

    protected $table = 'levels';
    protected $primaryKey = 'level_id';

    protected $fillable = [
        'level',
        'title',
        'min_xp',
        'max_xp',
        'icon',
        'color',
        'can_create_community',
    ];

    protected $casts = [
        'can_create_community' => 'boolean',
    ];

    public function users(): HasMany
    {
        return $this->hasMany(User::class, 'level_id', 'level_id');
    }
}
