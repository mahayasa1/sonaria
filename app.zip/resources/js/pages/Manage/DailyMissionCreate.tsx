import React, { useState } from 'react';
import { Link, router } from '@inertiajs/react';
import AppLayout from '@/layouts/AppLayout';
import { apiFetch, ApiError } from '@/lib/api';
import { ArrowLeft, Flame, Loader2 } from 'lucide-react';

export default function DailyMissionCreate({
  community,
  activeCount,
}: {
  community: { communities_id: number; community_name: string };
  activeCount: number;
}) {
  const [quizId, setQuizId] = useState('');
  const [missionNumber, setMissionNumber] = useState(activeCount + 1);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [xpMin, setXpMin] = useState(15);
  const [xpMax, setXpMax] = useState(30);
  const [startDate, setStartDate] = useState(new Date().toISOString().slice(0, 10));
  const [endDate, setEndDate] = useState(new Date().toISOString().slice(0, 10));
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = async () => {
    setLoading(true);
    setError(null);
    try {
      await apiFetch(`/api/communities/${community.communities_id}/daily-missions`, {
        method: 'POST',
        body: JSON.stringify({
          quiz_id: Number(quizId),
          mission_number: missionNumber,
          title,
          description,
          xp_reward_min: xpMin,
          xp_reward_max: xpMax,
          start_date: startDate,
          end_date: endDate,
        }),
      });
      router.visit('/daily-missions');
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Gagal membuat Daily Mission.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <AppLayout title="Buat Daily Mission" role="Member" communityRole="Ketua" communityName={community.community_name}>
      <Link href="/dashboard" className="flex items-center gap-1.5 font-manrope text-xs text-[#75708A] hover:text-[#F3EEE2]">
        <ArrowLeft size={14} /> Kembali
      </Link>

      <header className="mt-3">
        <h1 className="flex items-center gap-2 font-fraunces text-3xl text-[#F3EEE2]">
          <Flame size={24} className="text-[#C1443C]" /> Daily Mission Baru
        </h1>
      </header>

      {activeCount >= 6 ? (
        <p className="mt-6 font-manrope text-sm text-[#B7AFC2]">
          Komunitas ini sudah punya 6 daily mission aktif. Nonaktifkan salah satu dulu sebelum
          membuat yang baru.
        </p>
      ) : (
        <div className="mt-6 max-w-lg space-y-4">
          <div>
            <label className="font-manrope text-xs text-[#75708A]">
              ID Quiz (buat dulu lewat Main Quest → materi → "Tambah Quiz", lalu tempel ID-nya di sini)
            </label>
            <input
              value={quizId}
              onChange={(e) => setQuizId(e.target.value)}
              placeholder="mis. 12"
              className="mt-1 w-full rounded-lg border border-[#2A2333] bg-[#1E1826] px-3 py-2 font-manrope text-sm text-[#F3EEE2] focus:border-[#D9A441]/50 focus:outline-none"
            />
          </div>
          <div>
            <label className="font-manrope text-xs text-[#75708A]">Nomor Misi (1-6)</label>
            <input
              type="number"
              min={1}
              max={6}
              value={missionNumber}
              onChange={(e) => setMissionNumber(Number(e.target.value))}
              className="mt-1 w-full rounded-lg border border-[#2A2333] bg-[#1E1826] px-3 py-2 font-manrope text-sm text-[#F3EEE2] focus:border-[#D9A441]/50 focus:outline-none"
            />
          </div>
          <div>
            <label className="font-manrope text-xs text-[#75708A]">Judul</label>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="mt-1 w-full rounded-lg border border-[#2A2333] bg-[#1E1826] px-3 py-2 font-manrope text-sm text-[#F3EEE2] focus:border-[#D9A441]/50 focus:outline-none"
            />
          </div>
          <div>
            <label className="font-manrope text-xs text-[#75708A]">Deskripsi</label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={3}
              className="mt-1 w-full rounded-lg border border-[#2A2333] bg-[#1E1826] px-3 py-2 font-manrope text-sm text-[#F3EEE2] focus:border-[#D9A441]/50 focus:outline-none"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-manrope text-xs text-[#75708A]">XP Min</label>
              <input
                type="number"
                value={xpMin}
                onChange={(e) => setXpMin(Number(e.target.value))}
                className="mt-1 w-full rounded-lg border border-[#2A2333] bg-[#1E1826] px-3 py-2 font-manrope text-sm text-[#F3EEE2] focus:border-[#D9A441]/50 focus:outline-none"
              />
            </div>
            <div>
              <label className="font-manrope text-xs text-[#75708A]">XP Max</label>
              <input
                type="number"
                value={xpMax}
                onChange={(e) => setXpMax(Number(e.target.value))}
                className="mt-1 w-full rounded-lg border border-[#2A2333] bg-[#1E1826] px-3 py-2 font-manrope text-sm text-[#F3EEE2] focus:border-[#D9A441]/50 focus:outline-none"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="font-manrope text-xs text-[#75708A]">Mulai</label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="mt-1 w-full rounded-lg border border-[#2A2333] bg-[#1E1826] px-3 py-2 font-manrope text-sm text-[#F3EEE2] focus:border-[#D9A441]/50 focus:outline-none"
              />
            </div>
            <div>
              <label className="font-manrope text-xs text-[#75708A]">Selesai</label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="mt-1 w-full rounded-lg border border-[#2A2333] bg-[#1E1826] px-3 py-2 font-manrope text-sm text-[#F3EEE2] focus:border-[#D9A441]/50 focus:outline-none"
              />
            </div>
          </div>

          <button
            onClick={submit}
            disabled={loading || !title || !quizId}
            className="flex items-center gap-2 rounded-full bg-[#D9A441] px-6 py-2.5 font-manrope text-sm text-[#14101B] disabled:opacity-40"
          >
            {loading && <Loader2 size={14} className="animate-spin" />}
            Simpan
          </button>
          {error && <p className="font-manrope text-xs text-[#C1443C]">{error}</p>}
        </div>
      )}
    </AppLayout>
  );
}
