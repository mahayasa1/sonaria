import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\Admin\LevelController::index
 * @see app/Http/Controllers/Api/Admin/LevelController.php:14
 * @route '/api/admin/levels'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/admin/levels',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\Admin\LevelController::index
 * @see app/Http/Controllers/Api/Admin/LevelController.php:14
 * @route '/api/admin/levels'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\LevelController::index
 * @see app/Http/Controllers/Api/Admin/LevelController.php:14
 * @route '/api/admin/levels'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\Admin\LevelController::index
 * @see app/Http/Controllers/Api/Admin/LevelController.php:14
 * @route '/api/admin/levels'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\Admin\LevelController::index
 * @see app/Http/Controllers/Api/Admin/LevelController.php:14
 * @route '/api/admin/levels'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\LevelController::index
 * @see app/Http/Controllers/Api/Admin/LevelController.php:14
 * @route '/api/admin/levels'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\Admin\LevelController::index
 * @see app/Http/Controllers/Api/Admin/LevelController.php:14
 * @route '/api/admin/levels'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\Admin\LevelController::store
 * @see app/Http/Controllers/Api/Admin/LevelController.php:23
 * @route '/api/admin/levels'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/admin/levels',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Admin\LevelController::store
 * @see app/Http/Controllers/Api/Admin/LevelController.php:23
 * @route '/api/admin/levels'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\LevelController::store
 * @see app/Http/Controllers/Api/Admin/LevelController.php:23
 * @route '/api/admin/levels'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Admin\LevelController::store
 * @see app/Http/Controllers/Api/Admin/LevelController.php:23
 * @route '/api/admin/levels'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\LevelController::store
 * @see app/Http/Controllers/Api/Admin/LevelController.php:23
 * @route '/api/admin/levels'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\Admin\LevelController::update
 * @see app/Http/Controllers/Api/Admin/LevelController.php:42
 * @route '/api/admin/levels/{level}'
 */
export const update = (args: { level: number | { level_id: number } } | [level: number | { level_id: number } ] | number | { level_id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/admin/levels/{level}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\Admin\LevelController::update
 * @see app/Http/Controllers/Api/Admin/LevelController.php:42
 * @route '/api/admin/levels/{level}'
 */
update.url = (args: { level: number | { level_id: number } } | [level: number | { level_id: number } ] | number | { level_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { level: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'level_id' in args) {
            args = { level: args.level_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    level: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        level: typeof args.level === 'object'
                ? args.level.level_id
                : args.level,
                }

    return update.definition.url
            .replace('{level}', parsedArgs.level.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\LevelController::update
 * @see app/Http/Controllers/Api/Admin/LevelController.php:42
 * @route '/api/admin/levels/{level}'
 */
update.put = (args: { level: number | { level_id: number } } | [level: number | { level_id: number } ] | number | { level_id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Api\Admin\LevelController::update
 * @see app/Http/Controllers/Api/Admin/LevelController.php:42
 * @route '/api/admin/levels/{level}'
 */
    const updateForm = (args: { level: number | { level_id: number } } | [level: number | { level_id: number } ] | number | { level_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\LevelController::update
 * @see app/Http/Controllers/Api/Admin/LevelController.php:42
 * @route '/api/admin/levels/{level}'
 */
        updateForm.put = (args: { level: number | { level_id: number } } | [level: number | { level_id: number } ] | number | { level_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Api\Admin\LevelController::destroy
 * @see app/Http/Controllers/Api/Admin/LevelController.php:61
 * @route '/api/admin/levels/{level}'
 */
export const destroy = (args: { level: number | { level_id: number } } | [level: number | { level_id: number } ] | number | { level_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/admin/levels/{level}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\Admin\LevelController::destroy
 * @see app/Http/Controllers/Api/Admin/LevelController.php:61
 * @route '/api/admin/levels/{level}'
 */
destroy.url = (args: { level: number | { level_id: number } } | [level: number | { level_id: number } ] | number | { level_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { level: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'level_id' in args) {
            args = { level: args.level_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    level: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        level: typeof args.level === 'object'
                ? args.level.level_id
                : args.level,
                }

    return destroy.definition.url
            .replace('{level}', parsedArgs.level.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\LevelController::destroy
 * @see app/Http/Controllers/Api/Admin/LevelController.php:61
 * @route '/api/admin/levels/{level}'
 */
destroy.delete = (args: { level: number | { level_id: number } } | [level: number | { level_id: number } ] | number | { level_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Api\Admin\LevelController::destroy
 * @see app/Http/Controllers/Api/Admin/LevelController.php:61
 * @route '/api/admin/levels/{level}'
 */
    const destroyForm = (args: { level: number | { level_id: number } } | [level: number | { level_id: number } ] | number | { level_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\LevelController::destroy
 * @see app/Http/Controllers/Api/Admin/LevelController.php:61
 * @route '/api/admin/levels/{level}'
 */
        destroyForm.delete = (args: { level: number | { level_id: number } } | [level: number | { level_id: number } ] | number | { level_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const LevelController = { index, store, update, destroy }

export default LevelController