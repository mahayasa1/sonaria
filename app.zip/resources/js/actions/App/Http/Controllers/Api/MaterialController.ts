import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\MaterialController::show
 * @see app/Http/Controllers/Api/MaterialController.php:50
 * @route '/api/materials/{material}'
 */
export const show = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/materials/{material}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\MaterialController::show
 * @see app/Http/Controllers/Api/MaterialController.php:50
 * @route '/api/materials/{material}'
 */
show.url = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { material: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'materials_id' in args) {
            args = { material: args.materials_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    material: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        material: typeof args.material === 'object'
                ? args.material.materials_id
                : args.material,
                }

    return show.definition.url
            .replace('{material}', parsedArgs.material.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\MaterialController::show
 * @see app/Http/Controllers/Api/MaterialController.php:50
 * @route '/api/materials/{material}'
 */
show.get = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\MaterialController::show
 * @see app/Http/Controllers/Api/MaterialController.php:50
 * @route '/api/materials/{material}'
 */
show.head = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\MaterialController::show
 * @see app/Http/Controllers/Api/MaterialController.php:50
 * @route '/api/materials/{material}'
 */
    const showForm = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\MaterialController::show
 * @see app/Http/Controllers/Api/MaterialController.php:50
 * @route '/api/materials/{material}'
 */
        showForm.get = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\MaterialController::show
 * @see app/Http/Controllers/Api/MaterialController.php:50
 * @route '/api/materials/{material}'
 */
        showForm.head = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\MaterialController::store
 * @see app/Http/Controllers/Api/MaterialController.php:19
 * @route '/api/main-quests/{mainQuest}/materials'
 */
export const store = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/main-quests/{mainQuest}/materials',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\MaterialController::store
 * @see app/Http/Controllers/Api/MaterialController.php:19
 * @route '/api/main-quests/{mainQuest}/materials'
 */
store.url = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { mainQuest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'main_quests_id' in args) {
            args = { mainQuest: args.main_quests_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    mainQuest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        mainQuest: typeof args.mainQuest === 'object'
                ? args.mainQuest.main_quests_id
                : args.mainQuest,
                }

    return store.definition.url
            .replace('{mainQuest}', parsedArgs.mainQuest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\MaterialController::store
 * @see app/Http/Controllers/Api/MaterialController.php:19
 * @route '/api/main-quests/{mainQuest}/materials'
 */
store.post = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\MaterialController::store
 * @see app/Http/Controllers/Api/MaterialController.php:19
 * @route '/api/main-quests/{mainQuest}/materials'
 */
    const storeForm = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\MaterialController::store
 * @see app/Http/Controllers/Api/MaterialController.php:19
 * @route '/api/main-quests/{mainQuest}/materials'
 */
        storeForm.post = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\MaterialController::updateProgress
 * @see app/Http/Controllers/Api/MaterialController.php:68
 * @route '/api/materials/{material}/progress'
 */
export const updateProgress = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateProgress.url(args, options),
    method: 'post',
})

updateProgress.definition = {
    methods: ["post"],
    url: '/api/materials/{material}/progress',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\MaterialController::updateProgress
 * @see app/Http/Controllers/Api/MaterialController.php:68
 * @route '/api/materials/{material}/progress'
 */
updateProgress.url = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { material: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'materials_id' in args) {
            args = { material: args.materials_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    material: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        material: typeof args.material === 'object'
                ? args.material.materials_id
                : args.material,
                }

    return updateProgress.definition.url
            .replace('{material}', parsedArgs.material.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\MaterialController::updateProgress
 * @see app/Http/Controllers/Api/MaterialController.php:68
 * @route '/api/materials/{material}/progress'
 */
updateProgress.post = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateProgress.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\MaterialController::updateProgress
 * @see app/Http/Controllers/Api/MaterialController.php:68
 * @route '/api/materials/{material}/progress'
 */
    const updateProgressForm = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateProgress.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\MaterialController::updateProgress
 * @see app/Http/Controllers/Api/MaterialController.php:68
 * @route '/api/materials/{material}/progress'
 */
        updateProgressForm.post = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateProgress.url(args, options),
            method: 'post',
        })
    
    updateProgress.form = updateProgressForm
const MaterialController = { show, store, updateProgress }

export default MaterialController