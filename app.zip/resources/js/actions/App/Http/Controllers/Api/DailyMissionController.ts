import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\DailyMissionController::index
 * @see app/Http/Controllers/Api/DailyMissionController.php:23
 * @route '/api/communities/{community}/daily-missions'
 */
export const index = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/communities/{community}/daily-missions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\DailyMissionController::index
 * @see app/Http/Controllers/Api/DailyMissionController.php:23
 * @route '/api/communities/{community}/daily-missions'
 */
index.url = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { community: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'communities_id' in args) {
            args = { community: args.communities_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    community: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        community: typeof args.community === 'object'
                ? args.community.communities_id
                : args.community,
                }

    return index.definition.url
            .replace('{community}', parsedArgs.community.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DailyMissionController::index
 * @see app/Http/Controllers/Api/DailyMissionController.php:23
 * @route '/api/communities/{community}/daily-missions'
 */
index.get = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\DailyMissionController::index
 * @see app/Http/Controllers/Api/DailyMissionController.php:23
 * @route '/api/communities/{community}/daily-missions'
 */
index.head = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\DailyMissionController::index
 * @see app/Http/Controllers/Api/DailyMissionController.php:23
 * @route '/api/communities/{community}/daily-missions'
 */
    const indexForm = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\DailyMissionController::index
 * @see app/Http/Controllers/Api/DailyMissionController.php:23
 * @route '/api/communities/{community}/daily-missions'
 */
        indexForm.get = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\DailyMissionController::index
 * @see app/Http/Controllers/Api/DailyMissionController.php:23
 * @route '/api/communities/{community}/daily-missions'
 */
        indexForm.head = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\DailyMissionController::store
 * @see app/Http/Controllers/Api/DailyMissionController.php:52
 * @route '/api/communities/{community}/daily-missions'
 */
export const store = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/communities/{community}/daily-missions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\DailyMissionController::store
 * @see app/Http/Controllers/Api/DailyMissionController.php:52
 * @route '/api/communities/{community}/daily-missions'
 */
store.url = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { community: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'communities_id' in args) {
            args = { community: args.communities_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    community: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        community: typeof args.community === 'object'
                ? args.community.communities_id
                : args.community,
                }

    return store.definition.url
            .replace('{community}', parsedArgs.community.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DailyMissionController::store
 * @see app/Http/Controllers/Api/DailyMissionController.php:52
 * @route '/api/communities/{community}/daily-missions'
 */
store.post = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\DailyMissionController::store
 * @see app/Http/Controllers/Api/DailyMissionController.php:52
 * @route '/api/communities/{community}/daily-missions'
 */
    const storeForm = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\DailyMissionController::store
 * @see app/Http/Controllers/Api/DailyMissionController.php:52
 * @route '/api/communities/{community}/daily-missions'
 */
        storeForm.post = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\DailyMissionController::complete
 * @see app/Http/Controllers/Api/DailyMissionController.php:86
 * @route '/api/daily-missions/{mission}/complete'
 */
export const complete = (args: { mission: number | { daily_missions_id: number } } | [mission: number | { daily_missions_id: number } ] | number | { daily_missions_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: complete.url(args, options),
    method: 'post',
})

complete.definition = {
    methods: ["post"],
    url: '/api/daily-missions/{mission}/complete',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\DailyMissionController::complete
 * @see app/Http/Controllers/Api/DailyMissionController.php:86
 * @route '/api/daily-missions/{mission}/complete'
 */
complete.url = (args: { mission: number | { daily_missions_id: number } } | [mission: number | { daily_missions_id: number } ] | number | { daily_missions_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { mission: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'daily_missions_id' in args) {
            args = { mission: args.daily_missions_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    mission: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        mission: typeof args.mission === 'object'
                ? args.mission.daily_missions_id
                : args.mission,
                }

    return complete.definition.url
            .replace('{mission}', parsedArgs.mission.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\DailyMissionController::complete
 * @see app/Http/Controllers/Api/DailyMissionController.php:86
 * @route '/api/daily-missions/{mission}/complete'
 */
complete.post = (args: { mission: number | { daily_missions_id: number } } | [mission: number | { daily_missions_id: number } ] | number | { daily_missions_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: complete.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\DailyMissionController::complete
 * @see app/Http/Controllers/Api/DailyMissionController.php:86
 * @route '/api/daily-missions/{mission}/complete'
 */
    const completeForm = (args: { mission: number | { daily_missions_id: number } } | [mission: number | { daily_missions_id: number } ] | number | { daily_missions_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: complete.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\DailyMissionController::complete
 * @see app/Http/Controllers/Api/DailyMissionController.php:86
 * @route '/api/daily-missions/{mission}/complete'
 */
        completeForm.post = (args: { mission: number | { daily_missions_id: number } } | [mission: number | { daily_missions_id: number } ] | number | { daily_missions_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: complete.url(args, options),
            method: 'post',
        })
    
    complete.form = completeForm
const DailyMissionController = { index, store, complete }

export default DailyMissionController