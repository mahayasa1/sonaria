import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\Admin\AchievementController::index
 * @see app/Http/Controllers/Api/Admin/AchievementController.php:14
 * @route '/api/admin/achievements'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/admin/achievements',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\Admin\AchievementController::index
 * @see app/Http/Controllers/Api/Admin/AchievementController.php:14
 * @route '/api/admin/achievements'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\AchievementController::index
 * @see app/Http/Controllers/Api/Admin/AchievementController.php:14
 * @route '/api/admin/achievements'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\Admin\AchievementController::index
 * @see app/Http/Controllers/Api/Admin/AchievementController.php:14
 * @route '/api/admin/achievements'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\Admin\AchievementController::index
 * @see app/Http/Controllers/Api/Admin/AchievementController.php:14
 * @route '/api/admin/achievements'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\AchievementController::index
 * @see app/Http/Controllers/Api/Admin/AchievementController.php:14
 * @route '/api/admin/achievements'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\Admin\AchievementController::index
 * @see app/Http/Controllers/Api/Admin/AchievementController.php:14
 * @route '/api/admin/achievements'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\Admin\AchievementController::store
 * @see app/Http/Controllers/Api/Admin/AchievementController.php:23
 * @route '/api/admin/achievements'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/admin/achievements',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Admin\AchievementController::store
 * @see app/Http/Controllers/Api/Admin/AchievementController.php:23
 * @route '/api/admin/achievements'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\AchievementController::store
 * @see app/Http/Controllers/Api/Admin/AchievementController.php:23
 * @route '/api/admin/achievements'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Admin\AchievementController::store
 * @see app/Http/Controllers/Api/Admin/AchievementController.php:23
 * @route '/api/admin/achievements'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\AchievementController::store
 * @see app/Http/Controllers/Api/Admin/AchievementController.php:23
 * @route '/api/admin/achievements'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\Admin\AchievementController::update
 * @see app/Http/Controllers/Api/Admin/AchievementController.php:40
 * @route '/api/admin/achievements/{achievement}'
 */
export const update = (args: { achievement: number | { achievements_id: number } } | [achievement: number | { achievements_id: number } ] | number | { achievements_id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/admin/achievements/{achievement}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\Admin\AchievementController::update
 * @see app/Http/Controllers/Api/Admin/AchievementController.php:40
 * @route '/api/admin/achievements/{achievement}'
 */
update.url = (args: { achievement: number | { achievements_id: number } } | [achievement: number | { achievements_id: number } ] | number | { achievements_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { achievement: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'achievements_id' in args) {
            args = { achievement: args.achievements_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    achievement: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        achievement: typeof args.achievement === 'object'
                ? args.achievement.achievements_id
                : args.achievement,
                }

    return update.definition.url
            .replace('{achievement}', parsedArgs.achievement.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\AchievementController::update
 * @see app/Http/Controllers/Api/Admin/AchievementController.php:40
 * @route '/api/admin/achievements/{achievement}'
 */
update.put = (args: { achievement: number | { achievements_id: number } } | [achievement: number | { achievements_id: number } ] | number | { achievements_id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Api\Admin\AchievementController::update
 * @see app/Http/Controllers/Api/Admin/AchievementController.php:40
 * @route '/api/admin/achievements/{achievement}'
 */
    const updateForm = (args: { achievement: number | { achievements_id: number } } | [achievement: number | { achievements_id: number } ] | number | { achievements_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\AchievementController::update
 * @see app/Http/Controllers/Api/Admin/AchievementController.php:40
 * @route '/api/admin/achievements/{achievement}'
 */
        updateForm.put = (args: { achievement: number | { achievements_id: number } } | [achievement: number | { achievements_id: number } ] | number | { achievements_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Api\Admin\AchievementController::destroy
 * @see app/Http/Controllers/Api/Admin/AchievementController.php:57
 * @route '/api/admin/achievements/{achievement}'
 */
export const destroy = (args: { achievement: number | { achievements_id: number } } | [achievement: number | { achievements_id: number } ] | number | { achievements_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/admin/achievements/{achievement}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\Admin\AchievementController::destroy
 * @see app/Http/Controllers/Api/Admin/AchievementController.php:57
 * @route '/api/admin/achievements/{achievement}'
 */
destroy.url = (args: { achievement: number | { achievements_id: number } } | [achievement: number | { achievements_id: number } ] | number | { achievements_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { achievement: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'achievements_id' in args) {
            args = { achievement: args.achievements_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    achievement: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        achievement: typeof args.achievement === 'object'
                ? args.achievement.achievements_id
                : args.achievement,
                }

    return destroy.definition.url
            .replace('{achievement}', parsedArgs.achievement.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\AchievementController::destroy
 * @see app/Http/Controllers/Api/Admin/AchievementController.php:57
 * @route '/api/admin/achievements/{achievement}'
 */
destroy.delete = (args: { achievement: number | { achievements_id: number } } | [achievement: number | { achievements_id: number } ] | number | { achievements_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Api\Admin\AchievementController::destroy
 * @see app/Http/Controllers/Api/Admin/AchievementController.php:57
 * @route '/api/admin/achievements/{achievement}'
 */
    const destroyForm = (args: { achievement: number | { achievements_id: number } } | [achievement: number | { achievements_id: number } ] | number | { achievements_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\AchievementController::destroy
 * @see app/Http/Controllers/Api/Admin/AchievementController.php:57
 * @route '/api/admin/achievements/{achievement}'
 */
        destroyForm.delete = (args: { achievement: number | { achievements_id: number } } | [achievement: number | { achievements_id: number } ] | number | { achievements_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const AchievementController = { index, store, update, destroy }

export default AchievementController