import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\Admin\MusicCategoryController::index
 * @see app/Http/Controllers/Api/Admin/MusicCategoryController.php:14
 * @route '/api/admin/categories'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/admin/categories',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\Admin\MusicCategoryController::index
 * @see app/Http/Controllers/Api/Admin/MusicCategoryController.php:14
 * @route '/api/admin/categories'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\MusicCategoryController::index
 * @see app/Http/Controllers/Api/Admin/MusicCategoryController.php:14
 * @route '/api/admin/categories'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\Admin\MusicCategoryController::index
 * @see app/Http/Controllers/Api/Admin/MusicCategoryController.php:14
 * @route '/api/admin/categories'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\Admin\MusicCategoryController::index
 * @see app/Http/Controllers/Api/Admin/MusicCategoryController.php:14
 * @route '/api/admin/categories'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\MusicCategoryController::index
 * @see app/Http/Controllers/Api/Admin/MusicCategoryController.php:14
 * @route '/api/admin/categories'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\Admin\MusicCategoryController::index
 * @see app/Http/Controllers/Api/Admin/MusicCategoryController.php:14
 * @route '/api/admin/categories'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\Admin\MusicCategoryController::store
 * @see app/Http/Controllers/Api/Admin/MusicCategoryController.php:26
 * @route '/api/admin/categories'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/admin/categories',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Admin\MusicCategoryController::store
 * @see app/Http/Controllers/Api/Admin/MusicCategoryController.php:26
 * @route '/api/admin/categories'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\MusicCategoryController::store
 * @see app/Http/Controllers/Api/Admin/MusicCategoryController.php:26
 * @route '/api/admin/categories'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Admin\MusicCategoryController::store
 * @see app/Http/Controllers/Api/Admin/MusicCategoryController.php:26
 * @route '/api/admin/categories'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\MusicCategoryController::store
 * @see app/Http/Controllers/Api/Admin/MusicCategoryController.php:26
 * @route '/api/admin/categories'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\Admin\MusicCategoryController::update
 * @see app/Http/Controllers/Api/Admin/MusicCategoryController.php:41
 * @route '/api/admin/categories/{category}'
 */
export const update = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/admin/categories/{category}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\Admin\MusicCategoryController::update
 * @see app/Http/Controllers/Api/Admin/MusicCategoryController.php:41
 * @route '/api/admin/categories/{category}'
 */
update.url = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'music_categories_id' in args) {
            args = { category: args.music_categories_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    category: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        category: typeof args.category === 'object'
                ? args.category.music_categories_id
                : args.category,
                }

    return update.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\MusicCategoryController::update
 * @see app/Http/Controllers/Api/Admin/MusicCategoryController.php:41
 * @route '/api/admin/categories/{category}'
 */
update.put = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Api\Admin\MusicCategoryController::update
 * @see app/Http/Controllers/Api/Admin/MusicCategoryController.php:41
 * @route '/api/admin/categories/{category}'
 */
    const updateForm = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\MusicCategoryController::update
 * @see app/Http/Controllers/Api/Admin/MusicCategoryController.php:41
 * @route '/api/admin/categories/{category}'
 */
        updateForm.put = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Api\Admin\MusicCategoryController::destroy
 * @see app/Http/Controllers/Api/Admin/MusicCategoryController.php:56
 * @route '/api/admin/categories/{category}'
 */
export const destroy = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/admin/categories/{category}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\Admin\MusicCategoryController::destroy
 * @see app/Http/Controllers/Api/Admin/MusicCategoryController.php:56
 * @route '/api/admin/categories/{category}'
 */
destroy.url = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'music_categories_id' in args) {
            args = { category: args.music_categories_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    category: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        category: typeof args.category === 'object'
                ? args.category.music_categories_id
                : args.category,
                }

    return destroy.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\MusicCategoryController::destroy
 * @see app/Http/Controllers/Api/Admin/MusicCategoryController.php:56
 * @route '/api/admin/categories/{category}'
 */
destroy.delete = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Api\Admin\MusicCategoryController::destroy
 * @see app/Http/Controllers/Api/Admin/MusicCategoryController.php:56
 * @route '/api/admin/categories/{category}'
 */
    const destroyForm = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\MusicCategoryController::destroy
 * @see app/Http/Controllers/Api/Admin/MusicCategoryController.php:56
 * @route '/api/admin/categories/{category}'
 */
        destroyForm.delete = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Api\Admin\MusicCategoryController::storeInstrument
 * @see app/Http/Controllers/Api/Admin/MusicCategoryController.php:75
 * @route '/api/admin/categories/{category}/instruments'
 */
export const storeInstrument = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeInstrument.url(args, options),
    method: 'post',
})

storeInstrument.definition = {
    methods: ["post"],
    url: '/api/admin/categories/{category}/instruments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Admin\MusicCategoryController::storeInstrument
 * @see app/Http/Controllers/Api/Admin/MusicCategoryController.php:75
 * @route '/api/admin/categories/{category}/instruments'
 */
storeInstrument.url = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'music_categories_id' in args) {
            args = { category: args.music_categories_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    category: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        category: typeof args.category === 'object'
                ? args.category.music_categories_id
                : args.category,
                }

    return storeInstrument.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\MusicCategoryController::storeInstrument
 * @see app/Http/Controllers/Api/Admin/MusicCategoryController.php:75
 * @route '/api/admin/categories/{category}/instruments'
 */
storeInstrument.post = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeInstrument.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Admin\MusicCategoryController::storeInstrument
 * @see app/Http/Controllers/Api/Admin/MusicCategoryController.php:75
 * @route '/api/admin/categories/{category}/instruments'
 */
    const storeInstrumentForm = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeInstrument.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\MusicCategoryController::storeInstrument
 * @see app/Http/Controllers/Api/Admin/MusicCategoryController.php:75
 * @route '/api/admin/categories/{category}/instruments'
 */
        storeInstrumentForm.post = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeInstrument.url(args, options),
            method: 'post',
        })
    
    storeInstrument.form = storeInstrumentForm
/**
* @see \App\Http\Controllers\Api\Admin\MusicCategoryController::destroyInstrument
 * @see app/Http/Controllers/Api/Admin/MusicCategoryController.php:90
 * @route '/api/admin/instruments/{instrument}'
 */
export const destroyInstrument = (args: { instrument: number | { intruments_id: number } } | [instrument: number | { intruments_id: number } ] | number | { intruments_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyInstrument.url(args, options),
    method: 'delete',
})

destroyInstrument.definition = {
    methods: ["delete"],
    url: '/api/admin/instruments/{instrument}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\Admin\MusicCategoryController::destroyInstrument
 * @see app/Http/Controllers/Api/Admin/MusicCategoryController.php:90
 * @route '/api/admin/instruments/{instrument}'
 */
destroyInstrument.url = (args: { instrument: number | { intruments_id: number } } | [instrument: number | { intruments_id: number } ] | number | { intruments_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { instrument: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'intruments_id' in args) {
            args = { instrument: args.intruments_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    instrument: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        instrument: typeof args.instrument === 'object'
                ? args.instrument.intruments_id
                : args.instrument,
                }

    return destroyInstrument.definition.url
            .replace('{instrument}', parsedArgs.instrument.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\MusicCategoryController::destroyInstrument
 * @see app/Http/Controllers/Api/Admin/MusicCategoryController.php:90
 * @route '/api/admin/instruments/{instrument}'
 */
destroyInstrument.delete = (args: { instrument: number | { intruments_id: number } } | [instrument: number | { intruments_id: number } ] | number | { intruments_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyInstrument.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Api\Admin\MusicCategoryController::destroyInstrument
 * @see app/Http/Controllers/Api/Admin/MusicCategoryController.php:90
 * @route '/api/admin/instruments/{instrument}'
 */
    const destroyInstrumentForm = (args: { instrument: number | { intruments_id: number } } | [instrument: number | { intruments_id: number } ] | number | { intruments_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyInstrument.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\MusicCategoryController::destroyInstrument
 * @see app/Http/Controllers/Api/Admin/MusicCategoryController.php:90
 * @route '/api/admin/instruments/{instrument}'
 */
        destroyInstrumentForm.delete = (args: { instrument: number | { intruments_id: number } } | [instrument: number | { intruments_id: number } ] | number | { intruments_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyInstrument.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyInstrument.form = destroyInstrumentForm
const MusicCategoryController = { index, store, update, destroy, storeInstrument, destroyInstrument }

export default MusicCategoryController