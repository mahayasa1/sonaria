import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\ForumCommentController::store
 * @see app/Http/Controllers/Api/ForumCommentController.php:16
 * @route '/api/forum-posts/{forumPost}/comments'
 */
export const store = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/forum-posts/{forumPost}/comments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\ForumCommentController::store
 * @see app/Http/Controllers/Api/ForumCommentController.php:16
 * @route '/api/forum-posts/{forumPost}/comments'
 */
store.url = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { forumPost: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'forum_posts_id' in args) {
            args = { forumPost: args.forum_posts_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    forumPost: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        forumPost: typeof args.forumPost === 'object'
                ? args.forumPost.forum_posts_id
                : args.forumPost,
                }

    return store.definition.url
            .replace('{forumPost}', parsedArgs.forumPost.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ForumCommentController::store
 * @see app/Http/Controllers/Api/ForumCommentController.php:16
 * @route '/api/forum-posts/{forumPost}/comments'
 */
store.post = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\ForumCommentController::store
 * @see app/Http/Controllers/Api/ForumCommentController.php:16
 * @route '/api/forum-posts/{forumPost}/comments'
 */
    const storeForm = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\ForumCommentController::store
 * @see app/Http/Controllers/Api/ForumCommentController.php:16
 * @route '/api/forum-posts/{forumPost}/comments'
 */
        storeForm.post = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\ForumCommentController::destroy
 * @see app/Http/Controllers/Api/ForumCommentController.php:34
 * @route '/api/forum-comments/{forumComment}'
 */
export const destroy = (args: { forumComment: number | { forum_comments_id: number } } | [forumComment: number | { forum_comments_id: number } ] | number | { forum_comments_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/forum-comments/{forumComment}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\ForumCommentController::destroy
 * @see app/Http/Controllers/Api/ForumCommentController.php:34
 * @route '/api/forum-comments/{forumComment}'
 */
destroy.url = (args: { forumComment: number | { forum_comments_id: number } } | [forumComment: number | { forum_comments_id: number } ] | number | { forum_comments_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { forumComment: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'forum_comments_id' in args) {
            args = { forumComment: args.forum_comments_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    forumComment: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        forumComment: typeof args.forumComment === 'object'
                ? args.forumComment.forum_comments_id
                : args.forumComment,
                }

    return destroy.definition.url
            .replace('{forumComment}', parsedArgs.forumComment.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ForumCommentController::destroy
 * @see app/Http/Controllers/Api/ForumCommentController.php:34
 * @route '/api/forum-comments/{forumComment}'
 */
destroy.delete = (args: { forumComment: number | { forum_comments_id: number } } | [forumComment: number | { forum_comments_id: number } ] | number | { forum_comments_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Api\ForumCommentController::destroy
 * @see app/Http/Controllers/Api/ForumCommentController.php:34
 * @route '/api/forum-comments/{forumComment}'
 */
    const destroyForm = (args: { forumComment: number | { forum_comments_id: number } } | [forumComment: number | { forum_comments_id: number } ] | number | { forum_comments_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\ForumCommentController::destroy
 * @see app/Http/Controllers/Api/ForumCommentController.php:34
 * @route '/api/forum-comments/{forumComment}'
 */
        destroyForm.delete = (args: { forumComment: number | { forum_comments_id: number } } | [forumComment: number | { forum_comments_id: number } ] | number | { forum_comments_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const ForumCommentController = { store, destroy }

export default ForumCommentController