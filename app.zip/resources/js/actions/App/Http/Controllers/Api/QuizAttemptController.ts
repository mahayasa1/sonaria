import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\QuizAttemptController::start
 * @see app/Http/Controllers/Api/QuizAttemptController.php:21
 * @route '/api/quizzes/{quiz}/attempts'
 */
export const start = (args: { quiz: number | { quizzes_id: number } } | [quiz: number | { quizzes_id: number } ] | number | { quizzes_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(args, options),
    method: 'post',
})

start.definition = {
    methods: ["post"],
    url: '/api/quizzes/{quiz}/attempts',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\QuizAttemptController::start
 * @see app/Http/Controllers/Api/QuizAttemptController.php:21
 * @route '/api/quizzes/{quiz}/attempts'
 */
start.url = (args: { quiz: number | { quizzes_id: number } } | [quiz: number | { quizzes_id: number } ] | number | { quizzes_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { quiz: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'quizzes_id' in args) {
            args = { quiz: args.quizzes_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    quiz: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        quiz: typeof args.quiz === 'object'
                ? args.quiz.quizzes_id
                : args.quiz,
                }

    return start.definition.url
            .replace('{quiz}', parsedArgs.quiz.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\QuizAttemptController::start
 * @see app/Http/Controllers/Api/QuizAttemptController.php:21
 * @route '/api/quizzes/{quiz}/attempts'
 */
start.post = (args: { quiz: number | { quizzes_id: number } } | [quiz: number | { quizzes_id: number } ] | number | { quizzes_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: start.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\QuizAttemptController::start
 * @see app/Http/Controllers/Api/QuizAttemptController.php:21
 * @route '/api/quizzes/{quiz}/attempts'
 */
    const startForm = (args: { quiz: number | { quizzes_id: number } } | [quiz: number | { quizzes_id: number } ] | number | { quizzes_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: start.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\QuizAttemptController::start
 * @see app/Http/Controllers/Api/QuizAttemptController.php:21
 * @route '/api/quizzes/{quiz}/attempts'
 */
        startForm.post = (args: { quiz: number | { quizzes_id: number } } | [quiz: number | { quizzes_id: number } ] | number | { quizzes_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: start.url(args, options),
            method: 'post',
        })
    
    start.form = startForm
/**
* @see \App\Http\Controllers\Api\QuizAttemptController::submit
 * @see app/Http/Controllers/Api/QuizAttemptController.php:36
 * @route '/api/quiz-attempts/{attempt}/submit'
 */
export const submit = (args: { attempt: number | { quiz_attempts_id: number } } | [attempt: number | { quiz_attempts_id: number } ] | number | { quiz_attempts_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(args, options),
    method: 'post',
})

submit.definition = {
    methods: ["post"],
    url: '/api/quiz-attempts/{attempt}/submit',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\QuizAttemptController::submit
 * @see app/Http/Controllers/Api/QuizAttemptController.php:36
 * @route '/api/quiz-attempts/{attempt}/submit'
 */
submit.url = (args: { attempt: number | { quiz_attempts_id: number } } | [attempt: number | { quiz_attempts_id: number } ] | number | { quiz_attempts_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { attempt: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'quiz_attempts_id' in args) {
            args = { attempt: args.quiz_attempts_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    attempt: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        attempt: typeof args.attempt === 'object'
                ? args.attempt.quiz_attempts_id
                : args.attempt,
                }

    return submit.definition.url
            .replace('{attempt}', parsedArgs.attempt.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\QuizAttemptController::submit
 * @see app/Http/Controllers/Api/QuizAttemptController.php:36
 * @route '/api/quiz-attempts/{attempt}/submit'
 */
submit.post = (args: { attempt: number | { quiz_attempts_id: number } } | [attempt: number | { quiz_attempts_id: number } ] | number | { quiz_attempts_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: submit.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\QuizAttemptController::submit
 * @see app/Http/Controllers/Api/QuizAttemptController.php:36
 * @route '/api/quiz-attempts/{attempt}/submit'
 */
    const submitForm = (args: { attempt: number | { quiz_attempts_id: number } } | [attempt: number | { quiz_attempts_id: number } ] | number | { quiz_attempts_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: submit.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\QuizAttemptController::submit
 * @see app/Http/Controllers/Api/QuizAttemptController.php:36
 * @route '/api/quiz-attempts/{attempt}/submit'
 */
        submitForm.post = (args: { attempt: number | { quiz_attempts_id: number } } | [attempt: number | { quiz_attempts_id: number } ] | number | { quiz_attempts_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: submit.url(args, options),
            method: 'post',
        })
    
    submit.form = submitForm
const QuizAttemptController = { start, submit }

export default QuizAttemptController