import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\MainQuestController::index
 * @see app/Http/Controllers/Api/MainQuestController.php:18
 * @route '/api/communities/{community}/main-quests'
 */
export const index = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/communities/{community}/main-quests',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\MainQuestController::index
 * @see app/Http/Controllers/Api/MainQuestController.php:18
 * @route '/api/communities/{community}/main-quests'
 */
index.url = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { community: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'communities_id' in args) {
            args = { community: args.communities_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    community: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        community: typeof args.community === 'object'
                ? args.community.communities_id
                : args.community,
                }

    return index.definition.url
            .replace('{community}', parsedArgs.community.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\MainQuestController::index
 * @see app/Http/Controllers/Api/MainQuestController.php:18
 * @route '/api/communities/{community}/main-quests'
 */
index.get = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\MainQuestController::index
 * @see app/Http/Controllers/Api/MainQuestController.php:18
 * @route '/api/communities/{community}/main-quests'
 */
index.head = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\MainQuestController::index
 * @see app/Http/Controllers/Api/MainQuestController.php:18
 * @route '/api/communities/{community}/main-quests'
 */
    const indexForm = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\MainQuestController::index
 * @see app/Http/Controllers/Api/MainQuestController.php:18
 * @route '/api/communities/{community}/main-quests'
 */
        indexForm.get = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\MainQuestController::index
 * @see app/Http/Controllers/Api/MainQuestController.php:18
 * @route '/api/communities/{community}/main-quests'
 */
        indexForm.head = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\MainQuestController::store
 * @see app/Http/Controllers/Api/MainQuestController.php:46
 * @route '/api/communities/{community}/main-quests'
 */
export const store = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/communities/{community}/main-quests',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\MainQuestController::store
 * @see app/Http/Controllers/Api/MainQuestController.php:46
 * @route '/api/communities/{community}/main-quests'
 */
store.url = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { community: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'communities_id' in args) {
            args = { community: args.communities_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    community: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        community: typeof args.community === 'object'
                ? args.community.communities_id
                : args.community,
                }

    return store.definition.url
            .replace('{community}', parsedArgs.community.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\MainQuestController::store
 * @see app/Http/Controllers/Api/MainQuestController.php:46
 * @route '/api/communities/{community}/main-quests'
 */
store.post = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\MainQuestController::store
 * @see app/Http/Controllers/Api/MainQuestController.php:46
 * @route '/api/communities/{community}/main-quests'
 */
    const storeForm = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\MainQuestController::store
 * @see app/Http/Controllers/Api/MainQuestController.php:46
 * @route '/api/communities/{community}/main-quests'
 */
        storeForm.post = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\MainQuestController::show
 * @see app/Http/Controllers/Api/MainQuestController.php:35
 * @route '/api/main-quests/{mainQuest}'
 */
export const show = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/main-quests/{mainQuest}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\MainQuestController::show
 * @see app/Http/Controllers/Api/MainQuestController.php:35
 * @route '/api/main-quests/{mainQuest}'
 */
show.url = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { mainQuest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'main_quests_id' in args) {
            args = { mainQuest: args.main_quests_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    mainQuest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        mainQuest: typeof args.mainQuest === 'object'
                ? args.mainQuest.main_quests_id
                : args.mainQuest,
                }

    return show.definition.url
            .replace('{mainQuest}', parsedArgs.mainQuest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\MainQuestController::show
 * @see app/Http/Controllers/Api/MainQuestController.php:35
 * @route '/api/main-quests/{mainQuest}'
 */
show.get = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\MainQuestController::show
 * @see app/Http/Controllers/Api/MainQuestController.php:35
 * @route '/api/main-quests/{mainQuest}'
 */
show.head = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\MainQuestController::show
 * @see app/Http/Controllers/Api/MainQuestController.php:35
 * @route '/api/main-quests/{mainQuest}'
 */
    const showForm = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\MainQuestController::show
 * @see app/Http/Controllers/Api/MainQuestController.php:35
 * @route '/api/main-quests/{mainQuest}'
 */
        showForm.get = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\MainQuestController::show
 * @see app/Http/Controllers/Api/MainQuestController.php:35
 * @route '/api/main-quests/{mainQuest}'
 */
        showForm.head = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const MainQuestController = { index, store, show }

export default MainQuestController