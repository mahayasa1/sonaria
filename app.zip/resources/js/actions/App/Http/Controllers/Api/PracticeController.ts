import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\PracticeController::show
 * @see app/Http/Controllers/Api/PracticeController.php:40
 * @route '/api/practices/{practice}'
 */
export const show = (args: { practice: number | { practices_id: number } } | [practice: number | { practices_id: number } ] | number | { practices_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/practices/{practice}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\PracticeController::show
 * @see app/Http/Controllers/Api/PracticeController.php:40
 * @route '/api/practices/{practice}'
 */
show.url = (args: { practice: number | { practices_id: number } } | [practice: number | { practices_id: number } ] | number | { practices_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { practice: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'practices_id' in args) {
            args = { practice: args.practices_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    practice: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        practice: typeof args.practice === 'object'
                ? args.practice.practices_id
                : args.practice,
                }

    return show.definition.url
            .replace('{practice}', parsedArgs.practice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\PracticeController::show
 * @see app/Http/Controllers/Api/PracticeController.php:40
 * @route '/api/practices/{practice}'
 */
show.get = (args: { practice: number | { practices_id: number } } | [practice: number | { practices_id: number } ] | number | { practices_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\PracticeController::show
 * @see app/Http/Controllers/Api/PracticeController.php:40
 * @route '/api/practices/{practice}'
 */
show.head = (args: { practice: number | { practices_id: number } } | [practice: number | { practices_id: number } ] | number | { practices_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\PracticeController::show
 * @see app/Http/Controllers/Api/PracticeController.php:40
 * @route '/api/practices/{practice}'
 */
    const showForm = (args: { practice: number | { practices_id: number } } | [practice: number | { practices_id: number } ] | number | { practices_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\PracticeController::show
 * @see app/Http/Controllers/Api/PracticeController.php:40
 * @route '/api/practices/{practice}'
 */
        showForm.get = (args: { practice: number | { practices_id: number } } | [practice: number | { practices_id: number } ] | number | { practices_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\PracticeController::show
 * @see app/Http/Controllers/Api/PracticeController.php:40
 * @route '/api/practices/{practice}'
 */
        showForm.head = (args: { practice: number | { practices_id: number } } | [practice: number | { practices_id: number } ] | number | { practices_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\PracticeController::store
 * @see app/Http/Controllers/Api/PracticeController.php:16
 * @route '/api/materials/{material}/practices'
 */
export const store = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/materials/{material}/practices',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\PracticeController::store
 * @see app/Http/Controllers/Api/PracticeController.php:16
 * @route '/api/materials/{material}/practices'
 */
store.url = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { material: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'materials_id' in args) {
            args = { material: args.materials_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    material: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        material: typeof args.material === 'object'
                ? args.material.materials_id
                : args.material,
                }

    return store.definition.url
            .replace('{material}', parsedArgs.material.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\PracticeController::store
 * @see app/Http/Controllers/Api/PracticeController.php:16
 * @route '/api/materials/{material}/practices'
 */
store.post = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\PracticeController::store
 * @see app/Http/Controllers/Api/PracticeController.php:16
 * @route '/api/materials/{material}/practices'
 */
    const storeForm = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\PracticeController::store
 * @see app/Http/Controllers/Api/PracticeController.php:16
 * @route '/api/materials/{material}/practices'
 */
        storeForm.post = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
const PracticeController = { show, store }

export default PracticeController