import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\Admin\RoleController::index
 * @see app/Http/Controllers/Api/Admin/RoleController.php:14
 * @route '/api/admin/roles'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/admin/roles',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\Admin\RoleController::index
 * @see app/Http/Controllers/Api/Admin/RoleController.php:14
 * @route '/api/admin/roles'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\RoleController::index
 * @see app/Http/Controllers/Api/Admin/RoleController.php:14
 * @route '/api/admin/roles'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\Admin\RoleController::index
 * @see app/Http/Controllers/Api/Admin/RoleController.php:14
 * @route '/api/admin/roles'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\Admin\RoleController::index
 * @see app/Http/Controllers/Api/Admin/RoleController.php:14
 * @route '/api/admin/roles'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\RoleController::index
 * @see app/Http/Controllers/Api/Admin/RoleController.php:14
 * @route '/api/admin/roles'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\Admin\RoleController::index
 * @see app/Http/Controllers/Api/Admin/RoleController.php:14
 * @route '/api/admin/roles'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\Admin\RoleController::store
 * @see app/Http/Controllers/Api/Admin/RoleController.php:23
 * @route '/api/admin/roles'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/admin/roles',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Admin\RoleController::store
 * @see app/Http/Controllers/Api/Admin/RoleController.php:23
 * @route '/api/admin/roles'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\RoleController::store
 * @see app/Http/Controllers/Api/Admin/RoleController.php:23
 * @route '/api/admin/roles'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Admin\RoleController::store
 * @see app/Http/Controllers/Api/Admin/RoleController.php:23
 * @route '/api/admin/roles'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\RoleController::store
 * @see app/Http/Controllers/Api/Admin/RoleController.php:23
 * @route '/api/admin/roles'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\Admin\RoleController::update
 * @see app/Http/Controllers/Api/Admin/RoleController.php:37
 * @route '/api/admin/roles/{role}'
 */
export const update = (args: { role: number | { role_id: number } } | [role: number | { role_id: number } ] | number | { role_id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/admin/roles/{role}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\Admin\RoleController::update
 * @see app/Http/Controllers/Api/Admin/RoleController.php:37
 * @route '/api/admin/roles/{role}'
 */
update.url = (args: { role: number | { role_id: number } } | [role: number | { role_id: number } ] | number | { role_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { role: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'role_id' in args) {
            args = { role: args.role_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    role: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        role: typeof args.role === 'object'
                ? args.role.role_id
                : args.role,
                }

    return update.definition.url
            .replace('{role}', parsedArgs.role.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\RoleController::update
 * @see app/Http/Controllers/Api/Admin/RoleController.php:37
 * @route '/api/admin/roles/{role}'
 */
update.put = (args: { role: number | { role_id: number } } | [role: number | { role_id: number } ] | number | { role_id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Api\Admin\RoleController::update
 * @see app/Http/Controllers/Api/Admin/RoleController.php:37
 * @route '/api/admin/roles/{role}'
 */
    const updateForm = (args: { role: number | { role_id: number } } | [role: number | { role_id: number } ] | number | { role_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\RoleController::update
 * @see app/Http/Controllers/Api/Admin/RoleController.php:37
 * @route '/api/admin/roles/{role}'
 */
        updateForm.put = (args: { role: number | { role_id: number } } | [role: number | { role_id: number } ] | number | { role_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Api\Admin\RoleController::destroy
 * @see app/Http/Controllers/Api/Admin/RoleController.php:51
 * @route '/api/admin/roles/{role}'
 */
export const destroy = (args: { role: number | { role_id: number } } | [role: number | { role_id: number } ] | number | { role_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/admin/roles/{role}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\Admin\RoleController::destroy
 * @see app/Http/Controllers/Api/Admin/RoleController.php:51
 * @route '/api/admin/roles/{role}'
 */
destroy.url = (args: { role: number | { role_id: number } } | [role: number | { role_id: number } ] | number | { role_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { role: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'role_id' in args) {
            args = { role: args.role_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    role: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        role: typeof args.role === 'object'
                ? args.role.role_id
                : args.role,
                }

    return destroy.definition.url
            .replace('{role}', parsedArgs.role.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\RoleController::destroy
 * @see app/Http/Controllers/Api/Admin/RoleController.php:51
 * @route '/api/admin/roles/{role}'
 */
destroy.delete = (args: { role: number | { role_id: number } } | [role: number | { role_id: number } ] | number | { role_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Api\Admin\RoleController::destroy
 * @see app/Http/Controllers/Api/Admin/RoleController.php:51
 * @route '/api/admin/roles/{role}'
 */
    const destroyForm = (args: { role: number | { role_id: number } } | [role: number | { role_id: number } ] | number | { role_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\RoleController::destroy
 * @see app/Http/Controllers/Api/Admin/RoleController.php:51
 * @route '/api/admin/roles/{role}'
 */
        destroyForm.delete = (args: { role: number | { role_id: number } } | [role: number | { role_id: number } ] | number | { role_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const RoleController = { index, store, update, destroy }

export default RoleController