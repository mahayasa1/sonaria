import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\ForumPostController::index
 * @see app/Http/Controllers/Api/ForumPostController.php:16
 * @route '/api/communities/{community}/forum-posts'
 */
export const index = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/communities/{community}/forum-posts',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ForumPostController::index
 * @see app/Http/Controllers/Api/ForumPostController.php:16
 * @route '/api/communities/{community}/forum-posts'
 */
index.url = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { community: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'communities_id' in args) {
            args = { community: args.communities_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    community: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        community: typeof args.community === 'object'
                ? args.community.communities_id
                : args.community,
                }

    return index.definition.url
            .replace('{community}', parsedArgs.community.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ForumPostController::index
 * @see app/Http/Controllers/Api/ForumPostController.php:16
 * @route '/api/communities/{community}/forum-posts'
 */
index.get = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\ForumPostController::index
 * @see app/Http/Controllers/Api/ForumPostController.php:16
 * @route '/api/communities/{community}/forum-posts'
 */
index.head = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\ForumPostController::index
 * @see app/Http/Controllers/Api/ForumPostController.php:16
 * @route '/api/communities/{community}/forum-posts'
 */
    const indexForm = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\ForumPostController::index
 * @see app/Http/Controllers/Api/ForumPostController.php:16
 * @route '/api/communities/{community}/forum-posts'
 */
        indexForm.get = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\ForumPostController::index
 * @see app/Http/Controllers/Api/ForumPostController.php:16
 * @route '/api/communities/{community}/forum-posts'
 */
        indexForm.head = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\ForumPostController::store
 * @see app/Http/Controllers/Api/ForumPostController.php:34
 * @route '/api/communities/{community}/forum-posts'
 */
export const store = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/communities/{community}/forum-posts',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\ForumPostController::store
 * @see app/Http/Controllers/Api/ForumPostController.php:34
 * @route '/api/communities/{community}/forum-posts'
 */
store.url = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { community: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'communities_id' in args) {
            args = { community: args.communities_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    community: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        community: typeof args.community === 'object'
                ? args.community.communities_id
                : args.community,
                }

    return store.definition.url
            .replace('{community}', parsedArgs.community.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ForumPostController::store
 * @see app/Http/Controllers/Api/ForumPostController.php:34
 * @route '/api/communities/{community}/forum-posts'
 */
store.post = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\ForumPostController::store
 * @see app/Http/Controllers/Api/ForumPostController.php:34
 * @route '/api/communities/{community}/forum-posts'
 */
    const storeForm = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\ForumPostController::store
 * @see app/Http/Controllers/Api/ForumPostController.php:34
 * @route '/api/communities/{community}/forum-posts'
 */
        storeForm.post = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\ForumPostController::show
 * @see app/Http/Controllers/Api/ForumPostController.php:27
 * @route '/api/forum-posts/{forumPost}'
 */
export const show = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/forum-posts/{forumPost}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ForumPostController::show
 * @see app/Http/Controllers/Api/ForumPostController.php:27
 * @route '/api/forum-posts/{forumPost}'
 */
show.url = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { forumPost: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'forum_posts_id' in args) {
            args = { forumPost: args.forum_posts_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    forumPost: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        forumPost: typeof args.forumPost === 'object'
                ? args.forumPost.forum_posts_id
                : args.forumPost,
                }

    return show.definition.url
            .replace('{forumPost}', parsedArgs.forumPost.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ForumPostController::show
 * @see app/Http/Controllers/Api/ForumPostController.php:27
 * @route '/api/forum-posts/{forumPost}'
 */
show.get = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\ForumPostController::show
 * @see app/Http/Controllers/Api/ForumPostController.php:27
 * @route '/api/forum-posts/{forumPost}'
 */
show.head = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\ForumPostController::show
 * @see app/Http/Controllers/Api/ForumPostController.php:27
 * @route '/api/forum-posts/{forumPost}'
 */
    const showForm = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\ForumPostController::show
 * @see app/Http/Controllers/Api/ForumPostController.php:27
 * @route '/api/forum-posts/{forumPost}'
 */
        showForm.get = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\ForumPostController::show
 * @see app/Http/Controllers/Api/ForumPostController.php:27
 * @route '/api/forum-posts/{forumPost}'
 */
        showForm.head = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\ForumPostController::update
 * @see app/Http/Controllers/Api/ForumPostController.php:53
 * @route '/api/forum-posts/{forumPost}'
 */
export const update = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/forum-posts/{forumPost}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\ForumPostController::update
 * @see app/Http/Controllers/Api/ForumPostController.php:53
 * @route '/api/forum-posts/{forumPost}'
 */
update.url = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { forumPost: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'forum_posts_id' in args) {
            args = { forumPost: args.forum_posts_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    forumPost: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        forumPost: typeof args.forumPost === 'object'
                ? args.forumPost.forum_posts_id
                : args.forumPost,
                }

    return update.definition.url
            .replace('{forumPost}', parsedArgs.forumPost.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ForumPostController::update
 * @see app/Http/Controllers/Api/ForumPostController.php:53
 * @route '/api/forum-posts/{forumPost}'
 */
update.put = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Api\ForumPostController::update
 * @see app/Http/Controllers/Api/ForumPostController.php:53
 * @route '/api/forum-posts/{forumPost}'
 */
    const updateForm = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\ForumPostController::update
 * @see app/Http/Controllers/Api/ForumPostController.php:53
 * @route '/api/forum-posts/{forumPost}'
 */
        updateForm.put = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Api\ForumPostController::destroy
 * @see app/Http/Controllers/Api/ForumPostController.php:68
 * @route '/api/forum-posts/{forumPost}'
 */
export const destroy = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/forum-posts/{forumPost}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\ForumPostController::destroy
 * @see app/Http/Controllers/Api/ForumPostController.php:68
 * @route '/api/forum-posts/{forumPost}'
 */
destroy.url = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { forumPost: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'forum_posts_id' in args) {
            args = { forumPost: args.forum_posts_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    forumPost: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        forumPost: typeof args.forumPost === 'object'
                ? args.forumPost.forum_posts_id
                : args.forumPost,
                }

    return destroy.definition.url
            .replace('{forumPost}', parsedArgs.forumPost.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ForumPostController::destroy
 * @see app/Http/Controllers/Api/ForumPostController.php:68
 * @route '/api/forum-posts/{forumPost}'
 */
destroy.delete = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Api\ForumPostController::destroy
 * @see app/Http/Controllers/Api/ForumPostController.php:68
 * @route '/api/forum-posts/{forumPost}'
 */
    const destroyForm = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\ForumPostController::destroy
 * @see app/Http/Controllers/Api/ForumPostController.php:68
 * @route '/api/forum-posts/{forumPost}'
 */
        destroyForm.delete = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\Api\ForumPostController::toggleLike
 * @see app/Http/Controllers/Api/ForumPostController.php:80
 * @route '/api/forum-posts/{forumPost}/like'
 */
export const toggleLike = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleLike.url(args, options),
    method: 'post',
})

toggleLike.definition = {
    methods: ["post"],
    url: '/api/forum-posts/{forumPost}/like',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\ForumPostController::toggleLike
 * @see app/Http/Controllers/Api/ForumPostController.php:80
 * @route '/api/forum-posts/{forumPost}/like'
 */
toggleLike.url = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { forumPost: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'forum_posts_id' in args) {
            args = { forumPost: args.forum_posts_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    forumPost: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        forumPost: typeof args.forumPost === 'object'
                ? args.forumPost.forum_posts_id
                : args.forumPost,
                }

    return toggleLike.definition.url
            .replace('{forumPost}', parsedArgs.forumPost.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ForumPostController::toggleLike
 * @see app/Http/Controllers/Api/ForumPostController.php:80
 * @route '/api/forum-posts/{forumPost}/like'
 */
toggleLike.post = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleLike.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\ForumPostController::toggleLike
 * @see app/Http/Controllers/Api/ForumPostController.php:80
 * @route '/api/forum-posts/{forumPost}/like'
 */
    const toggleLikeForm = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleLike.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\ForumPostController::toggleLike
 * @see app/Http/Controllers/Api/ForumPostController.php:80
 * @route '/api/forum-posts/{forumPost}/like'
 */
        toggleLikeForm.post = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleLike.url(args, options),
            method: 'post',
        })
    
    toggleLike.form = toggleLikeForm
const ForumPostController = { index, store, show, update, destroy, toggleLike }

export default ForumPostController