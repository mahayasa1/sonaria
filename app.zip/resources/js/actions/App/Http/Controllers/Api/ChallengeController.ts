import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\ChallengeController::index
 * @see app/Http/Controllers/Api/ChallengeController.php:17
 * @route '/api/communities/{community}/challenge'
 */
export const index = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/communities/{community}/challenge',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ChallengeController::index
 * @see app/Http/Controllers/Api/ChallengeController.php:17
 * @route '/api/communities/{community}/challenge'
 */
index.url = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { community: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'communities_id' in args) {
            args = { community: args.communities_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    community: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        community: typeof args.community === 'object'
                ? args.community.communities_id
                : args.community,
                }

    return index.definition.url
            .replace('{community}', parsedArgs.community.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ChallengeController::index
 * @see app/Http/Controllers/Api/ChallengeController.php:17
 * @route '/api/communities/{community}/challenge'
 */
index.get = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\ChallengeController::index
 * @see app/Http/Controllers/Api/ChallengeController.php:17
 * @route '/api/communities/{community}/challenge'
 */
index.head = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\ChallengeController::index
 * @see app/Http/Controllers/Api/ChallengeController.php:17
 * @route '/api/communities/{community}/challenge'
 */
    const indexForm = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\ChallengeController::index
 * @see app/Http/Controllers/Api/ChallengeController.php:17
 * @route '/api/communities/{community}/challenge'
 */
        indexForm.get = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\ChallengeController::index
 * @see app/Http/Controllers/Api/ChallengeController.php:17
 * @route '/api/communities/{community}/challenge'
 */
        indexForm.head = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\ChallengeController::store
 * @see app/Http/Controllers/Api/ChallengeController.php:36
 * @route '/api/communities/{community}/challenges'
 */
export const store = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/communities/{community}/challenges',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\ChallengeController::store
 * @see app/Http/Controllers/Api/ChallengeController.php:36
 * @route '/api/communities/{community}/challenges'
 */
store.url = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { community: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'communities_id' in args) {
            args = { community: args.communities_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    community: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        community: typeof args.community === 'object'
                ? args.community.communities_id
                : args.community,
                }

    return store.definition.url
            .replace('{community}', parsedArgs.community.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ChallengeController::store
 * @see app/Http/Controllers/Api/ChallengeController.php:36
 * @route '/api/communities/{community}/challenges'
 */
store.post = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\ChallengeController::store
 * @see app/Http/Controllers/Api/ChallengeController.php:36
 * @route '/api/communities/{community}/challenges'
 */
    const storeForm = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\ChallengeController::store
 * @see app/Http/Controllers/Api/ChallengeController.php:36
 * @route '/api/communities/{community}/challenges'
 */
        storeForm.post = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\ChallengeController::show
 * @see app/Http/Controllers/Api/ChallengeController.php:27
 * @route '/api/challenges/{challenge}'
 */
export const show = (args: { challenge: number | { challenges_id: number } } | [challenge: number | { challenges_id: number } ] | number | { challenges_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/challenges/{challenge}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ChallengeController::show
 * @see app/Http/Controllers/Api/ChallengeController.php:27
 * @route '/api/challenges/{challenge}'
 */
show.url = (args: { challenge: number | { challenges_id: number } } | [challenge: number | { challenges_id: number } ] | number | { challenges_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { challenge: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'challenges_id' in args) {
            args = { challenge: args.challenges_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    challenge: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        challenge: typeof args.challenge === 'object'
                ? args.challenge.challenges_id
                : args.challenge,
                }

    return show.definition.url
            .replace('{challenge}', parsedArgs.challenge.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ChallengeController::show
 * @see app/Http/Controllers/Api/ChallengeController.php:27
 * @route '/api/challenges/{challenge}'
 */
show.get = (args: { challenge: number | { challenges_id: number } } | [challenge: number | { challenges_id: number } ] | number | { challenges_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\ChallengeController::show
 * @see app/Http/Controllers/Api/ChallengeController.php:27
 * @route '/api/challenges/{challenge}'
 */
show.head = (args: { challenge: number | { challenges_id: number } } | [challenge: number | { challenges_id: number } ] | number | { challenges_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\ChallengeController::show
 * @see app/Http/Controllers/Api/ChallengeController.php:27
 * @route '/api/challenges/{challenge}'
 */
    const showForm = (args: { challenge: number | { challenges_id: number } } | [challenge: number | { challenges_id: number } ] | number | { challenges_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\ChallengeController::show
 * @see app/Http/Controllers/Api/ChallengeController.php:27
 * @route '/api/challenges/{challenge}'
 */
        showForm.get = (args: { challenge: number | { challenges_id: number } } | [challenge: number | { challenges_id: number } ] | number | { challenges_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\ChallengeController::show
 * @see app/Http/Controllers/Api/ChallengeController.php:27
 * @route '/api/challenges/{challenge}'
 */
        showForm.head = (args: { challenge: number | { challenges_id: number } } | [challenge: number | { challenges_id: number } ] | number | { challenges_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const ChallengeController = { index, store, show }

export default ChallengeController