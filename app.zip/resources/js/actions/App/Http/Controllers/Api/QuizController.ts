import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\QuizController::show
 * @see app/Http/Controllers/Api/QuizController.php:82
 * @route '/api/quizzes/{quiz}'
 */
export const show = (args: { quiz: number | { quizzes_id: number } } | [quiz: number | { quizzes_id: number } ] | number | { quizzes_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/quizzes/{quiz}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\QuizController::show
 * @see app/Http/Controllers/Api/QuizController.php:82
 * @route '/api/quizzes/{quiz}'
 */
show.url = (args: { quiz: number | { quizzes_id: number } } | [quiz: number | { quizzes_id: number } ] | number | { quizzes_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { quiz: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'quizzes_id' in args) {
            args = { quiz: args.quizzes_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    quiz: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        quiz: typeof args.quiz === 'object'
                ? args.quiz.quizzes_id
                : args.quiz,
                }

    return show.definition.url
            .replace('{quiz}', parsedArgs.quiz.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\QuizController::show
 * @see app/Http/Controllers/Api/QuizController.php:82
 * @route '/api/quizzes/{quiz}'
 */
show.get = (args: { quiz: number | { quizzes_id: number } } | [quiz: number | { quizzes_id: number } ] | number | { quizzes_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\QuizController::show
 * @see app/Http/Controllers/Api/QuizController.php:82
 * @route '/api/quizzes/{quiz}'
 */
show.head = (args: { quiz: number | { quizzes_id: number } } | [quiz: number | { quizzes_id: number } ] | number | { quizzes_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\QuizController::show
 * @see app/Http/Controllers/Api/QuizController.php:82
 * @route '/api/quizzes/{quiz}'
 */
    const showForm = (args: { quiz: number | { quizzes_id: number } } | [quiz: number | { quizzes_id: number } ] | number | { quizzes_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\QuizController::show
 * @see app/Http/Controllers/Api/QuizController.php:82
 * @route '/api/quizzes/{quiz}'
 */
        showForm.get = (args: { quiz: number | { quizzes_id: number } } | [quiz: number | { quizzes_id: number } ] | number | { quizzes_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\QuizController::show
 * @see app/Http/Controllers/Api/QuizController.php:82
 * @route '/api/quizzes/{quiz}'
 */
        showForm.head = (args: { quiz: number | { quizzes_id: number } } | [quiz: number | { quizzes_id: number } ] | number | { quizzes_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\QuizController::store
 * @see app/Http/Controllers/Api/QuizController.php:19
 * @route '/api/materials/{material}/quizzes'
 */
export const store = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/materials/{material}/quizzes',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\QuizController::store
 * @see app/Http/Controllers/Api/QuizController.php:19
 * @route '/api/materials/{material}/quizzes'
 */
store.url = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { material: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'materials_id' in args) {
            args = { material: args.materials_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    material: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        material: typeof args.material === 'object'
                ? args.material.materials_id
                : args.material,
                }

    return store.definition.url
            .replace('{material}', parsedArgs.material.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\QuizController::store
 * @see app/Http/Controllers/Api/QuizController.php:19
 * @route '/api/materials/{material}/quizzes'
 */
store.post = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\QuizController::store
 * @see app/Http/Controllers/Api/QuizController.php:19
 * @route '/api/materials/{material}/quizzes'
 */
    const storeForm = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\QuizController::store
 * @see app/Http/Controllers/Api/QuizController.php:19
 * @route '/api/materials/{material}/quizzes'
 */
        storeForm.post = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
const QuizController = { show, store }

export default QuizController