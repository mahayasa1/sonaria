import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\OnboardingController::categories
 * @see app/Http/Controllers/Api/OnboardingController.php:16
 * @route '/api/categories'
 */
export const categories = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: categories.url(options),
    method: 'get',
})

categories.definition = {
    methods: ["get","head"],
    url: '/api/categories',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\OnboardingController::categories
 * @see app/Http/Controllers/Api/OnboardingController.php:16
 * @route '/api/categories'
 */
categories.url = (options?: RouteQueryOptions) => {
    return categories.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\OnboardingController::categories
 * @see app/Http/Controllers/Api/OnboardingController.php:16
 * @route '/api/categories'
 */
categories.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: categories.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\OnboardingController::categories
 * @see app/Http/Controllers/Api/OnboardingController.php:16
 * @route '/api/categories'
 */
categories.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: categories.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\OnboardingController::categories
 * @see app/Http/Controllers/Api/OnboardingController.php:16
 * @route '/api/categories'
 */
    const categoriesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: categories.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\OnboardingController::categories
 * @see app/Http/Controllers/Api/OnboardingController.php:16
 * @route '/api/categories'
 */
        categoriesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: categories.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\OnboardingController::categories
 * @see app/Http/Controllers/Api/OnboardingController.php:16
 * @route '/api/categories'
 */
        categoriesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: categories.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    categories.form = categoriesForm
/**
* @see \App\Http\Controllers\Api\OnboardingController::instruments
 * @see app/Http/Controllers/Api/OnboardingController.php:24
 * @route '/api/categories/{category}/instruments'
 */
export const instruments = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: instruments.url(args, options),
    method: 'get',
})

instruments.definition = {
    methods: ["get","head"],
    url: '/api/categories/{category}/instruments',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\OnboardingController::instruments
 * @see app/Http/Controllers/Api/OnboardingController.php:24
 * @route '/api/categories/{category}/instruments'
 */
instruments.url = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'music_categories_id' in args) {
            args = { category: args.music_categories_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    category: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        category: typeof args.category === 'object'
                ? args.category.music_categories_id
                : args.category,
                }

    return instruments.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\OnboardingController::instruments
 * @see app/Http/Controllers/Api/OnboardingController.php:24
 * @route '/api/categories/{category}/instruments'
 */
instruments.get = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: instruments.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\OnboardingController::instruments
 * @see app/Http/Controllers/Api/OnboardingController.php:24
 * @route '/api/categories/{category}/instruments'
 */
instruments.head = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: instruments.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\OnboardingController::instruments
 * @see app/Http/Controllers/Api/OnboardingController.php:24
 * @route '/api/categories/{category}/instruments'
 */
    const instrumentsForm = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: instruments.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\OnboardingController::instruments
 * @see app/Http/Controllers/Api/OnboardingController.php:24
 * @route '/api/categories/{category}/instruments'
 */
        instrumentsForm.get = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: instruments.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\OnboardingController::instruments
 * @see app/Http/Controllers/Api/OnboardingController.php:24
 * @route '/api/categories/{category}/instruments'
 */
        instrumentsForm.head = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: instruments.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    instruments.form = instrumentsForm
/**
* @see \App\Http\Controllers\Api\OnboardingController::selectInstrument
 * @see app/Http/Controllers/Api/OnboardingController.php:34
 * @route '/api/onboarding/instrument'
 */
export const selectInstrument = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: selectInstrument.url(options),
    method: 'post',
})

selectInstrument.definition = {
    methods: ["post"],
    url: '/api/onboarding/instrument',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\OnboardingController::selectInstrument
 * @see app/Http/Controllers/Api/OnboardingController.php:34
 * @route '/api/onboarding/instrument'
 */
selectInstrument.url = (options?: RouteQueryOptions) => {
    return selectInstrument.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\OnboardingController::selectInstrument
 * @see app/Http/Controllers/Api/OnboardingController.php:34
 * @route '/api/onboarding/instrument'
 */
selectInstrument.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: selectInstrument.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\OnboardingController::selectInstrument
 * @see app/Http/Controllers/Api/OnboardingController.php:34
 * @route '/api/onboarding/instrument'
 */
    const selectInstrumentForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: selectInstrument.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\OnboardingController::selectInstrument
 * @see app/Http/Controllers/Api/OnboardingController.php:34
 * @route '/api/onboarding/instrument'
 */
        selectInstrumentForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: selectInstrument.url(options),
            method: 'post',
        })
    
    selectInstrument.form = selectInstrumentForm
const OnboardingController = { categories, instruments, selectInstrument }

export default OnboardingController