import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\PracticeSubmissionController::store
 * @see app/Http/Controllers/Api/PracticeSubmissionController.php:23
 * @route '/api/practices/{practice}/submissions'
 */
export const store = (args: { practice: number | { practices_id: number } } | [practice: number | { practices_id: number } ] | number | { practices_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/practices/{practice}/submissions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\PracticeSubmissionController::store
 * @see app/Http/Controllers/Api/PracticeSubmissionController.php:23
 * @route '/api/practices/{practice}/submissions'
 */
store.url = (args: { practice: number | { practices_id: number } } | [practice: number | { practices_id: number } ] | number | { practices_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { practice: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'practices_id' in args) {
            args = { practice: args.practices_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    practice: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        practice: typeof args.practice === 'object'
                ? args.practice.practices_id
                : args.practice,
                }

    return store.definition.url
            .replace('{practice}', parsedArgs.practice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\PracticeSubmissionController::store
 * @see app/Http/Controllers/Api/PracticeSubmissionController.php:23
 * @route '/api/practices/{practice}/submissions'
 */
store.post = (args: { practice: number | { practices_id: number } } | [practice: number | { practices_id: number } ] | number | { practices_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\PracticeSubmissionController::store
 * @see app/Http/Controllers/Api/PracticeSubmissionController.php:23
 * @route '/api/practices/{practice}/submissions'
 */
    const storeForm = (args: { practice: number | { practices_id: number } } | [practice: number | { practices_id: number } ] | number | { practices_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\PracticeSubmissionController::store
 * @see app/Http/Controllers/Api/PracticeSubmissionController.php:23
 * @route '/api/practices/{practice}/submissions'
 */
        storeForm.post = (args: { practice: number | { practices_id: number } } | [practice: number | { practices_id: number } ] | number | { practices_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\PracticeSubmissionController::index
 * @see app/Http/Controllers/Api/PracticeSubmissionController.php:52
 * @route '/api/practices/{practice}/submissions'
 */
export const index = (args: { practice: number | { practices_id: number } } | [practice: number | { practices_id: number } ] | number | { practices_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/practices/{practice}/submissions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\PracticeSubmissionController::index
 * @see app/Http/Controllers/Api/PracticeSubmissionController.php:52
 * @route '/api/practices/{practice}/submissions'
 */
index.url = (args: { practice: number | { practices_id: number } } | [practice: number | { practices_id: number } ] | number | { practices_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { practice: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'practices_id' in args) {
            args = { practice: args.practices_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    practice: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        practice: typeof args.practice === 'object'
                ? args.practice.practices_id
                : args.practice,
                }

    return index.definition.url
            .replace('{practice}', parsedArgs.practice.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\PracticeSubmissionController::index
 * @see app/Http/Controllers/Api/PracticeSubmissionController.php:52
 * @route '/api/practices/{practice}/submissions'
 */
index.get = (args: { practice: number | { practices_id: number } } | [practice: number | { practices_id: number } ] | number | { practices_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\PracticeSubmissionController::index
 * @see app/Http/Controllers/Api/PracticeSubmissionController.php:52
 * @route '/api/practices/{practice}/submissions'
 */
index.head = (args: { practice: number | { practices_id: number } } | [practice: number | { practices_id: number } ] | number | { practices_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\PracticeSubmissionController::index
 * @see app/Http/Controllers/Api/PracticeSubmissionController.php:52
 * @route '/api/practices/{practice}/submissions'
 */
    const indexForm = (args: { practice: number | { practices_id: number } } | [practice: number | { practices_id: number } ] | number | { practices_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\PracticeSubmissionController::index
 * @see app/Http/Controllers/Api/PracticeSubmissionController.php:52
 * @route '/api/practices/{practice}/submissions'
 */
        indexForm.get = (args: { practice: number | { practices_id: number } } | [practice: number | { practices_id: number } ] | number | { practices_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\PracticeSubmissionController::index
 * @see app/Http/Controllers/Api/PracticeSubmissionController.php:52
 * @route '/api/practices/{practice}/submissions'
 */
        indexForm.head = (args: { practice: number | { practices_id: number } } | [practice: number | { practices_id: number } ] | number | { practices_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\PracticeSubmissionController::review
 * @see app/Http/Controllers/Api/PracticeSubmissionController.php:65
 * @route '/api/practice-submissions/{submission}/review'
 */
export const review = (args: { submission: number | { practice_submissions_id: number } } | [submission: number | { practice_submissions_id: number } ] | number | { practice_submissions_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: review.url(args, options),
    method: 'post',
})

review.definition = {
    methods: ["post"],
    url: '/api/practice-submissions/{submission}/review',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\PracticeSubmissionController::review
 * @see app/Http/Controllers/Api/PracticeSubmissionController.php:65
 * @route '/api/practice-submissions/{submission}/review'
 */
review.url = (args: { submission: number | { practice_submissions_id: number } } | [submission: number | { practice_submissions_id: number } ] | number | { practice_submissions_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { submission: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'practice_submissions_id' in args) {
            args = { submission: args.practice_submissions_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    submission: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        submission: typeof args.submission === 'object'
                ? args.submission.practice_submissions_id
                : args.submission,
                }

    return review.definition.url
            .replace('{submission}', parsedArgs.submission.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\PracticeSubmissionController::review
 * @see app/Http/Controllers/Api/PracticeSubmissionController.php:65
 * @route '/api/practice-submissions/{submission}/review'
 */
review.post = (args: { submission: number | { practice_submissions_id: number } } | [submission: number | { practice_submissions_id: number } ] | number | { practice_submissions_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: review.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\PracticeSubmissionController::review
 * @see app/Http/Controllers/Api/PracticeSubmissionController.php:65
 * @route '/api/practice-submissions/{submission}/review'
 */
    const reviewForm = (args: { submission: number | { practice_submissions_id: number } } | [submission: number | { practice_submissions_id: number } ] | number | { practice_submissions_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: review.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\PracticeSubmissionController::review
 * @see app/Http/Controllers/Api/PracticeSubmissionController.php:65
 * @route '/api/practice-submissions/{submission}/review'
 */
        reviewForm.post = (args: { submission: number | { practice_submissions_id: number } } | [submission: number | { practice_submissions_id: number } ] | number | { practice_submissions_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: review.url(args, options),
            method: 'post',
        })
    
    review.form = reviewForm
const PracticeSubmissionController = { store, index, review }

export default PracticeSubmissionController