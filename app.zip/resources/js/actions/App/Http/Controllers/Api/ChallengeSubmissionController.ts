import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\ChallengeSubmissionController::store
 * @see app/Http/Controllers/Api/ChallengeSubmissionController.php:19
 * @route '/api/challenges/{challenge}/submissions'
 */
export const store = (args: { challenge: number | { challenges_id: number } } | [challenge: number | { challenges_id: number } ] | number | { challenges_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/challenges/{challenge}/submissions',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\ChallengeSubmissionController::store
 * @see app/Http/Controllers/Api/ChallengeSubmissionController.php:19
 * @route '/api/challenges/{challenge}/submissions'
 */
store.url = (args: { challenge: number | { challenges_id: number } } | [challenge: number | { challenges_id: number } ] | number | { challenges_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { challenge: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'challenges_id' in args) {
            args = { challenge: args.challenges_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    challenge: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        challenge: typeof args.challenge === 'object'
                ? args.challenge.challenges_id
                : args.challenge,
                }

    return store.definition.url
            .replace('{challenge}', parsedArgs.challenge.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ChallengeSubmissionController::store
 * @see app/Http/Controllers/Api/ChallengeSubmissionController.php:19
 * @route '/api/challenges/{challenge}/submissions'
 */
store.post = (args: { challenge: number | { challenges_id: number } } | [challenge: number | { challenges_id: number } ] | number | { challenges_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\ChallengeSubmissionController::store
 * @see app/Http/Controllers/Api/ChallengeSubmissionController.php:19
 * @route '/api/challenges/{challenge}/submissions'
 */
    const storeForm = (args: { challenge: number | { challenges_id: number } } | [challenge: number | { challenges_id: number } ] | number | { challenges_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\ChallengeSubmissionController::store
 * @see app/Http/Controllers/Api/ChallengeSubmissionController.php:19
 * @route '/api/challenges/{challenge}/submissions'
 */
        storeForm.post = (args: { challenge: number | { challenges_id: number } } | [challenge: number | { challenges_id: number } ] | number | { challenges_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\ChallengeSubmissionController::index
 * @see app/Http/Controllers/Api/ChallengeSubmissionController.php:45
 * @route '/api/challenges/{challenge}/submissions'
 */
export const index = (args: { challenge: number | { challenges_id: number } } | [challenge: number | { challenges_id: number } ] | number | { challenges_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/challenges/{challenge}/submissions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\ChallengeSubmissionController::index
 * @see app/Http/Controllers/Api/ChallengeSubmissionController.php:45
 * @route '/api/challenges/{challenge}/submissions'
 */
index.url = (args: { challenge: number | { challenges_id: number } } | [challenge: number | { challenges_id: number } ] | number | { challenges_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { challenge: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'challenges_id' in args) {
            args = { challenge: args.challenges_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    challenge: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        challenge: typeof args.challenge === 'object'
                ? args.challenge.challenges_id
                : args.challenge,
                }

    return index.definition.url
            .replace('{challenge}', parsedArgs.challenge.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ChallengeSubmissionController::index
 * @see app/Http/Controllers/Api/ChallengeSubmissionController.php:45
 * @route '/api/challenges/{challenge}/submissions'
 */
index.get = (args: { challenge: number | { challenges_id: number } } | [challenge: number | { challenges_id: number } ] | number | { challenges_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\ChallengeSubmissionController::index
 * @see app/Http/Controllers/Api/ChallengeSubmissionController.php:45
 * @route '/api/challenges/{challenge}/submissions'
 */
index.head = (args: { challenge: number | { challenges_id: number } } | [challenge: number | { challenges_id: number } ] | number | { challenges_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\ChallengeSubmissionController::index
 * @see app/Http/Controllers/Api/ChallengeSubmissionController.php:45
 * @route '/api/challenges/{challenge}/submissions'
 */
    const indexForm = (args: { challenge: number | { challenges_id: number } } | [challenge: number | { challenges_id: number } ] | number | { challenges_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\ChallengeSubmissionController::index
 * @see app/Http/Controllers/Api/ChallengeSubmissionController.php:45
 * @route '/api/challenges/{challenge}/submissions'
 */
        indexForm.get = (args: { challenge: number | { challenges_id: number } } | [challenge: number | { challenges_id: number } ] | number | { challenges_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\ChallengeSubmissionController::index
 * @see app/Http/Controllers/Api/ChallengeSubmissionController.php:45
 * @route '/api/challenges/{challenge}/submissions'
 */
        indexForm.head = (args: { challenge: number | { challenges_id: number } } | [challenge: number | { challenges_id: number } ] | number | { challenges_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\ChallengeSubmissionController::review
 * @see app/Http/Controllers/Api/ChallengeSubmissionController.php:57
 * @route '/api/challenge-submissions/{submission}/review'
 */
export const review = (args: { submission: number | { challenge_submissions_id: number } } | [submission: number | { challenge_submissions_id: number } ] | number | { challenge_submissions_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: review.url(args, options),
    method: 'post',
})

review.definition = {
    methods: ["post"],
    url: '/api/challenge-submissions/{submission}/review',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\ChallengeSubmissionController::review
 * @see app/Http/Controllers/Api/ChallengeSubmissionController.php:57
 * @route '/api/challenge-submissions/{submission}/review'
 */
review.url = (args: { submission: number | { challenge_submissions_id: number } } | [submission: number | { challenge_submissions_id: number } ] | number | { challenge_submissions_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { submission: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'challenge_submissions_id' in args) {
            args = { submission: args.challenge_submissions_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    submission: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        submission: typeof args.submission === 'object'
                ? args.submission.challenge_submissions_id
                : args.submission,
                }

    return review.definition.url
            .replace('{submission}', parsedArgs.submission.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\ChallengeSubmissionController::review
 * @see app/Http/Controllers/Api/ChallengeSubmissionController.php:57
 * @route '/api/challenge-submissions/{submission}/review'
 */
review.post = (args: { submission: number | { challenge_submissions_id: number } } | [submission: number | { challenge_submissions_id: number } ] | number | { challenge_submissions_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: review.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\ChallengeSubmissionController::review
 * @see app/Http/Controllers/Api/ChallengeSubmissionController.php:57
 * @route '/api/challenge-submissions/{submission}/review'
 */
    const reviewForm = (args: { submission: number | { challenge_submissions_id: number } } | [submission: number | { challenge_submissions_id: number } ] | number | { challenge_submissions_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: review.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\ChallengeSubmissionController::review
 * @see app/Http/Controllers/Api/ChallengeSubmissionController.php:57
 * @route '/api/challenge-submissions/{submission}/review'
 */
        reviewForm.post = (args: { submission: number | { challenge_submissions_id: number } } | [submission: number | { challenge_submissions_id: number } ] | number | { challenge_submissions_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: review.url(args, options),
            method: 'post',
        })
    
    review.form = reviewForm
const ChallengeSubmissionController = { store, index, review }

export default ChallengeSubmissionController