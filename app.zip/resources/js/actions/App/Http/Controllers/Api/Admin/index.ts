import RoleController from './RoleController'
import LevelController from './LevelController'
import MusicCategoryController from './MusicCategoryController'
import BadgeController from './BadgeController'
import AchievementController from './AchievementController'
const Admin = {
    RoleController: Object.assign(RoleController, RoleController),
LevelController: Object.assign(LevelController, LevelController),
MusicCategoryController: Object.assign(MusicCategoryController, MusicCategoryController),
BadgeController: Object.assign(BadgeController, BadgeController),
AchievementController: Object.assign(AchievementController, AchievementController),
}

export default Admin