import AuthController from './AuthController'
import OnboardingController from './OnboardingController'
import CommunityController from './CommunityController'
import MainQuestController from './MainQuestController'
import MaterialController from './MaterialController'
import MaterialFileController from './MaterialFileController'
import PracticeController from './PracticeController'
import PracticeSubmissionController from './PracticeSubmissionController'
import QuizController from './QuizController'
import QuizAttemptController from './QuizAttemptController'
import DailyMissionController from './DailyMissionController'
import ChallengeController from './ChallengeController'
import ChallengeSubmissionController from './ChallengeSubmissionController'
import LeaderboardController from './LeaderboardController'
import ForumPostController from './ForumPostController'
import ForumCommentController from './ForumCommentController'
import NotificationController from './NotificationController'
import Admin from './Admin'
const Api = {
    AuthController: Object.assign(AuthController, AuthController),
OnboardingController: Object.assign(OnboardingController, OnboardingController),
CommunityController: Object.assign(CommunityController, CommunityController),
MainQuestController: Object.assign(MainQuestController, MainQuestController),
MaterialController: Object.assign(MaterialController, MaterialController),
MaterialFileController: Object.assign(MaterialFileController, MaterialFileController),
PracticeController: Object.assign(PracticeController, PracticeController),
PracticeSubmissionController: Object.assign(PracticeSubmissionController, PracticeSubmissionController),
QuizController: Object.assign(QuizController, QuizController),
QuizAttemptController: Object.assign(QuizAttemptController, QuizAttemptController),
DailyMissionController: Object.assign(DailyMissionController, DailyMissionController),
ChallengeController: Object.assign(ChallengeController, ChallengeController),
ChallengeSubmissionController: Object.assign(ChallengeSubmissionController, ChallengeSubmissionController),
LeaderboardController: Object.assign(LeaderboardController, LeaderboardController),
ForumPostController: Object.assign(ForumPostController, ForumPostController),
ForumCommentController: Object.assign(ForumCommentController, ForumCommentController),
NotificationController: Object.assign(NotificationController, NotificationController),
Admin: Object.assign(Admin, Admin),
}

export default Api