import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\MaterialFileController::index
 * @see app/Http/Controllers/Api/MaterialFileController.php:40
 * @route '/api/materials/{material}/files'
 */
export const index = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/materials/{material}/files',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\MaterialFileController::index
 * @see app/Http/Controllers/Api/MaterialFileController.php:40
 * @route '/api/materials/{material}/files'
 */
index.url = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { material: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'materials_id' in args) {
            args = { material: args.materials_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    material: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        material: typeof args.material === 'object'
                ? args.material.materials_id
                : args.material,
                }

    return index.definition.url
            .replace('{material}', parsedArgs.material.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\MaterialFileController::index
 * @see app/Http/Controllers/Api/MaterialFileController.php:40
 * @route '/api/materials/{material}/files'
 */
index.get = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\MaterialFileController::index
 * @see app/Http/Controllers/Api/MaterialFileController.php:40
 * @route '/api/materials/{material}/files'
 */
index.head = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\MaterialFileController::index
 * @see app/Http/Controllers/Api/MaterialFileController.php:40
 * @route '/api/materials/{material}/files'
 */
    const indexForm = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\MaterialFileController::index
 * @see app/Http/Controllers/Api/MaterialFileController.php:40
 * @route '/api/materials/{material}/files'
 */
        indexForm.get = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\MaterialFileController::index
 * @see app/Http/Controllers/Api/MaterialFileController.php:40
 * @route '/api/materials/{material}/files'
 */
        indexForm.head = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\MaterialFileController::store
 * @see app/Http/Controllers/Api/MaterialFileController.php:21
 * @route '/api/materials/{material}/files'
 */
export const store = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/materials/{material}/files',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\MaterialFileController::store
 * @see app/Http/Controllers/Api/MaterialFileController.php:21
 * @route '/api/materials/{material}/files'
 */
store.url = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { material: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'materials_id' in args) {
            args = { material: args.materials_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    material: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        material: typeof args.material === 'object'
                ? args.material.materials_id
                : args.material,
                }

    return store.definition.url
            .replace('{material}', parsedArgs.material.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\MaterialFileController::store
 * @see app/Http/Controllers/Api/MaterialFileController.php:21
 * @route '/api/materials/{material}/files'
 */
store.post = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\MaterialFileController::store
 * @see app/Http/Controllers/Api/MaterialFileController.php:21
 * @route '/api/materials/{material}/files'
 */
    const storeForm = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\MaterialFileController::store
 * @see app/Http/Controllers/Api/MaterialFileController.php:21
 * @route '/api/materials/{material}/files'
 */
        storeForm.post = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\MaterialFileController::show
 * @see app/Http/Controllers/Api/MaterialFileController.php:45
 * @route '/api/material-files/{materialFile}'
 */
export const show = (args: { materialFile: number | { material_files_id: number } } | [materialFile: number | { material_files_id: number } ] | number | { material_files_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/material-files/{materialFile}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\MaterialFileController::show
 * @see app/Http/Controllers/Api/MaterialFileController.php:45
 * @route '/api/material-files/{materialFile}'
 */
show.url = (args: { materialFile: number | { material_files_id: number } } | [materialFile: number | { material_files_id: number } ] | number | { material_files_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { materialFile: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'material_files_id' in args) {
            args = { materialFile: args.material_files_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    materialFile: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        materialFile: typeof args.materialFile === 'object'
                ? args.materialFile.material_files_id
                : args.materialFile,
                }

    return show.definition.url
            .replace('{materialFile}', parsedArgs.materialFile.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\MaterialFileController::show
 * @see app/Http/Controllers/Api/MaterialFileController.php:45
 * @route '/api/material-files/{materialFile}'
 */
show.get = (args: { materialFile: number | { material_files_id: number } } | [materialFile: number | { material_files_id: number } ] | number | { material_files_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\MaterialFileController::show
 * @see app/Http/Controllers/Api/MaterialFileController.php:45
 * @route '/api/material-files/{materialFile}'
 */
show.head = (args: { materialFile: number | { material_files_id: number } } | [materialFile: number | { material_files_id: number } ] | number | { material_files_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\MaterialFileController::show
 * @see app/Http/Controllers/Api/MaterialFileController.php:45
 * @route '/api/material-files/{materialFile}'
 */
    const showForm = (args: { materialFile: number | { material_files_id: number } } | [materialFile: number | { material_files_id: number } ] | number | { material_files_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\MaterialFileController::show
 * @see app/Http/Controllers/Api/MaterialFileController.php:45
 * @route '/api/material-files/{materialFile}'
 */
        showForm.get = (args: { materialFile: number | { material_files_id: number } } | [materialFile: number | { material_files_id: number } ] | number | { material_files_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\MaterialFileController::show
 * @see app/Http/Controllers/Api/MaterialFileController.php:45
 * @route '/api/material-files/{materialFile}'
 */
        showForm.head = (args: { materialFile: number | { material_files_id: number } } | [materialFile: number | { material_files_id: number } ] | number | { material_files_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\MaterialFileController::update
 * @see app/Http/Controllers/Api/MaterialFileController.php:53
 * @route '/api/material-files/{materialFile}'
 */
export const update = (args: { materialFile: number | { material_files_id: number } } | [materialFile: number | { material_files_id: number } ] | number | { material_files_id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/material-files/{materialFile}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\MaterialFileController::update
 * @see app/Http/Controllers/Api/MaterialFileController.php:53
 * @route '/api/material-files/{materialFile}'
 */
update.url = (args: { materialFile: number | { material_files_id: number } } | [materialFile: number | { material_files_id: number } ] | number | { material_files_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { materialFile: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'material_files_id' in args) {
            args = { materialFile: args.material_files_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    materialFile: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        materialFile: typeof args.materialFile === 'object'
                ? args.materialFile.material_files_id
                : args.materialFile,
                }

    return update.definition.url
            .replace('{materialFile}', parsedArgs.materialFile.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\MaterialFileController::update
 * @see app/Http/Controllers/Api/MaterialFileController.php:53
 * @route '/api/material-files/{materialFile}'
 */
update.put = (args: { materialFile: number | { material_files_id: number } } | [materialFile: number | { material_files_id: number } ] | number | { material_files_id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Api\MaterialFileController::update
 * @see app/Http/Controllers/Api/MaterialFileController.php:53
 * @route '/api/material-files/{materialFile}'
 */
    const updateForm = (args: { materialFile: number | { material_files_id: number } } | [materialFile: number | { material_files_id: number } ] | number | { material_files_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\MaterialFileController::update
 * @see app/Http/Controllers/Api/MaterialFileController.php:53
 * @route '/api/material-files/{materialFile}'
 */
        updateForm.put = (args: { materialFile: number | { material_files_id: number } } | [materialFile: number | { material_files_id: number } ] | number | { material_files_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Api\MaterialFileController::destroy
 * @see app/Http/Controllers/Api/MaterialFileController.php:72
 * @route '/api/material-files/{materialFile}'
 */
export const destroy = (args: { materialFile: number | { material_files_id: number } } | [materialFile: number | { material_files_id: number } ] | number | { material_files_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/material-files/{materialFile}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\MaterialFileController::destroy
 * @see app/Http/Controllers/Api/MaterialFileController.php:72
 * @route '/api/material-files/{materialFile}'
 */
destroy.url = (args: { materialFile: number | { material_files_id: number } } | [materialFile: number | { material_files_id: number } ] | number | { material_files_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { materialFile: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'material_files_id' in args) {
            args = { materialFile: args.material_files_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    materialFile: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        materialFile: typeof args.materialFile === 'object'
                ? args.materialFile.material_files_id
                : args.materialFile,
                }

    return destroy.definition.url
            .replace('{materialFile}', parsedArgs.materialFile.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\MaterialFileController::destroy
 * @see app/Http/Controllers/Api/MaterialFileController.php:72
 * @route '/api/material-files/{materialFile}'
 */
destroy.delete = (args: { materialFile: number | { material_files_id: number } } | [materialFile: number | { material_files_id: number } ] | number | { material_files_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Api\MaterialFileController::destroy
 * @see app/Http/Controllers/Api/MaterialFileController.php:72
 * @route '/api/material-files/{materialFile}'
 */
    const destroyForm = (args: { materialFile: number | { material_files_id: number } } | [materialFile: number | { material_files_id: number } ] | number | { material_files_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\MaterialFileController::destroy
 * @see app/Http/Controllers/Api/MaterialFileController.php:72
 * @route '/api/material-files/{materialFile}'
 */
        destroyForm.delete = (args: { materialFile: number | { material_files_id: number } } | [materialFile: number | { material_files_id: number } ] | number | { material_files_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const MaterialFileController = { index, store, show, update, destroy }

export default MaterialFileController