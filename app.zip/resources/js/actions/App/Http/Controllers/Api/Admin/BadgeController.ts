import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\Admin\BadgeController::index
 * @see app/Http/Controllers/Api/Admin/BadgeController.php:14
 * @route '/api/admin/badges'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/admin/badges',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\Admin\BadgeController::index
 * @see app/Http/Controllers/Api/Admin/BadgeController.php:14
 * @route '/api/admin/badges'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\BadgeController::index
 * @see app/Http/Controllers/Api/Admin/BadgeController.php:14
 * @route '/api/admin/badges'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\Admin\BadgeController::index
 * @see app/Http/Controllers/Api/Admin/BadgeController.php:14
 * @route '/api/admin/badges'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\Admin\BadgeController::index
 * @see app/Http/Controllers/Api/Admin/BadgeController.php:14
 * @route '/api/admin/badges'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\BadgeController::index
 * @see app/Http/Controllers/Api/Admin/BadgeController.php:14
 * @route '/api/admin/badges'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\Admin\BadgeController::index
 * @see app/Http/Controllers/Api/Admin/BadgeController.php:14
 * @route '/api/admin/badges'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\Admin\BadgeController::store
 * @see app/Http/Controllers/Api/Admin/BadgeController.php:23
 * @route '/api/admin/badges'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/admin/badges',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\Admin\BadgeController::store
 * @see app/Http/Controllers/Api/Admin/BadgeController.php:23
 * @route '/api/admin/badges'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\BadgeController::store
 * @see app/Http/Controllers/Api/Admin/BadgeController.php:23
 * @route '/api/admin/badges'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\Admin\BadgeController::store
 * @see app/Http/Controllers/Api/Admin/BadgeController.php:23
 * @route '/api/admin/badges'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\BadgeController::store
 * @see app/Http/Controllers/Api/Admin/BadgeController.php:23
 * @route '/api/admin/badges'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\Admin\BadgeController::update
 * @see app/Http/Controllers/Api/Admin/BadgeController.php:40
 * @route '/api/admin/badges/{badge}'
 */
export const update = (args: { badge: number | { badges_id: number } } | [badge: number | { badges_id: number } ] | number | { badges_id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/api/admin/badges/{badge}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\Admin\BadgeController::update
 * @see app/Http/Controllers/Api/Admin/BadgeController.php:40
 * @route '/api/admin/badges/{badge}'
 */
update.url = (args: { badge: number | { badges_id: number } } | [badge: number | { badges_id: number } ] | number | { badges_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { badge: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'badges_id' in args) {
            args = { badge: args.badges_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    badge: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        badge: typeof args.badge === 'object'
                ? args.badge.badges_id
                : args.badge,
                }

    return update.definition.url
            .replace('{badge}', parsedArgs.badge.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\BadgeController::update
 * @see app/Http/Controllers/Api/Admin/BadgeController.php:40
 * @route '/api/admin/badges/{badge}'
 */
update.put = (args: { badge: number | { badges_id: number } } | [badge: number | { badges_id: number } ] | number | { badges_id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Api\Admin\BadgeController::update
 * @see app/Http/Controllers/Api/Admin/BadgeController.php:40
 * @route '/api/admin/badges/{badge}'
 */
    const updateForm = (args: { badge: number | { badges_id: number } } | [badge: number | { badges_id: number } ] | number | { badges_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\BadgeController::update
 * @see app/Http/Controllers/Api/Admin/BadgeController.php:40
 * @route '/api/admin/badges/{badge}'
 */
        updateForm.put = (args: { badge: number | { badges_id: number } } | [badge: number | { badges_id: number } ] | number | { badges_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Api\Admin\BadgeController::destroy
 * @see app/Http/Controllers/Api/Admin/BadgeController.php:57
 * @route '/api/admin/badges/{badge}'
 */
export const destroy = (args: { badge: number | { badges_id: number } } | [badge: number | { badges_id: number } ] | number | { badges_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/api/admin/badges/{badge}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\Admin\BadgeController::destroy
 * @see app/Http/Controllers/Api/Admin/BadgeController.php:57
 * @route '/api/admin/badges/{badge}'
 */
destroy.url = (args: { badge: number | { badges_id: number } } | [badge: number | { badges_id: number } ] | number | { badges_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { badge: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'badges_id' in args) {
            args = { badge: args.badges_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    badge: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        badge: typeof args.badge === 'object'
                ? args.badge.badges_id
                : args.badge,
                }

    return destroy.definition.url
            .replace('{badge}', parsedArgs.badge.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\Admin\BadgeController::destroy
 * @see app/Http/Controllers/Api/Admin/BadgeController.php:57
 * @route '/api/admin/badges/{badge}'
 */
destroy.delete = (args: { badge: number | { badges_id: number } } | [badge: number | { badges_id: number } ] | number | { badges_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Api\Admin\BadgeController::destroy
 * @see app/Http/Controllers/Api/Admin/BadgeController.php:57
 * @route '/api/admin/badges/{badge}'
 */
    const destroyForm = (args: { badge: number | { badges_id: number } } | [badge: number | { badges_id: number } ] | number | { badges_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\Admin\BadgeController::destroy
 * @see app/Http/Controllers/Api/Admin/BadgeController.php:57
 * @route '/api/admin/badges/{badge}'
 */
        destroyForm.delete = (args: { badge: number | { badges_id: number } } | [badge: number | { badges_id: number } ] | number | { badges_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const BadgeController = { index, store, update, destroy }

export default BadgeController