import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\CommunityController::index
 * @see app/Http/Controllers/Api/CommunityController.php:20
 * @route '/api/communities'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/api/communities',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\CommunityController::index
 * @see app/Http/Controllers/Api/CommunityController.php:20
 * @route '/api/communities'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CommunityController::index
 * @see app/Http/Controllers/Api/CommunityController.php:20
 * @route '/api/communities'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\CommunityController::index
 * @see app/Http/Controllers/Api/CommunityController.php:20
 * @route '/api/communities'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\CommunityController::index
 * @see app/Http/Controllers/Api/CommunityController.php:20
 * @route '/api/communities'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\CommunityController::index
 * @see app/Http/Controllers/Api/CommunityController.php:20
 * @route '/api/communities'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\CommunityController::index
 * @see app/Http/Controllers/Api/CommunityController.php:20
 * @route '/api/communities'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Api\CommunityController::store
 * @see app/Http/Controllers/Api/CommunityController.php:53
 * @route '/api/communities'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/api/communities',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\CommunityController::store
 * @see app/Http/Controllers/Api/CommunityController.php:53
 * @route '/api/communities'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CommunityController::store
 * @see app/Http/Controllers/Api/CommunityController.php:53
 * @route '/api/communities'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\CommunityController::store
 * @see app/Http/Controllers/Api/CommunityController.php:53
 * @route '/api/communities'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\CommunityController::store
 * @see app/Http/Controllers/Api/CommunityController.php:53
 * @route '/api/communities'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Api\CommunityController::show
 * @see app/Http/Controllers/Api/CommunityController.php:37
 * @route '/api/communities/{community}'
 */
export const show = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/api/communities/{community}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\CommunityController::show
 * @see app/Http/Controllers/Api/CommunityController.php:37
 * @route '/api/communities/{community}'
 */
show.url = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { community: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'communities_id' in args) {
            args = { community: args.communities_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    community: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        community: typeof args.community === 'object'
                ? args.community.communities_id
                : args.community,
                }

    return show.definition.url
            .replace('{community}', parsedArgs.community.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CommunityController::show
 * @see app/Http/Controllers/Api/CommunityController.php:37
 * @route '/api/communities/{community}'
 */
show.get = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\CommunityController::show
 * @see app/Http/Controllers/Api/CommunityController.php:37
 * @route '/api/communities/{community}'
 */
show.head = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\CommunityController::show
 * @see app/Http/Controllers/Api/CommunityController.php:37
 * @route '/api/communities/{community}'
 */
    const showForm = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\CommunityController::show
 * @see app/Http/Controllers/Api/CommunityController.php:37
 * @route '/api/communities/{community}'
 */
        showForm.get = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\CommunityController::show
 * @see app/Http/Controllers/Api/CommunityController.php:37
 * @route '/api/communities/{community}'
 */
        showForm.head = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Api\CommunityController::join
 * @see app/Http/Controllers/Api/CommunityController.php:96
 * @route '/api/communities/{community}/join'
 */
export const join = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: join.url(args, options),
    method: 'post',
})

join.definition = {
    methods: ["post"],
    url: '/api/communities/{community}/join',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\CommunityController::join
 * @see app/Http/Controllers/Api/CommunityController.php:96
 * @route '/api/communities/{community}/join'
 */
join.url = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { community: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'communities_id' in args) {
            args = { community: args.communities_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    community: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        community: typeof args.community === 'object'
                ? args.community.communities_id
                : args.community,
                }

    return join.definition.url
            .replace('{community}', parsedArgs.community.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CommunityController::join
 * @see app/Http/Controllers/Api/CommunityController.php:96
 * @route '/api/communities/{community}/join'
 */
join.post = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: join.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\CommunityController::join
 * @see app/Http/Controllers/Api/CommunityController.php:96
 * @route '/api/communities/{community}/join'
 */
    const joinForm = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: join.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\CommunityController::join
 * @see app/Http/Controllers/Api/CommunityController.php:96
 * @route '/api/communities/{community}/join'
 */
        joinForm.post = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: join.url(args, options),
            method: 'post',
        })
    
    join.form = joinForm
/**
* @see \App\Http\Controllers\Api\CommunityController::leave
 * @see app/Http/Controllers/Api/CommunityController.php:178
 * @route '/api/communities/{community}/leave'
 */
export const leave = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: leave.url(args, options),
    method: 'post',
})

leave.definition = {
    methods: ["post"],
    url: '/api/communities/{community}/leave',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\CommunityController::leave
 * @see app/Http/Controllers/Api/CommunityController.php:178
 * @route '/api/communities/{community}/leave'
 */
leave.url = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { community: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'communities_id' in args) {
            args = { community: args.communities_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    community: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        community: typeof args.community === 'object'
                ? args.community.communities_id
                : args.community,
                }

    return leave.definition.url
            .replace('{community}', parsedArgs.community.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CommunityController::leave
 * @see app/Http/Controllers/Api/CommunityController.php:178
 * @route '/api/communities/{community}/leave'
 */
leave.post = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: leave.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\CommunityController::leave
 * @see app/Http/Controllers/Api/CommunityController.php:178
 * @route '/api/communities/{community}/leave'
 */
    const leaveForm = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: leave.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\CommunityController::leave
 * @see app/Http/Controllers/Api/CommunityController.php:178
 * @route '/api/communities/{community}/leave'
 */
        leaveForm.post = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: leave.url(args, options),
            method: 'post',
        })
    
    leave.form = leaveForm
/**
* @see \App\Http\Controllers\Api\CommunityController::updateMemberRole
 * @see app/Http/Controllers/Api/CommunityController.php:217
 * @route '/api/communities/{community}/members/{member}'
 */
export const updateMemberRole = (args: { community: number | { communities_id: number }, member: number | { community_members_id: number } } | [community: number | { communities_id: number }, member: number | { community_members_id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateMemberRole.url(args, options),
    method: 'put',
})

updateMemberRole.definition = {
    methods: ["put"],
    url: '/api/communities/{community}/members/{member}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Api\CommunityController::updateMemberRole
 * @see app/Http/Controllers/Api/CommunityController.php:217
 * @route '/api/communities/{community}/members/{member}'
 */
updateMemberRole.url = (args: { community: number | { communities_id: number }, member: number | { community_members_id: number } } | [community: number | { communities_id: number }, member: number | { community_members_id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    community: args[0],
                    member: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        community: typeof args.community === 'object'
                ? args.community.communities_id
                : args.community,
                                member: typeof args.member === 'object'
                ? args.member.community_members_id
                : args.member,
                }

    return updateMemberRole.definition.url
            .replace('{community}', parsedArgs.community.toString())
            .replace('{member}', parsedArgs.member.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CommunityController::updateMemberRole
 * @see app/Http/Controllers/Api/CommunityController.php:217
 * @route '/api/communities/{community}/members/{member}'
 */
updateMemberRole.put = (args: { community: number | { communities_id: number }, member: number | { community_members_id: number } } | [community: number | { communities_id: number }, member: number | { community_members_id: number } ], options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateMemberRole.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Api\CommunityController::updateMemberRole
 * @see app/Http/Controllers/Api/CommunityController.php:217
 * @route '/api/communities/{community}/members/{member}'
 */
    const updateMemberRoleForm = (args: { community: number | { communities_id: number }, member: number | { community_members_id: number } } | [community: number | { communities_id: number }, member: number | { community_members_id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateMemberRole.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\CommunityController::updateMemberRole
 * @see app/Http/Controllers/Api/CommunityController.php:217
 * @route '/api/communities/{community}/members/{member}'
 */
        updateMemberRoleForm.put = (args: { community: number | { communities_id: number }, member: number | { community_members_id: number } } | [community: number | { communities_id: number }, member: number | { community_members_id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateMemberRole.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateMemberRole.form = updateMemberRoleForm
/**
* @see \App\Http\Controllers\Api\CommunityController::removeMember
 * @see app/Http/Controllers/Api/CommunityController.php:252
 * @route '/api/communities/{community}/members/{member}'
 */
export const removeMember = (args: { community: number | { communities_id: number }, member: number | { community_members_id: number } } | [community: number | { communities_id: number }, member: number | { community_members_id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeMember.url(args, options),
    method: 'delete',
})

removeMember.definition = {
    methods: ["delete"],
    url: '/api/communities/{community}/members/{member}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Api\CommunityController::removeMember
 * @see app/Http/Controllers/Api/CommunityController.php:252
 * @route '/api/communities/{community}/members/{member}'
 */
removeMember.url = (args: { community: number | { communities_id: number }, member: number | { community_members_id: number } } | [community: number | { communities_id: number }, member: number | { community_members_id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    community: args[0],
                    member: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        community: typeof args.community === 'object'
                ? args.community.communities_id
                : args.community,
                                member: typeof args.member === 'object'
                ? args.member.community_members_id
                : args.member,
                }

    return removeMember.definition.url
            .replace('{community}', parsedArgs.community.toString())
            .replace('{member}', parsedArgs.member.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CommunityController::removeMember
 * @see app/Http/Controllers/Api/CommunityController.php:252
 * @route '/api/communities/{community}/members/{member}'
 */
removeMember.delete = (args: { community: number | { communities_id: number }, member: number | { community_members_id: number } } | [community: number | { communities_id: number }, member: number | { community_members_id: number } ], options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: removeMember.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Api\CommunityController::removeMember
 * @see app/Http/Controllers/Api/CommunityController.php:252
 * @route '/api/communities/{community}/members/{member}'
 */
    const removeMemberForm = (args: { community: number | { communities_id: number }, member: number | { community_members_id: number } } | [community: number | { communities_id: number }, member: number | { community_members_id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: removeMember.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\CommunityController::removeMember
 * @see app/Http/Controllers/Api/CommunityController.php:252
 * @route '/api/communities/{community}/members/{member}'
 */
        removeMemberForm.delete = (args: { community: number | { communities_id: number }, member: number | { community_members_id: number } } | [community: number | { communities_id: number }, member: number | { community_members_id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: removeMember.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    removeMember.form = removeMemberForm
/**
* @see \App\Http\Controllers\Api\CommunityController::joinRequests
 * @see app/Http/Controllers/Api/CommunityController.php:128
 * @route '/api/communities/{community}/join-requests'
 */
export const joinRequests = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: joinRequests.url(args, options),
    method: 'get',
})

joinRequests.definition = {
    methods: ["get","head"],
    url: '/api/communities/{community}/join-requests',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\CommunityController::joinRequests
 * @see app/Http/Controllers/Api/CommunityController.php:128
 * @route '/api/communities/{community}/join-requests'
 */
joinRequests.url = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { community: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'communities_id' in args) {
            args = { community: args.communities_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    community: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        community: typeof args.community === 'object'
                ? args.community.communities_id
                : args.community,
                }

    return joinRequests.definition.url
            .replace('{community}', parsedArgs.community.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CommunityController::joinRequests
 * @see app/Http/Controllers/Api/CommunityController.php:128
 * @route '/api/communities/{community}/join-requests'
 */
joinRequests.get = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: joinRequests.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\CommunityController::joinRequests
 * @see app/Http/Controllers/Api/CommunityController.php:128
 * @route '/api/communities/{community}/join-requests'
 */
joinRequests.head = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: joinRequests.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\CommunityController::joinRequests
 * @see app/Http/Controllers/Api/CommunityController.php:128
 * @route '/api/communities/{community}/join-requests'
 */
    const joinRequestsForm = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: joinRequests.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\CommunityController::joinRequests
 * @see app/Http/Controllers/Api/CommunityController.php:128
 * @route '/api/communities/{community}/join-requests'
 */
        joinRequestsForm.get = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: joinRequests.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\CommunityController::joinRequests
 * @see app/Http/Controllers/Api/CommunityController.php:128
 * @route '/api/communities/{community}/join-requests'
 */
        joinRequestsForm.head = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: joinRequests.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    joinRequests.form = joinRequestsForm
/**
* @see \App\Http\Controllers\Api\CommunityController::approveJoinRequest
 * @see app/Http/Controllers/Api/CommunityController.php:137
 * @route '/api/communities/{community}/join-requests/{joinRequest}/approve'
 */
export const approveJoinRequest = (args: { community: number | { communities_id: number }, joinRequest: number | { community_join_requests_id: number } } | [community: number | { communities_id: number }, joinRequest: number | { community_join_requests_id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approveJoinRequest.url(args, options),
    method: 'post',
})

approveJoinRequest.definition = {
    methods: ["post"],
    url: '/api/communities/{community}/join-requests/{joinRequest}/approve',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\CommunityController::approveJoinRequest
 * @see app/Http/Controllers/Api/CommunityController.php:137
 * @route '/api/communities/{community}/join-requests/{joinRequest}/approve'
 */
approveJoinRequest.url = (args: { community: number | { communities_id: number }, joinRequest: number | { community_join_requests_id: number } } | [community: number | { communities_id: number }, joinRequest: number | { community_join_requests_id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    community: args[0],
                    joinRequest: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        community: typeof args.community === 'object'
                ? args.community.communities_id
                : args.community,
                                joinRequest: typeof args.joinRequest === 'object'
                ? args.joinRequest.community_join_requests_id
                : args.joinRequest,
                }

    return approveJoinRequest.definition.url
            .replace('{community}', parsedArgs.community.toString())
            .replace('{joinRequest}', parsedArgs.joinRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CommunityController::approveJoinRequest
 * @see app/Http/Controllers/Api/CommunityController.php:137
 * @route '/api/communities/{community}/join-requests/{joinRequest}/approve'
 */
approveJoinRequest.post = (args: { community: number | { communities_id: number }, joinRequest: number | { community_join_requests_id: number } } | [community: number | { communities_id: number }, joinRequest: number | { community_join_requests_id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: approveJoinRequest.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\CommunityController::approveJoinRequest
 * @see app/Http/Controllers/Api/CommunityController.php:137
 * @route '/api/communities/{community}/join-requests/{joinRequest}/approve'
 */
    const approveJoinRequestForm = (args: { community: number | { communities_id: number }, joinRequest: number | { community_join_requests_id: number } } | [community: number | { communities_id: number }, joinRequest: number | { community_join_requests_id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: approveJoinRequest.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\CommunityController::approveJoinRequest
 * @see app/Http/Controllers/Api/CommunityController.php:137
 * @route '/api/communities/{community}/join-requests/{joinRequest}/approve'
 */
        approveJoinRequestForm.post = (args: { community: number | { communities_id: number }, joinRequest: number | { community_join_requests_id: number } } | [community: number | { communities_id: number }, joinRequest: number | { community_join_requests_id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: approveJoinRequest.url(args, options),
            method: 'post',
        })
    
    approveJoinRequest.form = approveJoinRequestForm
/**
* @see \App\Http\Controllers\Api\CommunityController::rejectJoinRequest
 * @see app/Http/Controllers/Api/CommunityController.php:155
 * @route '/api/communities/{community}/join-requests/{joinRequest}/reject'
 */
export const rejectJoinRequest = (args: { community: number | { communities_id: number }, joinRequest: number | { community_join_requests_id: number } } | [community: number | { communities_id: number }, joinRequest: number | { community_join_requests_id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rejectJoinRequest.url(args, options),
    method: 'post',
})

rejectJoinRequest.definition = {
    methods: ["post"],
    url: '/api/communities/{community}/join-requests/{joinRequest}/reject',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\CommunityController::rejectJoinRequest
 * @see app/Http/Controllers/Api/CommunityController.php:155
 * @route '/api/communities/{community}/join-requests/{joinRequest}/reject'
 */
rejectJoinRequest.url = (args: { community: number | { communities_id: number }, joinRequest: number | { community_join_requests_id: number } } | [community: number | { communities_id: number }, joinRequest: number | { community_join_requests_id: number } ], options?: RouteQueryOptions) => {
    if (Array.isArray(args)) {
        args = {
                    community: args[0],
                    joinRequest: args[1],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        community: typeof args.community === 'object'
                ? args.community.communities_id
                : args.community,
                                joinRequest: typeof args.joinRequest === 'object'
                ? args.joinRequest.community_join_requests_id
                : args.joinRequest,
                }

    return rejectJoinRequest.definition.url
            .replace('{community}', parsedArgs.community.toString())
            .replace('{joinRequest}', parsedArgs.joinRequest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\CommunityController::rejectJoinRequest
 * @see app/Http/Controllers/Api/CommunityController.php:155
 * @route '/api/communities/{community}/join-requests/{joinRequest}/reject'
 */
rejectJoinRequest.post = (args: { community: number | { communities_id: number }, joinRequest: number | { community_join_requests_id: number } } | [community: number | { communities_id: number }, joinRequest: number | { community_join_requests_id: number } ], options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: rejectJoinRequest.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\CommunityController::rejectJoinRequest
 * @see app/Http/Controllers/Api/CommunityController.php:155
 * @route '/api/communities/{community}/join-requests/{joinRequest}/reject'
 */
    const rejectJoinRequestForm = (args: { community: number | { communities_id: number }, joinRequest: number | { community_join_requests_id: number } } | [community: number | { communities_id: number }, joinRequest: number | { community_join_requests_id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: rejectJoinRequest.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\CommunityController::rejectJoinRequest
 * @see app/Http/Controllers/Api/CommunityController.php:155
 * @route '/api/communities/{community}/join-requests/{joinRequest}/reject'
 */
        rejectJoinRequestForm.post = (args: { community: number | { communities_id: number }, joinRequest: number | { community_join_requests_id: number } } | [community: number | { communities_id: number }, joinRequest: number | { community_join_requests_id: number } ], options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: rejectJoinRequest.url(args, options),
            method: 'post',
        })
    
    rejectJoinRequest.form = rejectJoinRequestForm
const CommunityController = { index, store, show, join, leave, updateMemberRole, removeMember, joinRequests, approveJoinRequest, rejectJoinRequest }

export default CommunityController