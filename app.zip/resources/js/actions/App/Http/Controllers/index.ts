import Web from './Web'
import Settings from './Settings'
import Api from './Api'
const Controllers = {
    Web: Object.assign(Web, Web),
Settings: Object.assign(Settings, Settings),
Api: Object.assign(Api, Api),
}

export default Controllers