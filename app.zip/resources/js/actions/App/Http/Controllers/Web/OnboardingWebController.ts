import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\OnboardingWebController::category
 * @see app/Http/Controllers/Web/OnboardingWebController.php:18
 * @route '/onboarding/category'
 */
export const category = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: category.url(options),
    method: 'get',
})

category.definition = {
    methods: ["get","head"],
    url: '/onboarding/category',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\OnboardingWebController::category
 * @see app/Http/Controllers/Web/OnboardingWebController.php:18
 * @route '/onboarding/category'
 */
category.url = (options?: RouteQueryOptions) => {
    return category.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\OnboardingWebController::category
 * @see app/Http/Controllers/Web/OnboardingWebController.php:18
 * @route '/onboarding/category'
 */
category.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: category.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\OnboardingWebController::category
 * @see app/Http/Controllers/Web/OnboardingWebController.php:18
 * @route '/onboarding/category'
 */
category.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: category.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\OnboardingWebController::category
 * @see app/Http/Controllers/Web/OnboardingWebController.php:18
 * @route '/onboarding/category'
 */
    const categoryForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: category.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\OnboardingWebController::category
 * @see app/Http/Controllers/Web/OnboardingWebController.php:18
 * @route '/onboarding/category'
 */
        categoryForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: category.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\OnboardingWebController::category
 * @see app/Http/Controllers/Web/OnboardingWebController.php:18
 * @route '/onboarding/category'
 */
        categoryForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: category.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    category.form = categoryForm
/**
* @see \App\Http\Controllers\Web\OnboardingWebController::storeInstrument
 * @see app/Http/Controllers/Web/OnboardingWebController.php:28
 * @route '/onboarding/instrument'
 */
export const storeInstrument = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeInstrument.url(options),
    method: 'post',
})

storeInstrument.definition = {
    methods: ["post"],
    url: '/onboarding/instrument',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\OnboardingWebController::storeInstrument
 * @see app/Http/Controllers/Web/OnboardingWebController.php:28
 * @route '/onboarding/instrument'
 */
storeInstrument.url = (options?: RouteQueryOptions) => {
    return storeInstrument.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\OnboardingWebController::storeInstrument
 * @see app/Http/Controllers/Web/OnboardingWebController.php:28
 * @route '/onboarding/instrument'
 */
storeInstrument.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeInstrument.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\OnboardingWebController::storeInstrument
 * @see app/Http/Controllers/Web/OnboardingWebController.php:28
 * @route '/onboarding/instrument'
 */
    const storeInstrumentForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeInstrument.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\OnboardingWebController::storeInstrument
 * @see app/Http/Controllers/Web/OnboardingWebController.php:28
 * @route '/onboarding/instrument'
 */
        storeInstrumentForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeInstrument.url(options),
            method: 'post',
        })
    
    storeInstrument.form = storeInstrumentForm
const OnboardingWebController = { category, storeInstrument }

export default OnboardingWebController