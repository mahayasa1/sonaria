import AuthController from './AuthController'
import DashboardController from './DashboardController'
import OnboardingWebController from './OnboardingWebController'
import CommunityWebController from './CommunityWebController'
import MainQuestWebController from './MainQuestWebController'
import DailyMissionWebController from './DailyMissionWebController'
import ChallengeWebController from './ChallengeWebController'
import ForumWebController from './ForumWebController'
import LeaderboardWebController from './LeaderboardWebController'
import ManageWebController from './ManageWebController'
import AdminWebController from './AdminWebController'
const Web = {
    AuthController: Object.assign(AuthController, AuthController),
DashboardController: Object.assign(DashboardController, DashboardController),
OnboardingWebController: Object.assign(OnboardingWebController, OnboardingWebController),
CommunityWebController: Object.assign(CommunityWebController, CommunityWebController),
MainQuestWebController: Object.assign(MainQuestWebController, MainQuestWebController),
DailyMissionWebController: Object.assign(DailyMissionWebController, DailyMissionWebController),
ChallengeWebController: Object.assign(ChallengeWebController, ChallengeWebController),
ForumWebController: Object.assign(ForumWebController, ForumWebController),
LeaderboardWebController: Object.assign(LeaderboardWebController, LeaderboardWebController),
ManageWebController: Object.assign(ManageWebController, ManageWebController),
AdminWebController: Object.assign(AdminWebController, AdminWebController),
}

export default Web