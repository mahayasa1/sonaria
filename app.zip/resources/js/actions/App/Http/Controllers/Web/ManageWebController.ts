import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\ManageWebController::members
 * @see app/Http/Controllers/Web/ManageWebController.php:25
 * @route '/manage/members'
 */
export const members = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: members.url(options),
    method: 'get',
})

members.definition = {
    methods: ["get","head"],
    url: '/manage/members',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\ManageWebController::members
 * @see app/Http/Controllers/Web/ManageWebController.php:25
 * @route '/manage/members'
 */
members.url = (options?: RouteQueryOptions) => {
    return members.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\ManageWebController::members
 * @see app/Http/Controllers/Web/ManageWebController.php:25
 * @route '/manage/members'
 */
members.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: members.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\ManageWebController::members
 * @see app/Http/Controllers/Web/ManageWebController.php:25
 * @route '/manage/members'
 */
members.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: members.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\ManageWebController::members
 * @see app/Http/Controllers/Web/ManageWebController.php:25
 * @route '/manage/members'
 */
    const membersForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: members.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\ManageWebController::members
 * @see app/Http/Controllers/Web/ManageWebController.php:25
 * @route '/manage/members'
 */
        membersForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: members.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\ManageWebController::members
 * @see app/Http/Controllers/Web/ManageWebController.php:25
 * @route '/manage/members'
 */
        membersForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: members.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    members.form = membersForm
/**
* @see \App\Http\Controllers\Web\ManageWebController::reviews
 * @see app/Http/Controllers/Web/ManageWebController.php:86
 * @route '/manage/reviews'
 */
export const reviews = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reviews.url(options),
    method: 'get',
})

reviews.definition = {
    methods: ["get","head"],
    url: '/manage/reviews',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\ManageWebController::reviews
 * @see app/Http/Controllers/Web/ManageWebController.php:86
 * @route '/manage/reviews'
 */
reviews.url = (options?: RouteQueryOptions) => {
    return reviews.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\ManageWebController::reviews
 * @see app/Http/Controllers/Web/ManageWebController.php:86
 * @route '/manage/reviews'
 */
reviews.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reviews.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\ManageWebController::reviews
 * @see app/Http/Controllers/Web/ManageWebController.php:86
 * @route '/manage/reviews'
 */
reviews.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: reviews.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\ManageWebController::reviews
 * @see app/Http/Controllers/Web/ManageWebController.php:86
 * @route '/manage/reviews'
 */
    const reviewsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: reviews.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\ManageWebController::reviews
 * @see app/Http/Controllers/Web/ManageWebController.php:86
 * @route '/manage/reviews'
 */
        reviewsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: reviews.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\ManageWebController::reviews
 * @see app/Http/Controllers/Web/ManageWebController.php:86
 * @route '/manage/reviews'
 */
        reviewsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: reviews.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    reviews.form = reviewsForm
/**
* @see \App\Http\Controllers\Web\ManageWebController::mainQuestCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:46
 * @route '/manage/main-quests/create'
 */
export const mainQuestCreate = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: mainQuestCreate.url(options),
    method: 'get',
})

mainQuestCreate.definition = {
    methods: ["get","head"],
    url: '/manage/main-quests/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\ManageWebController::mainQuestCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:46
 * @route '/manage/main-quests/create'
 */
mainQuestCreate.url = (options?: RouteQueryOptions) => {
    return mainQuestCreate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\ManageWebController::mainQuestCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:46
 * @route '/manage/main-quests/create'
 */
mainQuestCreate.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: mainQuestCreate.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\ManageWebController::mainQuestCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:46
 * @route '/manage/main-quests/create'
 */
mainQuestCreate.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: mainQuestCreate.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\ManageWebController::mainQuestCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:46
 * @route '/manage/main-quests/create'
 */
    const mainQuestCreateForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: mainQuestCreate.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\ManageWebController::mainQuestCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:46
 * @route '/manage/main-quests/create'
 */
        mainQuestCreateForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: mainQuestCreate.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\ManageWebController::mainQuestCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:46
 * @route '/manage/main-quests/create'
 */
        mainQuestCreateForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: mainQuestCreate.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    mainQuestCreate.form = mainQuestCreateForm
/**
* @see \App\Http\Controllers\Web\ManageWebController::materialCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:114
 * @route '/manage/main-quests/{mainQuest}/materials/create'
 */
export const materialCreate = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: materialCreate.url(args, options),
    method: 'get',
})

materialCreate.definition = {
    methods: ["get","head"],
    url: '/manage/main-quests/{mainQuest}/materials/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\ManageWebController::materialCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:114
 * @route '/manage/main-quests/{mainQuest}/materials/create'
 */
materialCreate.url = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { mainQuest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'main_quests_id' in args) {
            args = { mainQuest: args.main_quests_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    mainQuest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        mainQuest: typeof args.mainQuest === 'object'
                ? args.mainQuest.main_quests_id
                : args.mainQuest,
                }

    return materialCreate.definition.url
            .replace('{mainQuest}', parsedArgs.mainQuest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\ManageWebController::materialCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:114
 * @route '/manage/main-quests/{mainQuest}/materials/create'
 */
materialCreate.get = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: materialCreate.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\ManageWebController::materialCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:114
 * @route '/manage/main-quests/{mainQuest}/materials/create'
 */
materialCreate.head = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: materialCreate.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\ManageWebController::materialCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:114
 * @route '/manage/main-quests/{mainQuest}/materials/create'
 */
    const materialCreateForm = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: materialCreate.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\ManageWebController::materialCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:114
 * @route '/manage/main-quests/{mainQuest}/materials/create'
 */
        materialCreateForm.get = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: materialCreate.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\ManageWebController::materialCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:114
 * @route '/manage/main-quests/{mainQuest}/materials/create'
 */
        materialCreateForm.head = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: materialCreate.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    materialCreate.form = materialCreateForm
/**
* @see \App\Http\Controllers\Web\ManageWebController::quizCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:125
 * @route '/manage/materials/{material}/quizzes/create'
 */
export const quizCreate = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: quizCreate.url(args, options),
    method: 'get',
})

quizCreate.definition = {
    methods: ["get","head"],
    url: '/manage/materials/{material}/quizzes/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\ManageWebController::quizCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:125
 * @route '/manage/materials/{material}/quizzes/create'
 */
quizCreate.url = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { material: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'materials_id' in args) {
            args = { material: args.materials_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    material: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        material: typeof args.material === 'object'
                ? args.material.materials_id
                : args.material,
                }

    return quizCreate.definition.url
            .replace('{material}', parsedArgs.material.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\ManageWebController::quizCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:125
 * @route '/manage/materials/{material}/quizzes/create'
 */
quizCreate.get = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: quizCreate.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\ManageWebController::quizCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:125
 * @route '/manage/materials/{material}/quizzes/create'
 */
quizCreate.head = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: quizCreate.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\ManageWebController::quizCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:125
 * @route '/manage/materials/{material}/quizzes/create'
 */
    const quizCreateForm = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: quizCreate.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\ManageWebController::quizCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:125
 * @route '/manage/materials/{material}/quizzes/create'
 */
        quizCreateForm.get = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: quizCreate.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\ManageWebController::quizCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:125
 * @route '/manage/materials/{material}/quizzes/create'
 */
        quizCreateForm.head = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: quizCreate.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    quizCreate.form = quizCreateForm
/**
* @see \App\Http\Controllers\Web\ManageWebController::practiceCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:135
 * @route '/manage/materials/{material}/practices/create'
 */
export const practiceCreate = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: practiceCreate.url(args, options),
    method: 'get',
})

practiceCreate.definition = {
    methods: ["get","head"],
    url: '/manage/materials/{material}/practices/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\ManageWebController::practiceCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:135
 * @route '/manage/materials/{material}/practices/create'
 */
practiceCreate.url = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { material: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'materials_id' in args) {
            args = { material: args.materials_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    material: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        material: typeof args.material === 'object'
                ? args.material.materials_id
                : args.material,
                }

    return practiceCreate.definition.url
            .replace('{material}', parsedArgs.material.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\ManageWebController::practiceCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:135
 * @route '/manage/materials/{material}/practices/create'
 */
practiceCreate.get = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: practiceCreate.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\ManageWebController::practiceCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:135
 * @route '/manage/materials/{material}/practices/create'
 */
practiceCreate.head = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: practiceCreate.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\ManageWebController::practiceCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:135
 * @route '/manage/materials/{material}/practices/create'
 */
    const practiceCreateForm = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: practiceCreate.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\ManageWebController::practiceCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:135
 * @route '/manage/materials/{material}/practices/create'
 */
        practiceCreateForm.get = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: practiceCreate.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\ManageWebController::practiceCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:135
 * @route '/manage/materials/{material}/practices/create'
 */
        practiceCreateForm.head = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: practiceCreate.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    practiceCreate.form = practiceCreateForm
/**
* @see \App\Http\Controllers\Web\ManageWebController::materialFileCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:145
 * @route '/manage/materials/{material}/files/create'
 */
export const materialFileCreate = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: materialFileCreate.url(args, options),
    method: 'get',
})

materialFileCreate.definition = {
    methods: ["get","head"],
    url: '/manage/materials/{material}/files/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\ManageWebController::materialFileCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:145
 * @route '/manage/materials/{material}/files/create'
 */
materialFileCreate.url = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { material: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'materials_id' in args) {
            args = { material: args.materials_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    material: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        material: typeof args.material === 'object'
                ? args.material.materials_id
                : args.material,
                }

    return materialFileCreate.definition.url
            .replace('{material}', parsedArgs.material.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\ManageWebController::materialFileCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:145
 * @route '/manage/materials/{material}/files/create'
 */
materialFileCreate.get = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: materialFileCreate.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\ManageWebController::materialFileCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:145
 * @route '/manage/materials/{material}/files/create'
 */
materialFileCreate.head = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: materialFileCreate.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\ManageWebController::materialFileCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:145
 * @route '/manage/materials/{material}/files/create'
 */
    const materialFileCreateForm = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: materialFileCreate.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\ManageWebController::materialFileCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:145
 * @route '/manage/materials/{material}/files/create'
 */
        materialFileCreateForm.get = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: materialFileCreate.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\ManageWebController::materialFileCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:145
 * @route '/manage/materials/{material}/files/create'
 */
        materialFileCreateForm.head = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: materialFileCreate.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    materialFileCreate.form = materialFileCreateForm
/**
* @see \App\Http\Controllers\Web\ManageWebController::dailyMissionCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:59
 * @route '/manage/daily-missions/create'
 */
export const dailyMissionCreate = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dailyMissionCreate.url(options),
    method: 'get',
})

dailyMissionCreate.definition = {
    methods: ["get","head"],
    url: '/manage/daily-missions/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\ManageWebController::dailyMissionCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:59
 * @route '/manage/daily-missions/create'
 */
dailyMissionCreate.url = (options?: RouteQueryOptions) => {
    return dailyMissionCreate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\ManageWebController::dailyMissionCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:59
 * @route '/manage/daily-missions/create'
 */
dailyMissionCreate.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dailyMissionCreate.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\ManageWebController::dailyMissionCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:59
 * @route '/manage/daily-missions/create'
 */
dailyMissionCreate.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dailyMissionCreate.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\ManageWebController::dailyMissionCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:59
 * @route '/manage/daily-missions/create'
 */
    const dailyMissionCreateForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dailyMissionCreate.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\ManageWebController::dailyMissionCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:59
 * @route '/manage/daily-missions/create'
 */
        dailyMissionCreateForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dailyMissionCreate.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\ManageWebController::dailyMissionCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:59
 * @route '/manage/daily-missions/create'
 */
        dailyMissionCreateForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dailyMissionCreate.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dailyMissionCreate.form = dailyMissionCreateForm
/**
* @see \App\Http\Controllers\Web\ManageWebController::challengeCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:72
 * @route '/manage/challenge/create'
 */
export const challengeCreate = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: challengeCreate.url(options),
    method: 'get',
})

challengeCreate.definition = {
    methods: ["get","head"],
    url: '/manage/challenge/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\ManageWebController::challengeCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:72
 * @route '/manage/challenge/create'
 */
challengeCreate.url = (options?: RouteQueryOptions) => {
    return challengeCreate.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\ManageWebController::challengeCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:72
 * @route '/manage/challenge/create'
 */
challengeCreate.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: challengeCreate.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\ManageWebController::challengeCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:72
 * @route '/manage/challenge/create'
 */
challengeCreate.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: challengeCreate.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\ManageWebController::challengeCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:72
 * @route '/manage/challenge/create'
 */
    const challengeCreateForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: challengeCreate.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\ManageWebController::challengeCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:72
 * @route '/manage/challenge/create'
 */
        challengeCreateForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: challengeCreate.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\ManageWebController::challengeCreate
 * @see app/Http/Controllers/Web/ManageWebController.php:72
 * @route '/manage/challenge/create'
 */
        challengeCreateForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: challengeCreate.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    challengeCreate.form = challengeCreateForm
/**
* @see \App\Http\Controllers\Web\ManageWebController::reviewPractice
 * @see app/Http/Controllers/Web/ManageWebController.php:155
 * @route '/manage/practice-submissions/{submission}'
 */
export const reviewPractice = (args: { submission: number | { practice_submissions_id: number } } | [submission: number | { practice_submissions_id: number } ] | number | { practice_submissions_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reviewPractice.url(args, options),
    method: 'get',
})

reviewPractice.definition = {
    methods: ["get","head"],
    url: '/manage/practice-submissions/{submission}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\ManageWebController::reviewPractice
 * @see app/Http/Controllers/Web/ManageWebController.php:155
 * @route '/manage/practice-submissions/{submission}'
 */
reviewPractice.url = (args: { submission: number | { practice_submissions_id: number } } | [submission: number | { practice_submissions_id: number } ] | number | { practice_submissions_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { submission: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'practice_submissions_id' in args) {
            args = { submission: args.practice_submissions_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    submission: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        submission: typeof args.submission === 'object'
                ? args.submission.practice_submissions_id
                : args.submission,
                }

    return reviewPractice.definition.url
            .replace('{submission}', parsedArgs.submission.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\ManageWebController::reviewPractice
 * @see app/Http/Controllers/Web/ManageWebController.php:155
 * @route '/manage/practice-submissions/{submission}'
 */
reviewPractice.get = (args: { submission: number | { practice_submissions_id: number } } | [submission: number | { practice_submissions_id: number } ] | number | { practice_submissions_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reviewPractice.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\ManageWebController::reviewPractice
 * @see app/Http/Controllers/Web/ManageWebController.php:155
 * @route '/manage/practice-submissions/{submission}'
 */
reviewPractice.head = (args: { submission: number | { practice_submissions_id: number } } | [submission: number | { practice_submissions_id: number } ] | number | { practice_submissions_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: reviewPractice.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\ManageWebController::reviewPractice
 * @see app/Http/Controllers/Web/ManageWebController.php:155
 * @route '/manage/practice-submissions/{submission}'
 */
    const reviewPracticeForm = (args: { submission: number | { practice_submissions_id: number } } | [submission: number | { practice_submissions_id: number } ] | number | { practice_submissions_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: reviewPractice.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\ManageWebController::reviewPractice
 * @see app/Http/Controllers/Web/ManageWebController.php:155
 * @route '/manage/practice-submissions/{submission}'
 */
        reviewPracticeForm.get = (args: { submission: number | { practice_submissions_id: number } } | [submission: number | { practice_submissions_id: number } ] | number | { practice_submissions_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: reviewPractice.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\ManageWebController::reviewPractice
 * @see app/Http/Controllers/Web/ManageWebController.php:155
 * @route '/manage/practice-submissions/{submission}'
 */
        reviewPracticeForm.head = (args: { submission: number | { practice_submissions_id: number } } | [submission: number | { practice_submissions_id: number } ] | number | { practice_submissions_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: reviewPractice.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    reviewPractice.form = reviewPracticeForm
/**
* @see \App\Http\Controllers\Web\ManageWebController::reviewChallenge
 * @see app/Http/Controllers/Web/ManageWebController.php:165
 * @route '/manage/challenge-submissions/{submission}'
 */
export const reviewChallenge = (args: { submission: number | { challenge_submissions_id: number } } | [submission: number | { challenge_submissions_id: number } ] | number | { challenge_submissions_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reviewChallenge.url(args, options),
    method: 'get',
})

reviewChallenge.definition = {
    methods: ["get","head"],
    url: '/manage/challenge-submissions/{submission}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\ManageWebController::reviewChallenge
 * @see app/Http/Controllers/Web/ManageWebController.php:165
 * @route '/manage/challenge-submissions/{submission}'
 */
reviewChallenge.url = (args: { submission: number | { challenge_submissions_id: number } } | [submission: number | { challenge_submissions_id: number } ] | number | { challenge_submissions_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { submission: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'challenge_submissions_id' in args) {
            args = { submission: args.challenge_submissions_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    submission: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        submission: typeof args.submission === 'object'
                ? args.submission.challenge_submissions_id
                : args.submission,
                }

    return reviewChallenge.definition.url
            .replace('{submission}', parsedArgs.submission.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\ManageWebController::reviewChallenge
 * @see app/Http/Controllers/Web/ManageWebController.php:165
 * @route '/manage/challenge-submissions/{submission}'
 */
reviewChallenge.get = (args: { submission: number | { challenge_submissions_id: number } } | [submission: number | { challenge_submissions_id: number } ] | number | { challenge_submissions_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reviewChallenge.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\ManageWebController::reviewChallenge
 * @see app/Http/Controllers/Web/ManageWebController.php:165
 * @route '/manage/challenge-submissions/{submission}'
 */
reviewChallenge.head = (args: { submission: number | { challenge_submissions_id: number } } | [submission: number | { challenge_submissions_id: number } ] | number | { challenge_submissions_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: reviewChallenge.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\ManageWebController::reviewChallenge
 * @see app/Http/Controllers/Web/ManageWebController.php:165
 * @route '/manage/challenge-submissions/{submission}'
 */
    const reviewChallengeForm = (args: { submission: number | { challenge_submissions_id: number } } | [submission: number | { challenge_submissions_id: number } ] | number | { challenge_submissions_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: reviewChallenge.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\ManageWebController::reviewChallenge
 * @see app/Http/Controllers/Web/ManageWebController.php:165
 * @route '/manage/challenge-submissions/{submission}'
 */
        reviewChallengeForm.get = (args: { submission: number | { challenge_submissions_id: number } } | [submission: number | { challenge_submissions_id: number } ] | number | { challenge_submissions_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: reviewChallenge.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\ManageWebController::reviewChallenge
 * @see app/Http/Controllers/Web/ManageWebController.php:165
 * @route '/manage/challenge-submissions/{submission}'
 */
        reviewChallengeForm.head = (args: { submission: number | { challenge_submissions_id: number } } | [submission: number | { challenge_submissions_id: number } ] | number | { challenge_submissions_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: reviewChallenge.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    reviewChallenge.form = reviewChallengeForm
const ManageWebController = { members, reviews, mainQuestCreate, materialCreate, quizCreate, practiceCreate, materialFileCreate, dailyMissionCreate, challengeCreate, reviewPractice, reviewChallenge }

export default ManageWebController