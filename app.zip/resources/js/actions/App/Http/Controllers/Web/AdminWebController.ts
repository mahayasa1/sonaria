import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\AdminWebController::users
 * @see app/Http/Controllers/Web/AdminWebController.php:27
 * @route '/admin/users'
 */
export const users = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: users.url(options),
    method: 'get',
})

users.definition = {
    methods: ["get","head"],
    url: '/admin/users',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\AdminWebController::users
 * @see app/Http/Controllers/Web/AdminWebController.php:27
 * @route '/admin/users'
 */
users.url = (options?: RouteQueryOptions) => {
    return users.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AdminWebController::users
 * @see app/Http/Controllers/Web/AdminWebController.php:27
 * @route '/admin/users'
 */
users.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: users.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\AdminWebController::users
 * @see app/Http/Controllers/Web/AdminWebController.php:27
 * @route '/admin/users'
 */
users.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: users.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\AdminWebController::users
 * @see app/Http/Controllers/Web/AdminWebController.php:27
 * @route '/admin/users'
 */
    const usersForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: users.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\AdminWebController::users
 * @see app/Http/Controllers/Web/AdminWebController.php:27
 * @route '/admin/users'
 */
        usersForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: users.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\AdminWebController::users
 * @see app/Http/Controllers/Web/AdminWebController.php:27
 * @route '/admin/users'
 */
        usersForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: users.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    users.form = usersForm
/**
* @see \App\Http\Controllers\Web\AdminWebController::toggleUserStatus
 * @see app/Http/Controllers/Web/AdminWebController.php:46
 * @route '/admin/users/{user}/toggle-status'
 */
export const toggleUserStatus = (args: { user: number | { users_id: number } } | [user: number | { users_id: number } ] | number | { users_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleUserStatus.url(args, options),
    method: 'post',
})

toggleUserStatus.definition = {
    methods: ["post"],
    url: '/admin/users/{user}/toggle-status',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\AdminWebController::toggleUserStatus
 * @see app/Http/Controllers/Web/AdminWebController.php:46
 * @route '/admin/users/{user}/toggle-status'
 */
toggleUserStatus.url = (args: { user: number | { users_id: number } } | [user: number | { users_id: number } ] | number | { users_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'users_id' in args) {
            args = { user: args.users_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.users_id
                : args.user,
                }

    return toggleUserStatus.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AdminWebController::toggleUserStatus
 * @see app/Http/Controllers/Web/AdminWebController.php:46
 * @route '/admin/users/{user}/toggle-status'
 */
toggleUserStatus.post = (args: { user: number | { users_id: number } } | [user: number | { users_id: number } ] | number | { users_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleUserStatus.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\AdminWebController::toggleUserStatus
 * @see app/Http/Controllers/Web/AdminWebController.php:46
 * @route '/admin/users/{user}/toggle-status'
 */
    const toggleUserStatusForm = (args: { user: number | { users_id: number } } | [user: number | { users_id: number } ] | number | { users_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleUserStatus.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\AdminWebController::toggleUserStatus
 * @see app/Http/Controllers/Web/AdminWebController.php:46
 * @route '/admin/users/{user}/toggle-status'
 */
        toggleUserStatusForm.post = (args: { user: number | { users_id: number } } | [user: number | { users_id: number } ] | number | { users_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleUserStatus.url(args, options),
            method: 'post',
        })
    
    toggleUserStatus.form = toggleUserStatusForm
/**
* @see \App\Http\Controllers\Web\AdminWebController::communities
 * @see app/Http/Controllers/Web/AdminWebController.php:55
 * @route '/admin/communities'
 */
export const communities = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: communities.url(options),
    method: 'get',
})

communities.definition = {
    methods: ["get","head"],
    url: '/admin/communities',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\AdminWebController::communities
 * @see app/Http/Controllers/Web/AdminWebController.php:55
 * @route '/admin/communities'
 */
communities.url = (options?: RouteQueryOptions) => {
    return communities.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AdminWebController::communities
 * @see app/Http/Controllers/Web/AdminWebController.php:55
 * @route '/admin/communities'
 */
communities.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: communities.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\AdminWebController::communities
 * @see app/Http/Controllers/Web/AdminWebController.php:55
 * @route '/admin/communities'
 */
communities.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: communities.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\AdminWebController::communities
 * @see app/Http/Controllers/Web/AdminWebController.php:55
 * @route '/admin/communities'
 */
    const communitiesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: communities.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\AdminWebController::communities
 * @see app/Http/Controllers/Web/AdminWebController.php:55
 * @route '/admin/communities'
 */
        communitiesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: communities.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\AdminWebController::communities
 * @see app/Http/Controllers/Web/AdminWebController.php:55
 * @route '/admin/communities'
 */
        communitiesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: communities.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    communities.form = communitiesForm
/**
* @see \App\Http\Controllers\Web\AdminWebController::toggleCommunityStatus
 * @see app/Http/Controllers/Web/AdminWebController.php:71
 * @route '/admin/communities/{community}/toggle-status'
 */
export const toggleCommunityStatus = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleCommunityStatus.url(args, options),
    method: 'post',
})

toggleCommunityStatus.definition = {
    methods: ["post"],
    url: '/admin/communities/{community}/toggle-status',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\AdminWebController::toggleCommunityStatus
 * @see app/Http/Controllers/Web/AdminWebController.php:71
 * @route '/admin/communities/{community}/toggle-status'
 */
toggleCommunityStatus.url = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { community: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'communities_id' in args) {
            args = { community: args.communities_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    community: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        community: typeof args.community === 'object'
                ? args.community.communities_id
                : args.community,
                }

    return toggleCommunityStatus.definition.url
            .replace('{community}', parsedArgs.community.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AdminWebController::toggleCommunityStatus
 * @see app/Http/Controllers/Web/AdminWebController.php:71
 * @route '/admin/communities/{community}/toggle-status'
 */
toggleCommunityStatus.post = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleCommunityStatus.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\AdminWebController::toggleCommunityStatus
 * @see app/Http/Controllers/Web/AdminWebController.php:71
 * @route '/admin/communities/{community}/toggle-status'
 */
    const toggleCommunityStatusForm = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleCommunityStatus.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\AdminWebController::toggleCommunityStatus
 * @see app/Http/Controllers/Web/AdminWebController.php:71
 * @route '/admin/communities/{community}/toggle-status'
 */
        toggleCommunityStatusForm.post = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleCommunityStatus.url(args, options),
            method: 'post',
        })
    
    toggleCommunityStatus.form = toggleCommunityStatusForm
/**
* @see \App\Http\Controllers\Web\AdminWebController::categories
 * @see app/Http/Controllers/Web/AdminWebController.php:80
 * @route '/admin/categories'
 */
export const categories = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: categories.url(options),
    method: 'get',
})

categories.definition = {
    methods: ["get","head"],
    url: '/admin/categories',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\AdminWebController::categories
 * @see app/Http/Controllers/Web/AdminWebController.php:80
 * @route '/admin/categories'
 */
categories.url = (options?: RouteQueryOptions) => {
    return categories.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AdminWebController::categories
 * @see app/Http/Controllers/Web/AdminWebController.php:80
 * @route '/admin/categories'
 */
categories.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: categories.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\AdminWebController::categories
 * @see app/Http/Controllers/Web/AdminWebController.php:80
 * @route '/admin/categories'
 */
categories.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: categories.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\AdminWebController::categories
 * @see app/Http/Controllers/Web/AdminWebController.php:80
 * @route '/admin/categories'
 */
    const categoriesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: categories.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\AdminWebController::categories
 * @see app/Http/Controllers/Web/AdminWebController.php:80
 * @route '/admin/categories'
 */
        categoriesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: categories.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\AdminWebController::categories
 * @see app/Http/Controllers/Web/AdminWebController.php:80
 * @route '/admin/categories'
 */
        categoriesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: categories.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    categories.form = categoriesForm
/**
* @see \App\Http\Controllers\Web\AdminWebController::storeCategory
 * @see app/Http/Controllers/Web/AdminWebController.php:92
 * @route '/admin/categories'
 */
export const storeCategory = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCategory.url(options),
    method: 'post',
})

storeCategory.definition = {
    methods: ["post"],
    url: '/admin/categories',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\AdminWebController::storeCategory
 * @see app/Http/Controllers/Web/AdminWebController.php:92
 * @route '/admin/categories'
 */
storeCategory.url = (options?: RouteQueryOptions) => {
    return storeCategory.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AdminWebController::storeCategory
 * @see app/Http/Controllers/Web/AdminWebController.php:92
 * @route '/admin/categories'
 */
storeCategory.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCategory.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\AdminWebController::storeCategory
 * @see app/Http/Controllers/Web/AdminWebController.php:92
 * @route '/admin/categories'
 */
    const storeCategoryForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeCategory.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\AdminWebController::storeCategory
 * @see app/Http/Controllers/Web/AdminWebController.php:92
 * @route '/admin/categories'
 */
        storeCategoryForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeCategory.url(options),
            method: 'post',
        })
    
    storeCategory.form = storeCategoryForm
/**
* @see \App\Http\Controllers\Web\AdminWebController::destroyCategory
 * @see app/Http/Controllers/Web/AdminWebController.php:107
 * @route '/admin/categories/{category}'
 */
export const destroyCategory = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyCategory.url(args, options),
    method: 'delete',
})

destroyCategory.definition = {
    methods: ["delete"],
    url: '/admin/categories/{category}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Web\AdminWebController::destroyCategory
 * @see app/Http/Controllers/Web/AdminWebController.php:107
 * @route '/admin/categories/{category}'
 */
destroyCategory.url = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'music_categories_id' in args) {
            args = { category: args.music_categories_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    category: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        category: typeof args.category === 'object'
                ? args.category.music_categories_id
                : args.category,
                }

    return destroyCategory.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AdminWebController::destroyCategory
 * @see app/Http/Controllers/Web/AdminWebController.php:107
 * @route '/admin/categories/{category}'
 */
destroyCategory.delete = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyCategory.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Web\AdminWebController::destroyCategory
 * @see app/Http/Controllers/Web/AdminWebController.php:107
 * @route '/admin/categories/{category}'
 */
    const destroyCategoryForm = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyCategory.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\AdminWebController::destroyCategory
 * @see app/Http/Controllers/Web/AdminWebController.php:107
 * @route '/admin/categories/{category}'
 */
        destroyCategoryForm.delete = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyCategory.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyCategory.form = destroyCategoryForm
/**
* @see \App\Http\Controllers\Web\AdminWebController::storeInstrument
 * @see app/Http/Controllers/Web/AdminWebController.php:120
 * @route '/admin/categories/{category}/instruments'
 */
export const storeInstrument = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeInstrument.url(args, options),
    method: 'post',
})

storeInstrument.definition = {
    methods: ["post"],
    url: '/admin/categories/{category}/instruments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\AdminWebController::storeInstrument
 * @see app/Http/Controllers/Web/AdminWebController.php:120
 * @route '/admin/categories/{category}/instruments'
 */
storeInstrument.url = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'music_categories_id' in args) {
            args = { category: args.music_categories_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    category: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        category: typeof args.category === 'object'
                ? args.category.music_categories_id
                : args.category,
                }

    return storeInstrument.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AdminWebController::storeInstrument
 * @see app/Http/Controllers/Web/AdminWebController.php:120
 * @route '/admin/categories/{category}/instruments'
 */
storeInstrument.post = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeInstrument.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\AdminWebController::storeInstrument
 * @see app/Http/Controllers/Web/AdminWebController.php:120
 * @route '/admin/categories/{category}/instruments'
 */
    const storeInstrumentForm = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeInstrument.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\AdminWebController::storeInstrument
 * @see app/Http/Controllers/Web/AdminWebController.php:120
 * @route '/admin/categories/{category}/instruments'
 */
        storeInstrumentForm.post = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeInstrument.url(args, options),
            method: 'post',
        })
    
    storeInstrument.form = storeInstrumentForm
/**
* @see \App\Http\Controllers\Web\AdminWebController::destroyInstrument
 * @see app/Http/Controllers/Web/AdminWebController.php:135
 * @route '/admin/instruments/{instrument}'
 */
export const destroyInstrument = (args: { instrument: number | { intruments_id: number } } | [instrument: number | { intruments_id: number } ] | number | { intruments_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyInstrument.url(args, options),
    method: 'delete',
})

destroyInstrument.definition = {
    methods: ["delete"],
    url: '/admin/instruments/{instrument}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Web\AdminWebController::destroyInstrument
 * @see app/Http/Controllers/Web/AdminWebController.php:135
 * @route '/admin/instruments/{instrument}'
 */
destroyInstrument.url = (args: { instrument: number | { intruments_id: number } } | [instrument: number | { intruments_id: number } ] | number | { intruments_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { instrument: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'intruments_id' in args) {
            args = { instrument: args.intruments_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    instrument: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        instrument: typeof args.instrument === 'object'
                ? args.instrument.intruments_id
                : args.instrument,
                }

    return destroyInstrument.definition.url
            .replace('{instrument}', parsedArgs.instrument.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AdminWebController::destroyInstrument
 * @see app/Http/Controllers/Web/AdminWebController.php:135
 * @route '/admin/instruments/{instrument}'
 */
destroyInstrument.delete = (args: { instrument: number | { intruments_id: number } } | [instrument: number | { intruments_id: number } ] | number | { intruments_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyInstrument.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Web\AdminWebController::destroyInstrument
 * @see app/Http/Controllers/Web/AdminWebController.php:135
 * @route '/admin/instruments/{instrument}'
 */
    const destroyInstrumentForm = (args: { instrument: number | { intruments_id: number } } | [instrument: number | { intruments_id: number } ] | number | { intruments_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyInstrument.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\AdminWebController::destroyInstrument
 * @see app/Http/Controllers/Web/AdminWebController.php:135
 * @route '/admin/instruments/{instrument}'
 */
        destroyInstrumentForm.delete = (args: { instrument: number | { intruments_id: number } } | [instrument: number | { intruments_id: number } ] | number | { intruments_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyInstrument.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyInstrument.form = destroyInstrumentForm
/**
* @see \App\Http\Controllers\Web\AdminWebController::achievements
 * @see app/Http/Controllers/Web/AdminWebController.php:148
 * @route '/admin/achievements'
 */
export const achievements = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: achievements.url(options),
    method: 'get',
})

achievements.definition = {
    methods: ["get","head"],
    url: '/admin/achievements',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\AdminWebController::achievements
 * @see app/Http/Controllers/Web/AdminWebController.php:148
 * @route '/admin/achievements'
 */
achievements.url = (options?: RouteQueryOptions) => {
    return achievements.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AdminWebController::achievements
 * @see app/Http/Controllers/Web/AdminWebController.php:148
 * @route '/admin/achievements'
 */
achievements.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: achievements.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\AdminWebController::achievements
 * @see app/Http/Controllers/Web/AdminWebController.php:148
 * @route '/admin/achievements'
 */
achievements.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: achievements.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\AdminWebController::achievements
 * @see app/Http/Controllers/Web/AdminWebController.php:148
 * @route '/admin/achievements'
 */
    const achievementsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: achievements.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\AdminWebController::achievements
 * @see app/Http/Controllers/Web/AdminWebController.php:148
 * @route '/admin/achievements'
 */
        achievementsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: achievements.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\AdminWebController::achievements
 * @see app/Http/Controllers/Web/AdminWebController.php:148
 * @route '/admin/achievements'
 */
        achievementsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: achievements.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    achievements.form = achievementsForm
/**
* @see \App\Http\Controllers\Web\AdminWebController::storeAchievement
 * @see app/Http/Controllers/Web/AdminWebController.php:157
 * @route '/admin/achievements'
 */
export const storeAchievement = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeAchievement.url(options),
    method: 'post',
})

storeAchievement.definition = {
    methods: ["post"],
    url: '/admin/achievements',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\AdminWebController::storeAchievement
 * @see app/Http/Controllers/Web/AdminWebController.php:157
 * @route '/admin/achievements'
 */
storeAchievement.url = (options?: RouteQueryOptions) => {
    return storeAchievement.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AdminWebController::storeAchievement
 * @see app/Http/Controllers/Web/AdminWebController.php:157
 * @route '/admin/achievements'
 */
storeAchievement.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeAchievement.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\AdminWebController::storeAchievement
 * @see app/Http/Controllers/Web/AdminWebController.php:157
 * @route '/admin/achievements'
 */
    const storeAchievementForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeAchievement.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\AdminWebController::storeAchievement
 * @see app/Http/Controllers/Web/AdminWebController.php:157
 * @route '/admin/achievements'
 */
        storeAchievementForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeAchievement.url(options),
            method: 'post',
        })
    
    storeAchievement.form = storeAchievementForm
/**
* @see \App\Http\Controllers\Web\AdminWebController::destroyAchievement
 * @see app/Http/Controllers/Web/AdminWebController.php:174
 * @route '/admin/achievements/{achievement}'
 */
export const destroyAchievement = (args: { achievement: number | { achievements_id: number } } | [achievement: number | { achievements_id: number } ] | number | { achievements_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyAchievement.url(args, options),
    method: 'delete',
})

destroyAchievement.definition = {
    methods: ["delete"],
    url: '/admin/achievements/{achievement}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Web\AdminWebController::destroyAchievement
 * @see app/Http/Controllers/Web/AdminWebController.php:174
 * @route '/admin/achievements/{achievement}'
 */
destroyAchievement.url = (args: { achievement: number | { achievements_id: number } } | [achievement: number | { achievements_id: number } ] | number | { achievements_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { achievement: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'achievements_id' in args) {
            args = { achievement: args.achievements_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    achievement: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        achievement: typeof args.achievement === 'object'
                ? args.achievement.achievements_id
                : args.achievement,
                }

    return destroyAchievement.definition.url
            .replace('{achievement}', parsedArgs.achievement.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AdminWebController::destroyAchievement
 * @see app/Http/Controllers/Web/AdminWebController.php:174
 * @route '/admin/achievements/{achievement}'
 */
destroyAchievement.delete = (args: { achievement: number | { achievements_id: number } } | [achievement: number | { achievements_id: number } ] | number | { achievements_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyAchievement.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Web\AdminWebController::destroyAchievement
 * @see app/Http/Controllers/Web/AdminWebController.php:174
 * @route '/admin/achievements/{achievement}'
 */
    const destroyAchievementForm = (args: { achievement: number | { achievements_id: number } } | [achievement: number | { achievements_id: number } ] | number | { achievements_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyAchievement.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\AdminWebController::destroyAchievement
 * @see app/Http/Controllers/Web/AdminWebController.php:174
 * @route '/admin/achievements/{achievement}'
 */
        destroyAchievementForm.delete = (args: { achievement: number | { achievements_id: number } } | [achievement: number | { achievements_id: number } ] | number | { achievements_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyAchievement.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyAchievement.form = destroyAchievementForm
/**
* @see \App\Http\Controllers\Web\AdminWebController::badges
 * @see app/Http/Controllers/Web/AdminWebController.php:182
 * @route '/admin/badges'
 */
export const badges = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: badges.url(options),
    method: 'get',
})

badges.definition = {
    methods: ["get","head"],
    url: '/admin/badges',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\AdminWebController::badges
 * @see app/Http/Controllers/Web/AdminWebController.php:182
 * @route '/admin/badges'
 */
badges.url = (options?: RouteQueryOptions) => {
    return badges.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AdminWebController::badges
 * @see app/Http/Controllers/Web/AdminWebController.php:182
 * @route '/admin/badges'
 */
badges.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: badges.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\AdminWebController::badges
 * @see app/Http/Controllers/Web/AdminWebController.php:182
 * @route '/admin/badges'
 */
badges.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: badges.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\AdminWebController::badges
 * @see app/Http/Controllers/Web/AdminWebController.php:182
 * @route '/admin/badges'
 */
    const badgesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: badges.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\AdminWebController::badges
 * @see app/Http/Controllers/Web/AdminWebController.php:182
 * @route '/admin/badges'
 */
        badgesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: badges.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\AdminWebController::badges
 * @see app/Http/Controllers/Web/AdminWebController.php:182
 * @route '/admin/badges'
 */
        badgesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: badges.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    badges.form = badgesForm
/**
* @see \App\Http\Controllers\Web\AdminWebController::storeBadge
 * @see app/Http/Controllers/Web/AdminWebController.php:191
 * @route '/admin/badges'
 */
export const storeBadge = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeBadge.url(options),
    method: 'post',
})

storeBadge.definition = {
    methods: ["post"],
    url: '/admin/badges',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\AdminWebController::storeBadge
 * @see app/Http/Controllers/Web/AdminWebController.php:191
 * @route '/admin/badges'
 */
storeBadge.url = (options?: RouteQueryOptions) => {
    return storeBadge.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AdminWebController::storeBadge
 * @see app/Http/Controllers/Web/AdminWebController.php:191
 * @route '/admin/badges'
 */
storeBadge.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeBadge.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\AdminWebController::storeBadge
 * @see app/Http/Controllers/Web/AdminWebController.php:191
 * @route '/admin/badges'
 */
    const storeBadgeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeBadge.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\AdminWebController::storeBadge
 * @see app/Http/Controllers/Web/AdminWebController.php:191
 * @route '/admin/badges'
 */
        storeBadgeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeBadge.url(options),
            method: 'post',
        })
    
    storeBadge.form = storeBadgeForm
/**
* @see \App\Http\Controllers\Web\AdminWebController::destroyBadge
 * @see app/Http/Controllers/Web/AdminWebController.php:208
 * @route '/admin/badges/{badge}'
 */
export const destroyBadge = (args: { badge: number | { badges_id: number } } | [badge: number | { badges_id: number } ] | number | { badges_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyBadge.url(args, options),
    method: 'delete',
})

destroyBadge.definition = {
    methods: ["delete"],
    url: '/admin/badges/{badge}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Web\AdminWebController::destroyBadge
 * @see app/Http/Controllers/Web/AdminWebController.php:208
 * @route '/admin/badges/{badge}'
 */
destroyBadge.url = (args: { badge: number | { badges_id: number } } | [badge: number | { badges_id: number } ] | number | { badges_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { badge: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'badges_id' in args) {
            args = { badge: args.badges_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    badge: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        badge: typeof args.badge === 'object'
                ? args.badge.badges_id
                : args.badge,
                }

    return destroyBadge.definition.url
            .replace('{badge}', parsedArgs.badge.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AdminWebController::destroyBadge
 * @see app/Http/Controllers/Web/AdminWebController.php:208
 * @route '/admin/badges/{badge}'
 */
destroyBadge.delete = (args: { badge: number | { badges_id: number } } | [badge: number | { badges_id: number } ] | number | { badges_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyBadge.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Web\AdminWebController::destroyBadge
 * @see app/Http/Controllers/Web/AdminWebController.php:208
 * @route '/admin/badges/{badge}'
 */
    const destroyBadgeForm = (args: { badge: number | { badges_id: number } } | [badge: number | { badges_id: number } ] | number | { badges_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyBadge.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\AdminWebController::destroyBadge
 * @see app/Http/Controllers/Web/AdminWebController.php:208
 * @route '/admin/badges/{badge}'
 */
        destroyBadgeForm.delete = (args: { badge: number | { badges_id: number } } | [badge: number | { badges_id: number } ] | number | { badges_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyBadge.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyBadge.form = destroyBadgeForm
/**
* @see \App\Http\Controllers\Web\AdminWebController::settings
 * @see app/Http/Controllers/Web/AdminWebController.php:216
 * @route '/admin/settings'
 */
export const settings = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: settings.url(options),
    method: 'get',
})

settings.definition = {
    methods: ["get","head"],
    url: '/admin/settings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\AdminWebController::settings
 * @see app/Http/Controllers/Web/AdminWebController.php:216
 * @route '/admin/settings'
 */
settings.url = (options?: RouteQueryOptions) => {
    return settings.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AdminWebController::settings
 * @see app/Http/Controllers/Web/AdminWebController.php:216
 * @route '/admin/settings'
 */
settings.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: settings.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\AdminWebController::settings
 * @see app/Http/Controllers/Web/AdminWebController.php:216
 * @route '/admin/settings'
 */
settings.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: settings.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\AdminWebController::settings
 * @see app/Http/Controllers/Web/AdminWebController.php:216
 * @route '/admin/settings'
 */
    const settingsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: settings.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\AdminWebController::settings
 * @see app/Http/Controllers/Web/AdminWebController.php:216
 * @route '/admin/settings'
 */
        settingsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: settings.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\AdminWebController::settings
 * @see app/Http/Controllers/Web/AdminWebController.php:216
 * @route '/admin/settings'
 */
        settingsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: settings.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    settings.form = settingsForm
const AdminWebController = { users, toggleUserStatus, communities, toggleCommunityStatus, categories, storeCategory, destroyCategory, storeInstrument, destroyInstrument, achievements, storeAchievement, destroyAchievement, badges, storeBadge, destroyBadge, settings }

export default AdminWebController