import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\CommunityWebController::index
 * @see app/Http/Controllers/Web/CommunityWebController.php:23
 * @route '/communities'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/communities',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\CommunityWebController::index
 * @see app/Http/Controllers/Web/CommunityWebController.php:23
 * @route '/communities'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\CommunityWebController::index
 * @see app/Http/Controllers/Web/CommunityWebController.php:23
 * @route '/communities'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\CommunityWebController::index
 * @see app/Http/Controllers/Web/CommunityWebController.php:23
 * @route '/communities'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\CommunityWebController::index
 * @see app/Http/Controllers/Web/CommunityWebController.php:23
 * @route '/communities'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\CommunityWebController::index
 * @see app/Http/Controllers/Web/CommunityWebController.php:23
 * @route '/communities'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\CommunityWebController::index
 * @see app/Http/Controllers/Web/CommunityWebController.php:23
 * @route '/communities'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Web\CommunityWebController::show
 * @see app/Http/Controllers/Web/CommunityWebController.php:48
 * @route '/communities/{community}'
 */
export const show = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/communities/{community}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\CommunityWebController::show
 * @see app/Http/Controllers/Web/CommunityWebController.php:48
 * @route '/communities/{community}'
 */
show.url = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { community: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'communities_id' in args) {
            args = { community: args.communities_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    community: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        community: typeof args.community === 'object'
                ? args.community.communities_id
                : args.community,
                }

    return show.definition.url
            .replace('{community}', parsedArgs.community.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\CommunityWebController::show
 * @see app/Http/Controllers/Web/CommunityWebController.php:48
 * @route '/communities/{community}'
 */
show.get = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\CommunityWebController::show
 * @see app/Http/Controllers/Web/CommunityWebController.php:48
 * @route '/communities/{community}'
 */
show.head = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\CommunityWebController::show
 * @see app/Http/Controllers/Web/CommunityWebController.php:48
 * @route '/communities/{community}'
 */
    const showForm = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\CommunityWebController::show
 * @see app/Http/Controllers/Web/CommunityWebController.php:48
 * @route '/communities/{community}'
 */
        showForm.get = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\CommunityWebController::show
 * @see app/Http/Controllers/Web/CommunityWebController.php:48
 * @route '/communities/{community}'
 */
        showForm.head = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Web\CommunityWebController::join
 * @see app/Http/Controllers/Web/CommunityWebController.php:77
 * @route '/communities/{community}/join'
 */
export const join = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: join.url(args, options),
    method: 'post',
})

join.definition = {
    methods: ["post"],
    url: '/communities/{community}/join',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\CommunityWebController::join
 * @see app/Http/Controllers/Web/CommunityWebController.php:77
 * @route '/communities/{community}/join'
 */
join.url = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { community: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'communities_id' in args) {
            args = { community: args.communities_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    community: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        community: typeof args.community === 'object'
                ? args.community.communities_id
                : args.community,
                }

    return join.definition.url
            .replace('{community}', parsedArgs.community.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\CommunityWebController::join
 * @see app/Http/Controllers/Web/CommunityWebController.php:77
 * @route '/communities/{community}/join'
 */
join.post = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: join.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\CommunityWebController::join
 * @see app/Http/Controllers/Web/CommunityWebController.php:77
 * @route '/communities/{community}/join'
 */
    const joinForm = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: join.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\CommunityWebController::join
 * @see app/Http/Controllers/Web/CommunityWebController.php:77
 * @route '/communities/{community}/join'
 */
        joinForm.post = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: join.url(args, options),
            method: 'post',
        })
    
    join.form = joinForm
/**
* @see \App\Http\Controllers\Web\CommunityWebController::leave
 * @see app/Http/Controllers/Web/CommunityWebController.php:106
 * @route '/communities/{community}/leave'
 */
export const leave = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: leave.url(args, options),
    method: 'post',
})

leave.definition = {
    methods: ["post"],
    url: '/communities/{community}/leave',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\CommunityWebController::leave
 * @see app/Http/Controllers/Web/CommunityWebController.php:106
 * @route '/communities/{community}/leave'
 */
leave.url = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { community: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'communities_id' in args) {
            args = { community: args.communities_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    community: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        community: typeof args.community === 'object'
                ? args.community.communities_id
                : args.community,
                }

    return leave.definition.url
            .replace('{community}', parsedArgs.community.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\CommunityWebController::leave
 * @see app/Http/Controllers/Web/CommunityWebController.php:106
 * @route '/communities/{community}/leave'
 */
leave.post = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: leave.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\CommunityWebController::leave
 * @see app/Http/Controllers/Web/CommunityWebController.php:106
 * @route '/communities/{community}/leave'
 */
    const leaveForm = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: leave.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\CommunityWebController::leave
 * @see app/Http/Controllers/Web/CommunityWebController.php:106
 * @route '/communities/{community}/leave'
 */
        leaveForm.post = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: leave.url(args, options),
            method: 'post',
        })
    
    leave.form = leaveForm
const CommunityWebController = { index, show, join, leave }

export default CommunityWebController