import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\DailyMissionWebController::index
 * @see app/Http/Controllers/Web/DailyMissionWebController.php:21
 * @route '/daily-missions'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/daily-missions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\DailyMissionWebController::index
 * @see app/Http/Controllers/Web/DailyMissionWebController.php:21
 * @route '/daily-missions'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\DailyMissionWebController::index
 * @see app/Http/Controllers/Web/DailyMissionWebController.php:21
 * @route '/daily-missions'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\DailyMissionWebController::index
 * @see app/Http/Controllers/Web/DailyMissionWebController.php:21
 * @route '/daily-missions'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\DailyMissionWebController::index
 * @see app/Http/Controllers/Web/DailyMissionWebController.php:21
 * @route '/daily-missions'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\DailyMissionWebController::index
 * @see app/Http/Controllers/Web/DailyMissionWebController.php:21
 * @route '/daily-missions'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\DailyMissionWebController::index
 * @see app/Http/Controllers/Web/DailyMissionWebController.php:21
 * @route '/daily-missions'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const DailyMissionWebController = { index }

export default DailyMissionWebController