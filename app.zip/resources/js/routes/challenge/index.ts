import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Web\ChallengeWebController::index
 * @see app/Http/Controllers/Web/ChallengeWebController.php:21
 * @route '/challenge'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/challenge',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\ChallengeWebController::index
 * @see app/Http/Controllers/Web/ChallengeWebController.php:21
 * @route '/challenge'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\ChallengeWebController::index
 * @see app/Http/Controllers/Web/ChallengeWebController.php:21
 * @route '/challenge'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\ChallengeWebController::index
 * @see app/Http/Controllers/Web/ChallengeWebController.php:21
 * @route '/challenge'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\ChallengeWebController::index
 * @see app/Http/Controllers/Web/ChallengeWebController.php:21
 * @route '/challenge'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\ChallengeWebController::index
 * @see app/Http/Controllers/Web/ChallengeWebController.php:21
 * @route '/challenge'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\ChallengeWebController::index
 * @see app/Http/Controllers/Web/ChallengeWebController.php:21
 * @route '/challenge'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
const challenge = {
    index: Object.assign(index, index),
}

export default challenge