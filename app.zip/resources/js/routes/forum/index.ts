import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Web\ForumWebController::index
 * @see app/Http/Controllers/Web/ForumWebController.php:21
 * @route '/forum'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/forum',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\ForumWebController::index
 * @see app/Http/Controllers/Web/ForumWebController.php:21
 * @route '/forum'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\ForumWebController::index
 * @see app/Http/Controllers/Web/ForumWebController.php:21
 * @route '/forum'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\ForumWebController::index
 * @see app/Http/Controllers/Web/ForumWebController.php:21
 * @route '/forum'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\ForumWebController::index
 * @see app/Http/Controllers/Web/ForumWebController.php:21
 * @route '/forum'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\ForumWebController::index
 * @see app/Http/Controllers/Web/ForumWebController.php:21
 * @route '/forum'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\ForumWebController::index
 * @see app/Http/Controllers/Web/ForumWebController.php:21
 * @route '/forum'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Web\ForumWebController::show
 * @see app/Http/Controllers/Web/ForumWebController.php:50
 * @route '/forum/{forumPost}'
 */
export const show = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/forum/{forumPost}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\ForumWebController::show
 * @see app/Http/Controllers/Web/ForumWebController.php:50
 * @route '/forum/{forumPost}'
 */
show.url = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { forumPost: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'forum_posts_id' in args) {
            args = { forumPost: args.forum_posts_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    forumPost: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        forumPost: typeof args.forumPost === 'object'
                ? args.forumPost.forum_posts_id
                : args.forumPost,
                }

    return show.definition.url
            .replace('{forumPost}', parsedArgs.forumPost.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\ForumWebController::show
 * @see app/Http/Controllers/Web/ForumWebController.php:50
 * @route '/forum/{forumPost}'
 */
show.get = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\ForumWebController::show
 * @see app/Http/Controllers/Web/ForumWebController.php:50
 * @route '/forum/{forumPost}'
 */
show.head = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\ForumWebController::show
 * @see app/Http/Controllers/Web/ForumWebController.php:50
 * @route '/forum/{forumPost}'
 */
    const showForm = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\ForumWebController::show
 * @see app/Http/Controllers/Web/ForumWebController.php:50
 * @route '/forum/{forumPost}'
 */
        showForm.get = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\ForumWebController::show
 * @see app/Http/Controllers/Web/ForumWebController.php:50
 * @route '/forum/{forumPost}'
 */
        showForm.head = (args: { forumPost: number | { forum_posts_id: number } } | [forumPost: number | { forum_posts_id: number } ] | number | { forum_posts_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const forum = {
    index: Object.assign(index, index),
show: Object.assign(show, show),
}

export default forum