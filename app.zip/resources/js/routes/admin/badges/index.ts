import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\AdminWebController::store
 * @see app/Http/Controllers/Web/AdminWebController.php:191
 * @route '/admin/badges'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/badges',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\AdminWebController::store
 * @see app/Http/Controllers/Web/AdminWebController.php:191
 * @route '/admin/badges'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AdminWebController::store
 * @see app/Http/Controllers/Web/AdminWebController.php:191
 * @route '/admin/badges'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\AdminWebController::store
 * @see app/Http/Controllers/Web/AdminWebController.php:191
 * @route '/admin/badges'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\AdminWebController::store
 * @see app/Http/Controllers/Web/AdminWebController.php:191
 * @route '/admin/badges'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Web\AdminWebController::destroy
 * @see app/Http/Controllers/Web/AdminWebController.php:208
 * @route '/admin/badges/{badge}'
 */
export const destroy = (args: { badge: number | { badges_id: number } } | [badge: number | { badges_id: number } ] | number | { badges_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/badges/{badge}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Web\AdminWebController::destroy
 * @see app/Http/Controllers/Web/AdminWebController.php:208
 * @route '/admin/badges/{badge}'
 */
destroy.url = (args: { badge: number | { badges_id: number } } | [badge: number | { badges_id: number } ] | number | { badges_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { badge: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'badges_id' in args) {
            args = { badge: args.badges_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    badge: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        badge: typeof args.badge === 'object'
                ? args.badge.badges_id
                : args.badge,
                }

    return destroy.definition.url
            .replace('{badge}', parsedArgs.badge.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AdminWebController::destroy
 * @see app/Http/Controllers/Web/AdminWebController.php:208
 * @route '/admin/badges/{badge}'
 */
destroy.delete = (args: { badge: number | { badges_id: number } } | [badge: number | { badges_id: number } ] | number | { badges_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Web\AdminWebController::destroy
 * @see app/Http/Controllers/Web/AdminWebController.php:208
 * @route '/admin/badges/{badge}'
 */
    const destroyForm = (args: { badge: number | { badges_id: number } } | [badge: number | { badges_id: number } ] | number | { badges_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\AdminWebController::destroy
 * @see app/Http/Controllers/Web/AdminWebController.php:208
 * @route '/admin/badges/{badge}'
 */
        destroyForm.delete = (args: { badge: number | { badges_id: number } } | [badge: number | { badges_id: number } ] | number | { badges_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const badges = {
    store: Object.assign(store, store),
destroy: Object.assign(destroy, destroy),
}

export default badges