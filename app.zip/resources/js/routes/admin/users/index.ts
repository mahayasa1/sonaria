import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\AdminWebController::toggleStatus
 * @see app/Http/Controllers/Web/AdminWebController.php:46
 * @route '/admin/users/{user}/toggle-status'
 */
export const toggleStatus = (args: { user: number | { users_id: number } } | [user: number | { users_id: number } ] | number | { users_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleStatus.url(args, options),
    method: 'post',
})

toggleStatus.definition = {
    methods: ["post"],
    url: '/admin/users/{user}/toggle-status',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\AdminWebController::toggleStatus
 * @see app/Http/Controllers/Web/AdminWebController.php:46
 * @route '/admin/users/{user}/toggle-status'
 */
toggleStatus.url = (args: { user: number | { users_id: number } } | [user: number | { users_id: number } ] | number | { users_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { user: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'users_id' in args) {
            args = { user: args.users_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    user: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        user: typeof args.user === 'object'
                ? args.user.users_id
                : args.user,
                }

    return toggleStatus.definition.url
            .replace('{user}', parsedArgs.user.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AdminWebController::toggleStatus
 * @see app/Http/Controllers/Web/AdminWebController.php:46
 * @route '/admin/users/{user}/toggle-status'
 */
toggleStatus.post = (args: { user: number | { users_id: number } } | [user: number | { users_id: number } ] | number | { users_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleStatus.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\AdminWebController::toggleStatus
 * @see app/Http/Controllers/Web/AdminWebController.php:46
 * @route '/admin/users/{user}/toggle-status'
 */
    const toggleStatusForm = (args: { user: number | { users_id: number } } | [user: number | { users_id: number } ] | number | { users_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleStatus.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\AdminWebController::toggleStatus
 * @see app/Http/Controllers/Web/AdminWebController.php:46
 * @route '/admin/users/{user}/toggle-status'
 */
        toggleStatusForm.post = (args: { user: number | { users_id: number } } | [user: number | { users_id: number } ] | number | { users_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleStatus.url(args, options),
            method: 'post',
        })
    
    toggleStatus.form = toggleStatusForm
const users = {
    toggleStatus: Object.assign(toggleStatus, toggleStatus),
}

export default users