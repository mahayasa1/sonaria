import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\AdminWebController::store
 * @see app/Http/Controllers/Web/AdminWebController.php:92
 * @route '/admin/categories'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/categories',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\AdminWebController::store
 * @see app/Http/Controllers/Web/AdminWebController.php:92
 * @route '/admin/categories'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AdminWebController::store
 * @see app/Http/Controllers/Web/AdminWebController.php:92
 * @route '/admin/categories'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\AdminWebController::store
 * @see app/Http/Controllers/Web/AdminWebController.php:92
 * @route '/admin/categories'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\AdminWebController::store
 * @see app/Http/Controllers/Web/AdminWebController.php:92
 * @route '/admin/categories'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Web\AdminWebController::destroy
 * @see app/Http/Controllers/Web/AdminWebController.php:107
 * @route '/admin/categories/{category}'
 */
export const destroy = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/categories/{category}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Web\AdminWebController::destroy
 * @see app/Http/Controllers/Web/AdminWebController.php:107
 * @route '/admin/categories/{category}'
 */
destroy.url = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'music_categories_id' in args) {
            args = { category: args.music_categories_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    category: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        category: typeof args.category === 'object'
                ? args.category.music_categories_id
                : args.category,
                }

    return destroy.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AdminWebController::destroy
 * @see app/Http/Controllers/Web/AdminWebController.php:107
 * @route '/admin/categories/{category}'
 */
destroy.delete = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Web\AdminWebController::destroy
 * @see app/Http/Controllers/Web/AdminWebController.php:107
 * @route '/admin/categories/{category}'
 */
    const destroyForm = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\AdminWebController::destroy
 * @see app/Http/Controllers/Web/AdminWebController.php:107
 * @route '/admin/categories/{category}'
 */
        destroyForm.delete = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const categories = {
    store: Object.assign(store, store),
destroy: Object.assign(destroy, destroy),
}

export default categories