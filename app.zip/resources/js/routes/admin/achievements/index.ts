import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\AdminWebController::store
 * @see app/Http/Controllers/Web/AdminWebController.php:157
 * @route '/admin/achievements'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/achievements',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\AdminWebController::store
 * @see app/Http/Controllers/Web/AdminWebController.php:157
 * @route '/admin/achievements'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AdminWebController::store
 * @see app/Http/Controllers/Web/AdminWebController.php:157
 * @route '/admin/achievements'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\AdminWebController::store
 * @see app/Http/Controllers/Web/AdminWebController.php:157
 * @route '/admin/achievements'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\AdminWebController::store
 * @see app/Http/Controllers/Web/AdminWebController.php:157
 * @route '/admin/achievements'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Web\AdminWebController::destroy
 * @see app/Http/Controllers/Web/AdminWebController.php:174
 * @route '/admin/achievements/{achievement}'
 */
export const destroy = (args: { achievement: number | { achievements_id: number } } | [achievement: number | { achievements_id: number } ] | number | { achievements_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/achievements/{achievement}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Web\AdminWebController::destroy
 * @see app/Http/Controllers/Web/AdminWebController.php:174
 * @route '/admin/achievements/{achievement}'
 */
destroy.url = (args: { achievement: number | { achievements_id: number } } | [achievement: number | { achievements_id: number } ] | number | { achievements_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { achievement: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'achievements_id' in args) {
            args = { achievement: args.achievements_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    achievement: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        achievement: typeof args.achievement === 'object'
                ? args.achievement.achievements_id
                : args.achievement,
                }

    return destroy.definition.url
            .replace('{achievement}', parsedArgs.achievement.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AdminWebController::destroy
 * @see app/Http/Controllers/Web/AdminWebController.php:174
 * @route '/admin/achievements/{achievement}'
 */
destroy.delete = (args: { achievement: number | { achievements_id: number } } | [achievement: number | { achievements_id: number } ] | number | { achievements_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Web\AdminWebController::destroy
 * @see app/Http/Controllers/Web/AdminWebController.php:174
 * @route '/admin/achievements/{achievement}'
 */
    const destroyForm = (args: { achievement: number | { achievements_id: number } } | [achievement: number | { achievements_id: number } ] | number | { achievements_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\AdminWebController::destroy
 * @see app/Http/Controllers/Web/AdminWebController.php:174
 * @route '/admin/achievements/{achievement}'
 */
        destroyForm.delete = (args: { achievement: number | { achievements_id: number } } | [achievement: number | { achievements_id: number } ] | number | { achievements_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const achievements = {
    store: Object.assign(store, store),
destroy: Object.assign(destroy, destroy),
}

export default achievements