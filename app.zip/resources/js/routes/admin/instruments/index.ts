import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\AdminWebController::store
 * @see app/Http/Controllers/Web/AdminWebController.php:120
 * @route '/admin/categories/{category}/instruments'
 */
export const store = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/categories/{category}/instruments',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\AdminWebController::store
 * @see app/Http/Controllers/Web/AdminWebController.php:120
 * @route '/admin/categories/{category}/instruments'
 */
store.url = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'music_categories_id' in args) {
            args = { category: args.music_categories_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    category: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        category: typeof args.category === 'object'
                ? args.category.music_categories_id
                : args.category,
                }

    return store.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AdminWebController::store
 * @see app/Http/Controllers/Web/AdminWebController.php:120
 * @route '/admin/categories/{category}/instruments'
 */
store.post = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\AdminWebController::store
 * @see app/Http/Controllers/Web/AdminWebController.php:120
 * @route '/admin/categories/{category}/instruments'
 */
    const storeForm = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\AdminWebController::store
 * @see app/Http/Controllers/Web/AdminWebController.php:120
 * @route '/admin/categories/{category}/instruments'
 */
        storeForm.post = (args: { category: number | { music_categories_id: number } } | [category: number | { music_categories_id: number } ] | number | { music_categories_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(args, options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Web\AdminWebController::destroy
 * @see app/Http/Controllers/Web/AdminWebController.php:135
 * @route '/admin/instruments/{instrument}'
 */
export const destroy = (args: { instrument: number | { intruments_id: number } } | [instrument: number | { intruments_id: number } ] | number | { intruments_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/instruments/{instrument}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Web\AdminWebController::destroy
 * @see app/Http/Controllers/Web/AdminWebController.php:135
 * @route '/admin/instruments/{instrument}'
 */
destroy.url = (args: { instrument: number | { intruments_id: number } } | [instrument: number | { intruments_id: number } ] | number | { intruments_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { instrument: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'intruments_id' in args) {
            args = { instrument: args.intruments_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    instrument: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        instrument: typeof args.instrument === 'object'
                ? args.instrument.intruments_id
                : args.instrument,
                }

    return destroy.definition.url
            .replace('{instrument}', parsedArgs.instrument.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AdminWebController::destroy
 * @see app/Http/Controllers/Web/AdminWebController.php:135
 * @route '/admin/instruments/{instrument}'
 */
destroy.delete = (args: { instrument: number | { intruments_id: number } } | [instrument: number | { intruments_id: number } ] | number | { intruments_id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Web\AdminWebController::destroy
 * @see app/Http/Controllers/Web/AdminWebController.php:135
 * @route '/admin/instruments/{instrument}'
 */
    const destroyForm = (args: { instrument: number | { intruments_id: number } } | [instrument: number | { intruments_id: number } ] | number | { intruments_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\AdminWebController::destroy
 * @see app/Http/Controllers/Web/AdminWebController.php:135
 * @route '/admin/instruments/{instrument}'
 */
        destroyForm.delete = (args: { instrument: number | { intruments_id: number } } | [instrument: number | { intruments_id: number } ] | number | { intruments_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const instruments = {
    store: Object.assign(store, store),
destroy: Object.assign(destroy, destroy),
}

export default instruments