import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\AdminWebController::toggleStatus
 * @see app/Http/Controllers/Web/AdminWebController.php:71
 * @route '/admin/communities/{community}/toggle-status'
 */
export const toggleStatus = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleStatus.url(args, options),
    method: 'post',
})

toggleStatus.definition = {
    methods: ["post"],
    url: '/admin/communities/{community}/toggle-status',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\AdminWebController::toggleStatus
 * @see app/Http/Controllers/Web/AdminWebController.php:71
 * @route '/admin/communities/{community}/toggle-status'
 */
toggleStatus.url = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { community: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'communities_id' in args) {
            args = { community: args.communities_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    community: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        community: typeof args.community === 'object'
                ? args.community.communities_id
                : args.community,
                }

    return toggleStatus.definition.url
            .replace('{community}', parsedArgs.community.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AdminWebController::toggleStatus
 * @see app/Http/Controllers/Web/AdminWebController.php:71
 * @route '/admin/communities/{community}/toggle-status'
 */
toggleStatus.post = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: toggleStatus.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\AdminWebController::toggleStatus
 * @see app/Http/Controllers/Web/AdminWebController.php:71
 * @route '/admin/communities/{community}/toggle-status'
 */
    const toggleStatusForm = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: toggleStatus.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\AdminWebController::toggleStatus
 * @see app/Http/Controllers/Web/AdminWebController.php:71
 * @route '/admin/communities/{community}/toggle-status'
 */
        toggleStatusForm.post = (args: { community: number | { communities_id: number } } | [community: number | { communities_id: number } ] | number | { communities_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: toggleStatus.url(args, options),
            method: 'post',
        })
    
    toggleStatus.form = toggleStatusForm
const communities = {
    toggleStatus: Object.assign(toggleStatus, toggleStatus),
}

export default communities