import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import users48860f from './users'
import communities1d93b2 from './communities'
import categories08bc8d from './categories'
import instruments from './instruments'
import achievements3c855b from './achievements'
import badgesA89659 from './badges'
/**
* @see \App\Http\Controllers\Web\AdminWebController::users
 * @see app/Http/Controllers/Web/AdminWebController.php:27
 * @route '/admin/users'
 */
export const users = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: users.url(options),
    method: 'get',
})

users.definition = {
    methods: ["get","head"],
    url: '/admin/users',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\AdminWebController::users
 * @see app/Http/Controllers/Web/AdminWebController.php:27
 * @route '/admin/users'
 */
users.url = (options?: RouteQueryOptions) => {
    return users.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AdminWebController::users
 * @see app/Http/Controllers/Web/AdminWebController.php:27
 * @route '/admin/users'
 */
users.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: users.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\AdminWebController::users
 * @see app/Http/Controllers/Web/AdminWebController.php:27
 * @route '/admin/users'
 */
users.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: users.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\AdminWebController::users
 * @see app/Http/Controllers/Web/AdminWebController.php:27
 * @route '/admin/users'
 */
    const usersForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: users.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\AdminWebController::users
 * @see app/Http/Controllers/Web/AdminWebController.php:27
 * @route '/admin/users'
 */
        usersForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: users.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\AdminWebController::users
 * @see app/Http/Controllers/Web/AdminWebController.php:27
 * @route '/admin/users'
 */
        usersForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: users.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    users.form = usersForm
/**
* @see \App\Http\Controllers\Web\AdminWebController::communities
 * @see app/Http/Controllers/Web/AdminWebController.php:55
 * @route '/admin/communities'
 */
export const communities = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: communities.url(options),
    method: 'get',
})

communities.definition = {
    methods: ["get","head"],
    url: '/admin/communities',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\AdminWebController::communities
 * @see app/Http/Controllers/Web/AdminWebController.php:55
 * @route '/admin/communities'
 */
communities.url = (options?: RouteQueryOptions) => {
    return communities.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AdminWebController::communities
 * @see app/Http/Controllers/Web/AdminWebController.php:55
 * @route '/admin/communities'
 */
communities.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: communities.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\AdminWebController::communities
 * @see app/Http/Controllers/Web/AdminWebController.php:55
 * @route '/admin/communities'
 */
communities.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: communities.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\AdminWebController::communities
 * @see app/Http/Controllers/Web/AdminWebController.php:55
 * @route '/admin/communities'
 */
    const communitiesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: communities.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\AdminWebController::communities
 * @see app/Http/Controllers/Web/AdminWebController.php:55
 * @route '/admin/communities'
 */
        communitiesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: communities.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\AdminWebController::communities
 * @see app/Http/Controllers/Web/AdminWebController.php:55
 * @route '/admin/communities'
 */
        communitiesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: communities.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    communities.form = communitiesForm
/**
* @see \App\Http\Controllers\Web\AdminWebController::categories
 * @see app/Http/Controllers/Web/AdminWebController.php:80
 * @route '/admin/categories'
 */
export const categories = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: categories.url(options),
    method: 'get',
})

categories.definition = {
    methods: ["get","head"],
    url: '/admin/categories',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\AdminWebController::categories
 * @see app/Http/Controllers/Web/AdminWebController.php:80
 * @route '/admin/categories'
 */
categories.url = (options?: RouteQueryOptions) => {
    return categories.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AdminWebController::categories
 * @see app/Http/Controllers/Web/AdminWebController.php:80
 * @route '/admin/categories'
 */
categories.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: categories.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\AdminWebController::categories
 * @see app/Http/Controllers/Web/AdminWebController.php:80
 * @route '/admin/categories'
 */
categories.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: categories.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\AdminWebController::categories
 * @see app/Http/Controllers/Web/AdminWebController.php:80
 * @route '/admin/categories'
 */
    const categoriesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: categories.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\AdminWebController::categories
 * @see app/Http/Controllers/Web/AdminWebController.php:80
 * @route '/admin/categories'
 */
        categoriesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: categories.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\AdminWebController::categories
 * @see app/Http/Controllers/Web/AdminWebController.php:80
 * @route '/admin/categories'
 */
        categoriesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: categories.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    categories.form = categoriesForm
/**
* @see \App\Http\Controllers\Web\AdminWebController::achievements
 * @see app/Http/Controllers/Web/AdminWebController.php:148
 * @route '/admin/achievements'
 */
export const achievements = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: achievements.url(options),
    method: 'get',
})

achievements.definition = {
    methods: ["get","head"],
    url: '/admin/achievements',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\AdminWebController::achievements
 * @see app/Http/Controllers/Web/AdminWebController.php:148
 * @route '/admin/achievements'
 */
achievements.url = (options?: RouteQueryOptions) => {
    return achievements.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AdminWebController::achievements
 * @see app/Http/Controllers/Web/AdminWebController.php:148
 * @route '/admin/achievements'
 */
achievements.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: achievements.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\AdminWebController::achievements
 * @see app/Http/Controllers/Web/AdminWebController.php:148
 * @route '/admin/achievements'
 */
achievements.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: achievements.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\AdminWebController::achievements
 * @see app/Http/Controllers/Web/AdminWebController.php:148
 * @route '/admin/achievements'
 */
    const achievementsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: achievements.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\AdminWebController::achievements
 * @see app/Http/Controllers/Web/AdminWebController.php:148
 * @route '/admin/achievements'
 */
        achievementsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: achievements.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\AdminWebController::achievements
 * @see app/Http/Controllers/Web/AdminWebController.php:148
 * @route '/admin/achievements'
 */
        achievementsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: achievements.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    achievements.form = achievementsForm
/**
* @see \App\Http\Controllers\Web\AdminWebController::badges
 * @see app/Http/Controllers/Web/AdminWebController.php:182
 * @route '/admin/badges'
 */
export const badges = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: badges.url(options),
    method: 'get',
})

badges.definition = {
    methods: ["get","head"],
    url: '/admin/badges',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\AdminWebController::badges
 * @see app/Http/Controllers/Web/AdminWebController.php:182
 * @route '/admin/badges'
 */
badges.url = (options?: RouteQueryOptions) => {
    return badges.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AdminWebController::badges
 * @see app/Http/Controllers/Web/AdminWebController.php:182
 * @route '/admin/badges'
 */
badges.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: badges.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\AdminWebController::badges
 * @see app/Http/Controllers/Web/AdminWebController.php:182
 * @route '/admin/badges'
 */
badges.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: badges.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\AdminWebController::badges
 * @see app/Http/Controllers/Web/AdminWebController.php:182
 * @route '/admin/badges'
 */
    const badgesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: badges.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\AdminWebController::badges
 * @see app/Http/Controllers/Web/AdminWebController.php:182
 * @route '/admin/badges'
 */
        badgesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: badges.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\AdminWebController::badges
 * @see app/Http/Controllers/Web/AdminWebController.php:182
 * @route '/admin/badges'
 */
        badgesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: badges.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    badges.form = badgesForm
/**
* @see \App\Http\Controllers\Web\AdminWebController::settings
 * @see app/Http/Controllers/Web/AdminWebController.php:216
 * @route '/admin/settings'
 */
export const settings = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: settings.url(options),
    method: 'get',
})

settings.definition = {
    methods: ["get","head"],
    url: '/admin/settings',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\AdminWebController::settings
 * @see app/Http/Controllers/Web/AdminWebController.php:216
 * @route '/admin/settings'
 */
settings.url = (options?: RouteQueryOptions) => {
    return settings.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\AdminWebController::settings
 * @see app/Http/Controllers/Web/AdminWebController.php:216
 * @route '/admin/settings'
 */
settings.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: settings.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\AdminWebController::settings
 * @see app/Http/Controllers/Web/AdminWebController.php:216
 * @route '/admin/settings'
 */
settings.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: settings.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\AdminWebController::settings
 * @see app/Http/Controllers/Web/AdminWebController.php:216
 * @route '/admin/settings'
 */
    const settingsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: settings.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\AdminWebController::settings
 * @see app/Http/Controllers/Web/AdminWebController.php:216
 * @route '/admin/settings'
 */
        settingsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: settings.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\AdminWebController::settings
 * @see app/Http/Controllers/Web/AdminWebController.php:216
 * @route '/admin/settings'
 */
        settingsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: settings.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    settings.form = settingsForm
const admin = {
    users: Object.assign(users, users48860f),
communities: Object.assign(communities, communities1d93b2),
categories: Object.assign(categories, categories08bc8d),
instruments: Object.assign(instruments, instruments),
achievements: Object.assign(achievements, achievements3c855b),
badges: Object.assign(badges, badgesA89659),
settings: Object.assign(settings, settings),
}

export default admin