import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\ManageWebController::create
 * @see app/Http/Controllers/Web/ManageWebController.php:46
 * @route '/manage/main-quests/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/manage/main-quests/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\ManageWebController::create
 * @see app/Http/Controllers/Web/ManageWebController.php:46
 * @route '/manage/main-quests/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\ManageWebController::create
 * @see app/Http/Controllers/Web/ManageWebController.php:46
 * @route '/manage/main-quests/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\ManageWebController::create
 * @see app/Http/Controllers/Web/ManageWebController.php:46
 * @route '/manage/main-quests/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\ManageWebController::create
 * @see app/Http/Controllers/Web/ManageWebController.php:46
 * @route '/manage/main-quests/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\ManageWebController::create
 * @see app/Http/Controllers/Web/ManageWebController.php:46
 * @route '/manage/main-quests/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\ManageWebController::create
 * @see app/Http/Controllers/Web/ManageWebController.php:46
 * @route '/manage/main-quests/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
const mainQuests = {
    create: Object.assign(create, create),
}

export default mainQuests