import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\ManageWebController::create
 * @see app/Http/Controllers/Web/ManageWebController.php:135
 * @route '/manage/materials/{material}/practices/create'
 */
export const create = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/manage/materials/{material}/practices/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\ManageWebController::create
 * @see app/Http/Controllers/Web/ManageWebController.php:135
 * @route '/manage/materials/{material}/practices/create'
 */
create.url = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { material: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'materials_id' in args) {
            args = { material: args.materials_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    material: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        material: typeof args.material === 'object'
                ? args.material.materials_id
                : args.material,
                }

    return create.definition.url
            .replace('{material}', parsedArgs.material.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\ManageWebController::create
 * @see app/Http/Controllers/Web/ManageWebController.php:135
 * @route '/manage/materials/{material}/practices/create'
 */
create.get = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\ManageWebController::create
 * @see app/Http/Controllers/Web/ManageWebController.php:135
 * @route '/manage/materials/{material}/practices/create'
 */
create.head = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\ManageWebController::create
 * @see app/Http/Controllers/Web/ManageWebController.php:135
 * @route '/manage/materials/{material}/practices/create'
 */
    const createForm = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\ManageWebController::create
 * @see app/Http/Controllers/Web/ManageWebController.php:135
 * @route '/manage/materials/{material}/practices/create'
 */
        createForm.get = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\ManageWebController::create
 * @see app/Http/Controllers/Web/ManageWebController.php:135
 * @route '/manage/materials/{material}/practices/create'
 */
        createForm.head = (args: { material: number | { materials_id: number } } | [material: number | { materials_id: number } ] | number | { materials_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
const practices = {
    create: Object.assign(create, create),
}

export default practices