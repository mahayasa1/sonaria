import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\ManageWebController::create
 * @see app/Http/Controllers/Web/ManageWebController.php:114
 * @route '/manage/main-quests/{mainQuest}/materials/create'
 */
export const create = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/manage/main-quests/{mainQuest}/materials/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\ManageWebController::create
 * @see app/Http/Controllers/Web/ManageWebController.php:114
 * @route '/manage/main-quests/{mainQuest}/materials/create'
 */
create.url = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { mainQuest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'main_quests_id' in args) {
            args = { mainQuest: args.main_quests_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    mainQuest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        mainQuest: typeof args.mainQuest === 'object'
                ? args.mainQuest.main_quests_id
                : args.mainQuest,
                }

    return create.definition.url
            .replace('{mainQuest}', parsedArgs.mainQuest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\ManageWebController::create
 * @see app/Http/Controllers/Web/ManageWebController.php:114
 * @route '/manage/main-quests/{mainQuest}/materials/create'
 */
create.get = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\ManageWebController::create
 * @see app/Http/Controllers/Web/ManageWebController.php:114
 * @route '/manage/main-quests/{mainQuest}/materials/create'
 */
create.head = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\ManageWebController::create
 * @see app/Http/Controllers/Web/ManageWebController.php:114
 * @route '/manage/main-quests/{mainQuest}/materials/create'
 */
    const createForm = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\ManageWebController::create
 * @see app/Http/Controllers/Web/ManageWebController.php:114
 * @route '/manage/main-quests/{mainQuest}/materials/create'
 */
        createForm.get = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\ManageWebController::create
 * @see app/Http/Controllers/Web/ManageWebController.php:114
 * @route '/manage/main-quests/{mainQuest}/materials/create'
 */
        createForm.head = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
const materials = {
    create: Object.assign(create, create),
}

export default materials