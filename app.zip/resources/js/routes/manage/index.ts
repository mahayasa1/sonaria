import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
import mainQuests from './main-quests'
import materials from './materials'
import quizzes from './quizzes'
import practices from './practices'
import materialFiles from './material-files'
import dailyMissions from './daily-missions'
import challenge from './challenge'
import practiceSubmissions from './practice-submissions'
import challengeSubmissions from './challenge-submissions'
/**
* @see \App\Http\Controllers\Web\ManageWebController::members
 * @see app/Http/Controllers/Web/ManageWebController.php:25
 * @route '/manage/members'
 */
export const members = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: members.url(options),
    method: 'get',
})

members.definition = {
    methods: ["get","head"],
    url: '/manage/members',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\ManageWebController::members
 * @see app/Http/Controllers/Web/ManageWebController.php:25
 * @route '/manage/members'
 */
members.url = (options?: RouteQueryOptions) => {
    return members.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\ManageWebController::members
 * @see app/Http/Controllers/Web/ManageWebController.php:25
 * @route '/manage/members'
 */
members.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: members.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\ManageWebController::members
 * @see app/Http/Controllers/Web/ManageWebController.php:25
 * @route '/manage/members'
 */
members.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: members.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\ManageWebController::members
 * @see app/Http/Controllers/Web/ManageWebController.php:25
 * @route '/manage/members'
 */
    const membersForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: members.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\ManageWebController::members
 * @see app/Http/Controllers/Web/ManageWebController.php:25
 * @route '/manage/members'
 */
        membersForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: members.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\ManageWebController::members
 * @see app/Http/Controllers/Web/ManageWebController.php:25
 * @route '/manage/members'
 */
        membersForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: members.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    members.form = membersForm
/**
* @see \App\Http\Controllers\Web\ManageWebController::reviews
 * @see app/Http/Controllers/Web/ManageWebController.php:86
 * @route '/manage/reviews'
 */
export const reviews = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reviews.url(options),
    method: 'get',
})

reviews.definition = {
    methods: ["get","head"],
    url: '/manage/reviews',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\ManageWebController::reviews
 * @see app/Http/Controllers/Web/ManageWebController.php:86
 * @route '/manage/reviews'
 */
reviews.url = (options?: RouteQueryOptions) => {
    return reviews.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\ManageWebController::reviews
 * @see app/Http/Controllers/Web/ManageWebController.php:86
 * @route '/manage/reviews'
 */
reviews.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reviews.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\ManageWebController::reviews
 * @see app/Http/Controllers/Web/ManageWebController.php:86
 * @route '/manage/reviews'
 */
reviews.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: reviews.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\ManageWebController::reviews
 * @see app/Http/Controllers/Web/ManageWebController.php:86
 * @route '/manage/reviews'
 */
    const reviewsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: reviews.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\ManageWebController::reviews
 * @see app/Http/Controllers/Web/ManageWebController.php:86
 * @route '/manage/reviews'
 */
        reviewsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: reviews.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\ManageWebController::reviews
 * @see app/Http/Controllers/Web/ManageWebController.php:86
 * @route '/manage/reviews'
 */
        reviewsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: reviews.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    reviews.form = reviewsForm
const manage = {
    members: Object.assign(members, members),
reviews: Object.assign(reviews, reviews),
mainQuests: Object.assign(mainQuests, mainQuests),
materials: Object.assign(materials, materials),
quizzes: Object.assign(quizzes, quizzes),
practices: Object.assign(practices, practices),
materialFiles: Object.assign(materialFiles, materialFiles),
dailyMissions: Object.assign(dailyMissions, dailyMissions),
challenge: Object.assign(challenge, challenge),
practiceSubmissions: Object.assign(practiceSubmissions, practiceSubmissions),
challengeSubmissions: Object.assign(challengeSubmissions, challengeSubmissions),
}

export default manage