import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\ManageWebController::show
 * @see app/Http/Controllers/Web/ManageWebController.php:165
 * @route '/manage/challenge-submissions/{submission}'
 */
export const show = (args: { submission: number | { challenge_submissions_id: number } } | [submission: number | { challenge_submissions_id: number } ] | number | { challenge_submissions_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/manage/challenge-submissions/{submission}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\ManageWebController::show
 * @see app/Http/Controllers/Web/ManageWebController.php:165
 * @route '/manage/challenge-submissions/{submission}'
 */
show.url = (args: { submission: number | { challenge_submissions_id: number } } | [submission: number | { challenge_submissions_id: number } ] | number | { challenge_submissions_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { submission: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'challenge_submissions_id' in args) {
            args = { submission: args.challenge_submissions_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    submission: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        submission: typeof args.submission === 'object'
                ? args.submission.challenge_submissions_id
                : args.submission,
                }

    return show.definition.url
            .replace('{submission}', parsedArgs.submission.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\ManageWebController::show
 * @see app/Http/Controllers/Web/ManageWebController.php:165
 * @route '/manage/challenge-submissions/{submission}'
 */
show.get = (args: { submission: number | { challenge_submissions_id: number } } | [submission: number | { challenge_submissions_id: number } ] | number | { challenge_submissions_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\ManageWebController::show
 * @see app/Http/Controllers/Web/ManageWebController.php:165
 * @route '/manage/challenge-submissions/{submission}'
 */
show.head = (args: { submission: number | { challenge_submissions_id: number } } | [submission: number | { challenge_submissions_id: number } ] | number | { challenge_submissions_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\ManageWebController::show
 * @see app/Http/Controllers/Web/ManageWebController.php:165
 * @route '/manage/challenge-submissions/{submission}'
 */
    const showForm = (args: { submission: number | { challenge_submissions_id: number } } | [submission: number | { challenge_submissions_id: number } ] | number | { challenge_submissions_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\ManageWebController::show
 * @see app/Http/Controllers/Web/ManageWebController.php:165
 * @route '/manage/challenge-submissions/{submission}'
 */
        showForm.get = (args: { submission: number | { challenge_submissions_id: number } } | [submission: number | { challenge_submissions_id: number } ] | number | { challenge_submissions_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\ManageWebController::show
 * @see app/Http/Controllers/Web/ManageWebController.php:165
 * @route '/manage/challenge-submissions/{submission}'
 */
        showForm.head = (args: { submission: number | { challenge_submissions_id: number } } | [submission: number | { challenge_submissions_id: number } ] | number | { challenge_submissions_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const challengeSubmissions = {
    show: Object.assign(show, show),
}

export default challengeSubmissions