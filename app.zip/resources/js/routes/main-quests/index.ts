import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Web\MainQuestWebController::index
 * @see app/Http/Controllers/Web/MainQuestWebController.php:21
 * @route '/main-quests'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/main-quests',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\MainQuestWebController::index
 * @see app/Http/Controllers/Web/MainQuestWebController.php:21
 * @route '/main-quests'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\MainQuestWebController::index
 * @see app/Http/Controllers/Web/MainQuestWebController.php:21
 * @route '/main-quests'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\MainQuestWebController::index
 * @see app/Http/Controllers/Web/MainQuestWebController.php:21
 * @route '/main-quests'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\MainQuestWebController::index
 * @see app/Http/Controllers/Web/MainQuestWebController.php:21
 * @route '/main-quests'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\MainQuestWebController::index
 * @see app/Http/Controllers/Web/MainQuestWebController.php:21
 * @route '/main-quests'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\MainQuestWebController::index
 * @see app/Http/Controllers/Web/MainQuestWebController.php:21
 * @route '/main-quests'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Web\MainQuestWebController::show
 * @see app/Http/Controllers/Web/MainQuestWebController.php:49
 * @route '/main-quests/{mainQuest}'
 */
export const show = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/main-quests/{mainQuest}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\MainQuestWebController::show
 * @see app/Http/Controllers/Web/MainQuestWebController.php:49
 * @route '/main-quests/{mainQuest}'
 */
show.url = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { mainQuest: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'main_quests_id' in args) {
            args = { mainQuest: args.main_quests_id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    mainQuest: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        mainQuest: typeof args.mainQuest === 'object'
                ? args.mainQuest.main_quests_id
                : args.mainQuest,
                }

    return show.definition.url
            .replace('{mainQuest}', parsedArgs.mainQuest.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\MainQuestWebController::show
 * @see app/Http/Controllers/Web/MainQuestWebController.php:49
 * @route '/main-quests/{mainQuest}'
 */
show.get = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\MainQuestWebController::show
 * @see app/Http/Controllers/Web/MainQuestWebController.php:49
 * @route '/main-quests/{mainQuest}'
 */
show.head = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\MainQuestWebController::show
 * @see app/Http/Controllers/Web/MainQuestWebController.php:49
 * @route '/main-quests/{mainQuest}'
 */
    const showForm = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\MainQuestWebController::show
 * @see app/Http/Controllers/Web/MainQuestWebController.php:49
 * @route '/main-quests/{mainQuest}'
 */
        showForm.get = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\MainQuestWebController::show
 * @see app/Http/Controllers/Web/MainQuestWebController.php:49
 * @route '/main-quests/{mainQuest}'
 */
        showForm.head = (args: { mainQuest: number | { main_quests_id: number } } | [mainQuest: number | { main_quests_id: number } ] | number | { main_quests_id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
const mainQuests = {
    index: Object.assign(index, index),
show: Object.assign(show, show),
}

export default mainQuests